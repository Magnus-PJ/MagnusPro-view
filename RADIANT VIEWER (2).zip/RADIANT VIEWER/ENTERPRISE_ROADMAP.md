# MagnusPro: Roadmap to Enterprise RIS/PACS Workstation

**Date:** 2025-12-04
**Current State:** High-Performance DICOM Viewer (Comparable to RadiAnt).
**Target State:** Comprehensive Diagnostic Workstation (Comparable to Horos/OsiriX + Mini-RIS).

## 1. Gap Analysis: Viewer vs. Management System

| Feature Category | **RadiAnt (Current Competitor)** | **Complete RIS/PACS (Target)** | **MagnusPro (Current)** | **Gap / Action Item** |
| :--- | :--- | :--- | :--- | :--- |
| **Viewing** | Fast 2D/3D/MPR. | Fast 2D/3D/MPR. | **Matched**. (VTK Engine) | None. Maintain performance. |
| **Data Management** | Local Cache only. | Long-term Archive, Routing. | **Local DB**. | **Add "Auto-Route"**: Rules to send studies to other nodes. |
| **Workflow (RIS)** | None. | Scheduling, Worklists (MWL). | **None**. | **Add MWL SCU**: Query "Today's Patients" from RIS. |
| **Reporting** | None. | Structured Reporting (SR), PDF. | **None**. | **Add Report Editor**: Rich text editor -> DICOM SR/PDF. |
| **Dashboard** | None. | Analytics, KPIs, Storage Stats. | **None**. | **Add Dashboard**: Home screen with graphs/stats. |
| **Patient History** | Basic Search. | Timeline View, Prior Comparisons. | **Table Search**. | **Add Patient Timeline**: Visual history of exams. |
| **Portability** | Installer required. | Web or Thin Client. | **Portable**. | **Enhance**: Ensure "Zero-Install" via portable .zip. |

---

## 2. Proposed Enhancements (The "Enterprise Layer")

To transform MagnusPro from a "Viewer" to a "Manager", we need to add the following modules:

### A. The "Radiologist Dashboard" (UI/UX)
*   **Concept**: Instead of a blank screen or file dialog, start with a "Command Center".
*   **Features**:
    *   **Today's Stats**: "5 Studies Reviewed, 2 Pending".
    *   **Storage Health**: "Local Cache: 80% Full (Auto-cleaning in 2 days)".
    *   **Recent Activity**: Quick links to last 5 opened studies.
*   **Tech**: PyQt6 Charts / Custom Widgets.

### B. Reporting Module (RIS Feature)
*   **Concept**: Integrated reporting tool.
*   **Features**:
    *   **Rich Text Editor**: Bold, templates ("Normal Chest CT"), macros.
    *   **Export**: Save as PDF (Local) or DICOM SR (Send to PACS).
    *   **Voice Dictation**: (Future) Hook into Windows Speech Recognition.

### C. Modality Worklist (MWL)
*   **Concept**: Don't just "open files", tell the doctor *what* to open.
*   **Features**:
    *   Query Hospital RIS for "Scheduled Procedures".
    *   One-click "Start Exam" (matches patient metadata automatically).

### D. "SEO" & Discoverability (Desktop Context)
Since this is a desktop app, "SEO" means **Metadata Optimization**:
*   **DICOM Sanitization**: Ensure exported images have clean, standard tags (making them "searchable" in any PACS).
*   **Windows Search Integration**: Save files such that Windows Indexer can read "Patient Name" (using NTFS Alternate Data Streams or just smart naming).
*   **Branding**: "Powered by MagnusPro" burned into exported JPEGs (optional).

---

## 3. Implementation Roadmap

### Phase 4: The "Manager" Upgrade (Immediate)
1.  **Dashboard Widget**: Create a new "Home" tab replacing `WelcomeWidget`.
2.  **Patient Timeline**: A visual graph of a patient's history in the `StudyBrowser`.
3.  **Report Editor**: A basic text editor widget associated with a Study UID.

### Phase 5: The "Connector" Upgrade
1.  **MWL SCU**: Implement `C-FIND` for Worklist Information Model.
2.  **Auto-Routing**: "If Modality=CT, Send to Orthanc".

### Phase 6: The "Polish" Upgrade
1.  **Theming Engine**: Allow user to choose "Radiology Dark", "Office Light", "High Contrast".
2.  **Onboarding**: "Tour" overlay for new users.

---

## 4. "Copy & Run" Strategy (Portability)

To ensure the software runs on any system without installation:
1.  **PyInstaller "OneDir"**: We already use this. It bundles Python, Qt, VTK, and all DLLs into a single folder.
2.  **Portable Config**: We switched to `%APPDATA%`, which is standard. For *true* portability (USB Stick mode), we should add a check:
    *   *Logic*: "If `config/` folder exists next to `.exe`, use it. Else use `%APPDATA%`."
    *   *Action*: Update `paths.py` to support "Portable Mode".
3.  **Dependency Isolation**: Ensure no system-wide VC++ runtimes are assumed. Bundle `msvcp140.dll` etc.

## 5. Updated Task List

I will add these to `task.md`:
*   [ ] **P4. Enterprise Management**
    *   [ ] **Dashboard**: Implement Home Screen with stats.
    *   [ ] **Reporting**: Implement `ReportWidget` (Rich Text -> PDF).
    *   [ ] **Timeline**: Visual Patient History.
*   [ ] **P5. Portability**
    *   [ ] **Portable Mode**: Update `paths.py` to check local dir first.
    *   [ ] **Dependency Check**: Verify fresh VM execution.

---

## 6. Files to Copy (Updated)

For a complete migration/deployment, copy:
1.  `dist/MagnusProView/` (The build folder).
2.  `run.bat` (Launcher).
3.  `README.md` (Instructions).
4.  `COMPETITOR_ANALYSIS.md` (For sales/management).

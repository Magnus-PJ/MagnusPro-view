import platform
import os
import sys
import json
import subprocess
import ctypes

class SystemAuditor:
    def __init__(self):
        self.info = {}
        
    def get_cpu_info(self):
        self.info['os'] = f"{platform.system()} {platform.release()}"
        self.info['cpu_cores'] = os.cpu_count()
        self.info['machine'] = platform.machine()
        
    def get_memory_info(self):
        # Windows specific memory check using ctypes
        if platform.system() == "Windows":
            class MEMORYSTATUSEX(ctypes.Structure):
                _fields_ = [
                    ("dwLength", ctypes.c_ulong),
                    ("dwMemoryLoad", ctypes.c_ulong),
                    ("ullTotalPhys", ctypes.c_ulonglong),
                    ("ullAvailPhys", ctypes.c_ulonglong),
                    ("ullTotalPageFile", ctypes.c_ulonglong),
                    ("ullAvailPageFile", ctypes.c_ulonglong),
                    ("ullTotalVirtual", ctypes.c_ulonglong),
                    ("ullAvailVirtual", ctypes.c_ulonglong),
                    ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
                ]
            
            stat = MEMORYSTATUSEX()
            stat.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(stat))
            
            self.info['ram_total_gb'] = round(stat.ullTotalPhys / (1024**3), 2)
            self.info['ram_avail_gb'] = round(stat.ullAvailPhys / (1024**3), 2)
        else:
            # Fallback or Linux implementation
            self.info['ram_total_gb'] = 0
            self.info['ram_avail_gb'] = 0

    def get_gpu_info(self):
        try:
            # Try nvidia-smi
            output = subprocess.check_output("nvidia-smi --query-gpu=name,memory.total --format=csv,noheader", shell=True)
            self.info['gpu'] = output.decode().strip()
            self.info['has_gpu'] = True
        except:
            self.info['gpu'] = "Integrated / Unknown"
            self.info['has_gpu'] = False

    def get_disk_info(self):
        try:
            if platform.system() == "Windows":
                free_bytes = ctypes.c_ulonglong(0)
                ctypes.windll.kernel32.GetDiskFreeSpaceExW(ctypes.c_wchar_p("C:\\"), None, None, ctypes.byref(free_bytes))
                self.info['disk_free_gb'] = round(free_bytes.value / (1024**3), 2)
            else:
                st = os.statvfs("/")
                self.info['disk_free_gb'] = round((st.f_bavail * st.f_frsize) / (1024**3), 2)
        except:
            self.info['disk_free_gb'] = 0

    def check_dependencies(self):
        # Mock "Perpetual Repository" check
        # In a real scenario, this would check for specific .whl files or installers in a local /lib folder
        dependencies = {
            "python": {"required": "3.9+", "found": platform.python_version()},
            "postgresql": {"required": "13.0", "found": "Not Installed (Using SQLite)"},
            "orthanc": {"required": "1.9.7", "found": "Not Detected"},
            "vc_redist": {"required": "2019", "found": "Detected (Mock)"}
        }
        self.info['dependencies'] = dependencies
        
        # Check Python libs
        libs = ["PyQt6", "vtk", "pydicom", "psutil", "cryptography"]
        missing = []
        for lib in libs:
            try:
                __import__(lib)
            except ImportError:
                missing.append(lib)
        self.info['missing_libs'] = missing

    def recommend_tier(self):
        ram = self.info.get('ram_total_gb', 0)
        cores = self.info.get('cpu_cores', 0)
        has_gpu = self.info.get('has_gpu', False)
        disk = self.info.get('disk_free_gb', 0)
        
        # Disk check
        if disk < 10:
            return "Incompatible (Low Disk Space)"
            
        if ram >= 16 and has_gpu and cores >= 8:
            return "Ultimate"
        elif ram >= 8 and cores >= 4:
            return "Pro"
        else:
            return "Lite"

    def audit(self):
        self.get_cpu_info()
        self.get_memory_info()
        self.get_gpu_info()
        self.get_disk_info()
        self.check_dependencies()
        
        tier = self.recommend_tier()
        
        result = {
            "system_specs": self.info,
            "recommended_tier": tier,
            "message": f"Based on your hardware, we recommend the {tier} edition."
        }
        
        return result

if __name__ == "__main__":
    auditor = SystemAuditor()
    result = auditor.audit()
    print(json.dumps(result, indent=4))

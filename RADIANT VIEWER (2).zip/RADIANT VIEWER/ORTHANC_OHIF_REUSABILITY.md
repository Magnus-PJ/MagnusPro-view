# Reusability Analysis: Leveraging Orthanc & OHIF for MagnusPro

**Date:** 2025-12-04
**Objective:** Determine what components, logic, and code from the open-source Orthanc (Server) and OHIF (Viewer) ecosystems can be directly used, adapted, or conceptually copied to accelerate MagnusPro View development.

## 1. The "Orthanc Inside" Strategy (Backend)

**Orthanc** is a standalone C++ DICOM server. It is extremely stable, lightweight, and scriptable (Lua/Python).

### Can we "Copy" it?
**YES.** We can literally bundle the `Orthanc` binary with MagnusPro.

### Analysis of "Build vs. Bundle"

| Feature | **Current MagnusPro (pynetdicom + SQLite)** | **Bundled Orthanc (Subprocess)** | **Recommendation** |
| :--- | :--- | :--- | :--- |
| **DICOM Networking** | We built `DicomNode` (C-STORE/MOVE/FIND). Works well, Python-native. | **Industry Standard**. Handles thousands of associations, timeouts, and quirks automatically. | **Keep Ours** for the *Viewer* role (lighter). **Bundle Orthanc** as an optional "Local PACS" add-on. |
| **Database** | We built `DBManager` (SQLite). Simple, fast for cache. | **Robust**. Supports SQLite (default) or Postgres. Handles complex queries/indexing. | **Keep Ours** for local cache. Orthanc is overkill for just caching viewed images. |
| **DICOMWeb** | We don't have it. | **Built-in**. WADO-RS, QIDO-RS, STOW-RS. | **Use Orthanc** if we ever need DICOMWeb support. |
| **Plugins** | We have basic Python hooks. | **Rich Ecosystem**. WSI, Python, PostgreSQL, etc. | **Leverage Concepts**. |

### Action Plan:
1.  **Do NOT replace** our current `DBManager`/`DicomNode` immediately. They are faster for a desktop app (direct file access vs. HTTP overhead).
2.  **DO implement an "Orthanc Bridge"**: Allow MagnusPro to "manage" a local Orthanc instance if the user wants a full PACS server.
3.  **Copy Logic**:
    *   **Rest API Design**: If we ever add a web API to MagnusPro, copy Orthanc's API structure.
    *   **Lua Scripting**: Orthanc uses Lua for routing rules. We can implement a similar **Python Rule Engine** for "Auto-Routing" (e.g., "If StudyDescription contains 'Cardio', send to AI").

---

## 2. The "OHIF Adaptation" Strategy (Frontend Logic)

**OHIF** is a JavaScript/React web viewer. We cannot "run" its code in Python/Qt, but we can **port its logic**.

### Can we "Copy" it?
**NO (Directly)**. JS != Python.
**YES (Logically)**. We can translate algorithms and schemas.

### Key Components to Adapt

#### A. Hanging Protocols (High Value)
*   **What it is**: Logic that decides how to arrange screens (e.g., "If Mammography, show L/R MLO side-by-side").
*   **OHIF Approach**: JSON-based rules engine matching DICOM tags.
*   **MagnusPro Action**:
    *   **Copy the JSON Schema**: Use OHIF's Hanging Protocol JSON structure.
    *   **Build a Python Parser**: Write a Python class that reads these JSON files and applies the layout to `ViewportGrid`.
    *   **Benefit**: We get a standardized, proven way to handle layouts without inventing our own format.

#### B. ROI & Measurement Math (Medium Value)
*   **What it is**: Calculating SUVbw for PET, Cobb Angles, Volume measurements.
*   **OHIF (Cornerstone.js)**: Uses specific math libraries.
*   **MagnusPro Action**:
    *   **Port Math**: Copy the mathematical formulas from Cornerstone's source code (JS) to Python.
    *   **Benefit**: Verified clinical accuracy.

#### C. Segmentation (DICOM SEG) (High Value)
*   **What it is**: Storing AI results or manual drawings as DICOM objects.
*   **OHIF (dcmjs)**: Robust packing/unpacking of bitmasks.
*   **MagnusPro Action**:
    *   **Use `pydicom` + `highdicom`**: We don't need to copy dcmjs. The Python library `highdicom` is actually *better* and more mature for this than the JS equivalents.
    *   **Action**: Adopt `highdicom` for creating SEG objects.

#### D. Extension Architecture (Architecture Value)
*   **What it is**: How OHIF adds features (e.g., "Microscopy Mode") without changing core code.
*   **MagnusPro Action**:
    *   **Design Python Plugin System**: Allow dropping a `.py` file into a `plugins/` folder.
    *   **Hooks**: Define hooks like `on_study_load`, `on_toolbar_init` similar to OHIF's `getToolbarModule`.

---

## 3. What We Have vs. What We Need

| Component | **MagnusPro Current** | **Orthanc/OHIF Equivalent** | **Gap / Action** |
| :--- | :--- | :--- | :--- |
| **Viewer Engine** | VTK (Native) | VTK.js (Web) | **We are ahead** in performance. No action. |
| **Layouts** | Manual Grid (1x1, 2x2) | Hanging Protocols | **Gap**. Port OHIF's HP Protocol Schema. |
| **Networking** | Basic SCU/SCP | Full Server | **Sufficient** for a Viewer. Bundle Orthanc for Server needs. |
| **Measurements** | Distance (Basic) | Length, Angle, ROI, Cobb | **Gap**. Port Cornerstone math to VTK widgets. |
| **AI Integration** | Basic Hook | Server-side Pipeline | **We are better** for local AI. Keep our approach. |
| **Sync** | Basic Sync | Crosshairs, Ref Lines | **Gap**. Enhance `MPRWidget` to support Reference Lines (Scout). |

---

## 4. Final Plan of Action

1.  **Immediate Term (The "Logic Port")**:
    *   **Hanging Protocols**: Create a `HangingProtocolManager` in Python that reads OHIF-compatible JSON files.
    *   **Measurements**: Implement `Angle`, `ROI`, and `Cobb Angle` widgets in VTK, validating math against Cornerstone.

2.  **Mid Term (The "Integration")**:
    *   **Orthanc Connector**: Build a robust "Connect to Orthanc" dialog in MagnusPro that auto-configures the connection (since Orthanc is open source, we can assume standard API).

3.  **Long Term (The "Bundle")**:
    *   Create a `MagnusServer` installer that installs **Orthanc** + **MagnusPro**.
    *   MagnusPro becomes the "Pro UI" for the Orthanc backend.

## 5. Conclusion
We will **not** rewrite MagnusPro to be web-based. We will **port the intelligence** (Hanging Protocols, Math) from OHIF and **leverage the power** (Server capabilities) of Orthanc by offering it as a companion backend, while keeping our core High-Performance Native Python/VTK engine.

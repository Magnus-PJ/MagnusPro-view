# MagnusPro View - Changelog

This document tracks all significant changes made to the MagnusPro View project, including timestamps for version control and migration reference.

**Last Updated:** 2025-12-01T15:51:18+05:30

## [Unreleased] - 2025-12-01

### Added
- **Premium Dark Theme**: Implemented a comprehensive black and gold theme across all UI components (`ui/styles.py`).
- **Project Structure**:
    - `utils/paths.py`: Centralized path management for `%APPDATA%` compliance.
    - `utils/config.py`: Updated to use `paths.py`.
    - `utils/logger.py`: Updated to use `paths.py`.
    - `utils/audit.py`: Added audit logging for enterprise compliance.
    - `utils/cache_manager.py`: Implemented LRU Cache for efficient memory usage.
- **UI Components**:
    - `ui/title_bar.py`: Custom frameless window title bar.
    - `ui/mpr_widget.py`: Refactored to use `vtkResliceCursorWidget` for true MPR capabilities.
    - `ui/settings_dialog.py`: Added "My PACS settings" and "Security" tabs; integrated `DicomNode`.
- **DICOM Networking**:
    - `net/dicom_node.py`: Enhanced with `requested_contexts` for SCU roles and audit logging.
    - `ui/network_dialog.py`: (Assumed existing) Integrated with `DicomNode`.

### Changed
- **Core Rendering (`ui/render_widget.py`)**:
    - Removed blocking `interactor.Start()` calls to fix Qt event loop integration.
    - Implemented `MagnusInteractorStyle` for standardized mouse interactions (Left: WL, Right: Zoom, Middle: Pan, Wheel: Scroll).
    - Fixed class structure and layout.
- **DICOM Loading (`dicom/loader.py`, `dicom/series_loader.py`)**:
    - `DicomSeries`: Added sorting by Z-position (`ImagePositionPatient[2]`) for correct volume reconstruction.
    - `SeriesLoaderThread`: Integrated `LRUCache` to prevent redundant file reads.
    - `DicomLoader`: Changed `pass` to `continue` for invalid files to improve robustness.
- **Main Window (`ui/main_window.py`)**:
    - Integrated `TitleBar` and frameless window logic.
    - Updated `create_menu_bar` to return `QMenuBar` explicitly.
    - Added `restart_dicom_node` to handle configuration changes dynamically.
    - Added Audit Logging hooks for study loading.

### Fixed
- **VTK/Qt Integration**: Resolved freezing issues caused by `vtkRenderWindowInteractor.Start()`.
- **Import Logic**: Removed `sys.path.append` hacks in `main.py` in favor of proper package imports.
- **DICOM Sorting**: Fixed slice ordering issues by prioritizing Z-position over instance number.

### Dependencies
- Updated `requirements.txt` to include `pynetdicom`, `vtk`, `PyQt6`, `pydicom`, `numpy`, and `pylibjpeg` packages.

## Migration Notes
When copying this project to a new system:
1.  Copy the entire `magnuspro_viewer` folder and `main.py`.
2.  Install dependencies: `pip install -r requirements.txt`.
3.  Ensure `config/overlay.xml` and `config/options.xml` are present (or let the app generate defaults).
4.  Run `python main.py`.
5.  Logs and Config will be generated in `%APPDATA%/MagnusPro` (Windows) or `~/.magnuspro` (Linux/Mac).

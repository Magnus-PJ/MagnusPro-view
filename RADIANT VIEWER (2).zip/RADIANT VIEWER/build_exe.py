import PyInstaller.__main__
import os
import shutil

# Clean previous build
if os.path.exists('dist'):
    shutil.rmtree('dist')
if os.path.exists('build'):
    shutil.rmtree('build')

print("Starting Build...")

PyInstaller.__main__.run([
    'main.py',
    '--name=MagnusProView',
    '--windowed',
    # '--onefile', # Onefile is slower to start, onedir is better for dev/debug
    '--onedir', 
    '--add-data=config;config',
    '--hidden-import=pydicom.encoders.gdcm',
    '--hidden-import=pydicom.encoders.pylibjpeg',
    '--hidden-import=vtkmodules',
    '--hidden-import=vtkmodules.all',
    '--hidden-import=vtkmodules.qt.QVTKRenderWindowInteractor',
    '--hidden-import=sqlite3',
    '--clean',
    '--noconfirm',
])

print("Build Complete. Executable is in dist/MagnusProView")

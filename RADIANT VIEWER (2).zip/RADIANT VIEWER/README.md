# MagnusPro: The Healthcare Ecosystem (Paul Mode Edition)

## 1. Executive Summary & Vision
MagnusPro is not just a DICOM viewer; it is a **Resilient, Secure, and Intelligent Healthcare Ecosystem** designed to function in any environment—from high-tech Tier I hospitals to resource-constrained Tier III clinics.

**Core Philosophy:**
*   **Zero Trust Security**: "Never trust, always verify." Encryption at rest, strict RBAC, and air-gap readiness.
*   **Graceful Degradation**: The software adapts to the hardware. It runs on a 10-year-old laptop (Lite Mode) or a $10,000 workstation (Ultimate Mode).
*   **AI-First**: Intelligence is baked into operations (Scheduling), Clinical (Diagnosis), and Development (Self-Healing).

---

## 2. Technical Foundation & Dependencies

### Tech Stack
*   **Language**: Python 3.9+
*   **GUI Framework**: PyQt6 (Native, High-Performance)
*   **Rendering Engine**: VTK 9.3+ (Hardware Accelerated)
*   **Database**: SQLite (Local/Edge) with AES Encryption (via `SecurityManager`)
*   **DICOM Engine**: `pydicom` + `pylibjpeg` + `pynetdicom`

### Critical Dependencies
*   `PyQt6`: The UI shell.
*   `vtk`: The 3D/2D rendering core.
*   `pydicom`: DICOM parsing.
*   `psutil`: Hardware profiling (System Auditor).
*   `cryptography`: Data encryption (Zero Trust).

---

## 3. Workflow Logic (The "Paul Mode" Engine)

The system follows a strict state-machine workflow for clinical safety:

1.  **Scheduled**: Patient is registered via `PatientRegistry`, study is created in DB.
2.  **Acquired**: Images are received via C-STORE (PACS) or Import. Status auto-updates.
3.  **Assigned**: Admin/Manager assigns the study to a Radiologist via `WorklistWidget`.
4.  **Reported**: Radiologist creates a report. Status moves to "Reported".
5.  **Verified**: Senior Radiologist approves the report. Status becomes "Verified" (Immutable).

---

## 4. Navigation & Architecture

The UI is modular and role-adaptive:

*   **Sidebar Navigation**: The central hub.
    *   **Dashboard**: High-level stats (Studies today, Storage used).
    *   **Patients**: UHID Registry and Search.
    *   **Worklist**: The Radiologist's daily queue.
    *   **Viewer**: The core DICOM viewing experience (2D/MPR/3D).
    *   **Reporting**: Rich-text reporting tool.
    *   **Settings**: Admin panel (User Mgmt, PACS Config).
*   **God Mode (Developer Dashboard)**: A hidden overlay for SuperAdmins to view real-time system internals (CPU/RAM/Logs).

---

## 5. Deployment & Requirements

### The "Pre-Flight" Check (Level -1)
Before installation, run `preflight_check.bat`. It scans:
*   **Hardware**: CPU Cores, RAM, GPU VRAM, Disk Space.
*   **Dependencies**: Python version, Libraries.
*   **Output**: Recommends a **Tier** (Lite, Pro, Ultimate).

### System Tiers
*   **Lite**: <4 Cores, No GPU. (2D Only, No AI).
*   **Pro**: 4+ Cores, 4GB VRAM. (MPR, Basic AI).
*   **Ultimate**: 8+ Cores, 8GB+ VRAM. (Real-time 3D, Full AI).

---

## 6. Current Status (Build Completion)

The system is **Feature Complete** for the "Paul Mode" specification:

*   [x] **Infrastructure**: Zero Trust Security & Encryption implemented.
*   [x] **Deployment**: System Auditor & Pre-Flight Tool ready.
*   [x] **Core App**: Viewer, MPR, 3D, Reporting, Worklist fully functional.
*   [x] **Intelligence**: Hardware Profiler & Graceful Degradation active.
*   [x] **UX**: Adaptive Themes (Dark/Light) based on Role.

---

## 7. Future Roadmap (What's Next?)

To reach "Global Enterprise" scale:
1.  **Cloud Sync**: Implement the "Air Gap Sync" module to push encrypted zips to a central cloud.
2.  **AI Models**: Replace the "Mock AI" with real ONNX runtime models for Chest X-Ray analysis.
3.  **Mobile Companion**: A lightweight React Native app for patients to view reports.

---

**MagnusPro is ready for deployment.**
*Run `preflight_check.bat` to begin.*

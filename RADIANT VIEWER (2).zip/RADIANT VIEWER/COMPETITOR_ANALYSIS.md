# Comprehensive PACS & DICOM Viewer Comparison Analysis

**Date:** 2025-12-04
**Subject:** MagnusPro View vs. Global Competitors (RadiAnt, OHIF, Horos, etc.)

## 1. Executive Summary

This document provides an extensive technical and functional comparison between **MagnusPro View** (our current Python/Qt/VTK implementation) and the leading DICOM viewers and PACS solutions in the global market. The comparison focuses on architecture, technology stack, rendering capabilities, deployment, and specific feature sets.

**Primary Conclusion:** MagnusPro View is positioned as a **High-Performance Native Desktop Viewer** most similar to RadiAnt, but with the added flexibility of Python for rapid enterprise integration (AI hooks, custom databases). It outperforms web-based solutions (OHIF) in raw volume rendering speed and memory efficiency for large datasets but currently lacks the zero-footprint deployment advantage of web viewers.

---

## 2. Competitor Landscape

We are comparing MagnusPro View against:
1.  **RadiAnt DICOM Viewer** (Windows, Native C++) - *The Gold Standard for Speed/UX.*
2.  **OHIF Viewer** (Web, React/VTK.js) - *The Modern Web Standard.*
3.  **Horos / OsiriX** (macOS, Objective-C/Cocoa) - *The Apple Standard.*
4.  **Weasis** (Cross-platform, Java) - *The Enterprise/Hospital Integration Standard.*
5.  **Orthanc** (PACS Server + Web Viewer) - *The Lightweight PACS Standard.*

---

## 3. Detailed Technical Comparison

### A. Technology Stack & Architecture

| Feature | **MagnusPro View** (Ours) | **RadiAnt** | **OHIF** | **Horos / OsiriX** | **Weasis** |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Core Language** | **Python 3.9+** | C++ (Native) | JavaScript (React) | Objective-C / Swift | Java |
| **GUI Framework** | **PyQt6 (Qt 6)** | Custom / Win32 / MFC | HTML5 / CSS3 | Cocoa (macOS Native) | Java Swing / JavaFX |
| **Rendering Engine** | **VTK 9.3 (C++ bindings)** | Custom OpenGL / DirectX | VTK.js / Cornerstone.js | OpenGL (Native) | Java 2D / OpenGL |
| **DICOM Parsing** | **pydicom + pylibjpeg** | Custom C++ Parser | dcmjs | DCMTK (C++) | dcm4che (Java) |
| **Database** | **SQLite (Local)** | SQLite / File-based | MongoDB (via Orthanc/DCM4CHEE) | SQLCipher / CoreData | None (Stateless) / Local Cache |
| **Architecture** | **Monolithic Desktop App** | Monolithic Desktop App | SPA (Single Page App) | Monolithic Desktop App | Rich Client (Web Start) |

**Analysis:**
-   **MagnusPro vs. RadiAnt:** We use Python/Qt, which is slightly heavier than RadiAnt's pure C++, but VTK provides comparable GPU rendering performance. Python allows faster development of AI features.
-   **MagnusPro vs. OHIF:** OHIF is limited by browser memory caps (WASM helps, but native is unmatched for 5000+ slice datasets). MagnusPro has full system access.

### B. Rendering & Visualization Capabilities

| Feature | **MagnusPro View** | **RadiAnt** | **OHIF** | **Horos** |
| :--- | :--- | :--- | :--- | :--- |
| **2D Performance** | **High** (GPU Accelerated) | **Extreme** (Optimized C++) | **Medium** (Browser Canvas) | **High** (Metal/OpenGL) |
| **MPR (Multi-Planar)** | **True MPR** (vtkResliceCursor) | **Real-time** (Fluid) | **Good** (VTK.js) | **Excellent** (Curved MPR support) |
| **3D Volume Rendering** | **GPU Ray Casting** (VTK) | **GPU** (Custom Shader) | **Basic** (VTK.js, heavy on client) | **Advanced** (Surface/Volume) |
| **Fusion (PET/CT)** | *Planned* | Yes | Yes | Yes |
| **Cine Loop** | **Yes** (QTimer + VTK) | Yes (Fluid) | Yes | Yes |
| **Time-Intensity Curve** | *No* | Yes | Extension required | Yes |

**Code-Level Comparison (MPR):**
-   **MagnusPro**: Uses `vtkResliceCursorWidget`. This is a high-level VTK widget that handles the plane geometry and interaction internally.
-   **RadiAnt**: Likely uses raw OpenGL texture slicing. This allows them slightly lower overhead but requires writing complex shader math manually.
-   **OHIF**: Uses `vtk.js` `vti` volume representation. It requires downloading the entire dataset into browser memory before MPR can start, causing initial lag.

### C. Backend & PACS Integration

| Feature | **MagnusPro View** | **RadiAnt** | **Orthanc (Server)** | **DCM4CHEE (Server)** |
| :--- | :--- | :--- | :--- | :--- |
| **Protocol** | **DIMSE (C-STORE, C-MOVE)** | DIMSE | DIMSE + DICOMWeb | DIMSE + DICOMWeb |
| **Library** | **pynetdicom** | Custom / DCMTK | DCMTK | dcm4che |
| **Networking** | **Async (QThread)** | Multi-threaded | Async Server | Enterprise Java Beans |
| **Security** | **TLS (Supported)** | TLS | TLS | TLS + OIDC |
| **Local Cache** | **SQLite + LRU (Files)** | SQLite | JSON/SQLite/Postgres | Postgres/MySQL |

**Analysis:**
-   **MagnusPro** acts as a **DICOM Node** (SCP/SCU). It is not a full PACS server like Orthanc, but a "Thick Client" workstation.
-   **RadiAnt** operates similarly. It queries a PACS and pulls images locally.
-   **MagnusPro Advantage**: Our `DBManager` and `DicomNode` are tightly integrated in Python. We can easily add logic like "Auto-route to AI model on receive" which is impossible in RadiAnt without external scripting.

### D. Deployment & Distribution

| Method | **MagnusPro View** | **RadiAnt** | **OHIF** | **Weasis** |
| :--- | :--- | :--- | :--- | :--- |
| **Installer** | **PyInstaller (EXE)** | MSI / EXE | N/A (Web) | MSI / DEB / RPM |
| **Size** | **~150MB** (w/ VTK/Qt) | **~7MB** (Tiny!) | **~5MB** (Bundle) | **~100MB** (w/ JRE) |
| **Updates** | *Manual / Script* | Auto-update | Server-side | Web Start / Auto |
| **OS Support** | **Windows, Linux, Mac** | Windows Only | All (Browser) | All (Java) |

**Gap Analysis**: RadiAnt's 7MB size is a marvel of optimization. MagnusPro bundles the Python interpreter, Qt DLLs, and VTK DLLs, making it significantly larger. However, storage is cheap; functionality matters more.

---

## 4. Feature-by-Feature "Code" Comparison

### 1. DICOM Loading (The "First Impression")
*   **RadiAnt**: Reads headers only, lazy-loads pixels. Instant open.
*   **MagnusPro**:
    ```python
    # Our approach (dicom/loader.py)
    pydicom.dcmread(path, stop_before_pixels=True) # Fast header read
    # Pixel data loaded on demand via LRUCache
    ```
    *Verdict*: We match the architectural approach of RadiAnt. Performance depends on Python's file I/O overhead vs C++.

### 2. Mouse Interaction (The "Feel")
*   **RadiAnt**: Custom event loop. Extremely low latency.
*   **MagnusPro**:
    ```python
    # Our approach (ui/render_widget.py)
    class MagnusInteractorStyle(vtk.vtkInteractorStyleImage):
        def on_mouse_move(self):
            # VTK C++ internal handling -> High performance
            # Python signal emission -> Minimal overhead
    ```
    *Verdict*: By delegating the heavy lifting to VTK (C++), we achieve near-native performance. The Python layer only handles the "logic" of what tool is active.

### 3. MPR (The "Clinical Necessity")
*   **OHIF**: Client-side MPR in JS. Can be choppy on large datasets (2000+ slices).
*   **MagnusPro**:
    ```python
    # Our approach (ui/mpr_widget.py)
    vtkResliceCursorWidget() # Hardware accelerated slicing
    ```
    *Verdict*: VTK's C++ implementation of reslicing is industry-standard and superior to JS-based implementations for large volumes.

---

## 5. Strategic Recommendations for MagnusPro

To beat the competition, MagnusPro should not just "clone" RadiAnt, but leverage its Python nature:

1.  **AI Integration (The Killer Feature)**:
    *   RadiAnt is closed source. Integrating a custom PyTorch model requires complex workarounds.
    *   **MagnusPro**: Can import `torch` or `tensorflow` directly. We can add a "Run AI Nodule Detection" button that runs a model on the currently loaded `numpy` array in memory. **This is our unique selling point.**

2.  **Cross-Platform**:
    *   RadiAnt is Windows only.
    *   **MagnusPro** runs on Linux (great for AI researchers) and macOS (great for doctors).

3.  **Enterprise Customization**:
    *   Hospitals often need custom workflows (e.g., "Send to Billing").
    *   **MagnusPro**: Python scripts are easy to modify for specific hospital needs.

## 6. Conclusion

**MagnusPro View** is a robust, modern alternative to RadiAnt. While it carries a larger file size footprint, it matches the core rendering capabilities through VTK and offers superior extensibility.

**Scorecard:**
*   **Speed**: RadiAnt (10/10) > MagnusPro (8/10) > OHIF (6/10)
*   **Extensibility**: MagnusPro (10/10) > OHIF (9/10) > RadiAnt (2/10)
*   **Cross-Platform**: OHIF (10/10) > MagnusPro (9/10) > RadiAnt (1/10)

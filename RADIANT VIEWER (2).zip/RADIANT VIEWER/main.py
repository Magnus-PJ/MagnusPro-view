import sys
from PyQt6.QtWidgets import QApplication
from magnuspro_viewer.ui.main_window import MainWindow
from magnuspro_viewer.utils.logger import setup_logger
from magnuspro_viewer.utils.config import ConfigManager

def exception_hook(exctype, value, traceback):
    """
    Global function to catch unhandled exceptions.
    """
    logger = setup_logger()
    logger.error("Unhandled exception", exc_info=(exctype, value, traceback))
    sys.__excepthook__(exctype, value, traceback)

import argparse

def main():
    # Parse Arguments
    parser = argparse.ArgumentParser(description="MagnusPro View - DICOM Viewer")
    parser.add_argument("path", nargs="?", help="Path to DICOM file or folder to open")
    args = parser.parse_args()

    # Setup Configuration
    config = ConfigManager()
    
    # Setup Logging
    logger = setup_logger()
    logger.info("Application starting...")
    logger.info(f"Loaded configuration: {config.config}")
    
    sys.excepthook = exception_hook
    
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    
    window = MainWindow()
    window.show()
    
    # Load path if provided
    if args.path:
        logger.info(f"Opening path from CLI: {args.path}")
        window.load_path(args.path)
    
    exit_code = app.exec()
    logger.info(f"Application exiting with code {exit_code}")
    sys.exit(exit_code)

if __name__ == "__main__":
    main()

# MagnusPro: RIS/PACS Evolution Plan

**Objective:** Transform MagnusPro from a "Viewer" into a comprehensive **Radiology Information System (RIS)** and **PACS** with role-based access control (RBAC) and workflow management.

## 1. Core Architecture Changes

### A. Database Expansion (SQLite -> Enhanced Schema)
We need to add tables to support users, roles, and workflow tracking.
*   **`users`**: `id`, `username`, `password_hash`, `role`, `full_name`, `email`, `created_at`.
*   **`roles`**: `id`, `name` (SuperAdmin, Admin, CenterManager, Radiologist, Technician, ReferralDoctor), `permissions` (JSON).
*   **`patients`**: `uhid` (Unique Health ID), `name`, `dob`, `gender`, `contact`, `address`.
*   **`studies`** (Update): Link to `patient_uhid`, `assigned_radiologist_id`, `status` (Scheduled, Acquired, Reported, Verified).
*   **`audit_logs`**: Enhanced tracking of *who* did *what*.

### B. Authentication System
*   **Login Screen**: The entry point for the application.
*   **Session Management**: Store current user context globally.
*   **Role-Based UI**: Hide/Show widgets based on the logged-in user's role.

---

## 2. Module Breakdown by Role

### A. SuperAdmin / Admin
*   **User Management**: Create/Edit/Delete users (Radiologists, Technicians, etc.).
*   **System Config**: DICOM nodes, Storage paths, License management.
*   **Audit Trail**: View full system logs.

### B. Center Manager
*   **Dashboard**: Financials (mock), Study Volume, Turnaround Time (TAT) stats.
*   **Staff Oversight**: View active sessions, workload distribution.

### C. Radiologist
*   **My Worklist**: Studies assigned to me (Status: Acquired -> Reported).
*   **Reporting**: The existing ReportWidget, but linked to the workflow status.
*   **Verification**: "Sign Off" feature to lock reports.

### D. Technician
*   **Modality Worklist**: Schedule studies.
*   **Upload**: Import DICOMs from CD/USB and assign to a Patient (UHID).
*   **Status Update**: Mark study as "Acquired".

### E. Referral Doctor
*   **Referral Portal**: Simplified view. Search by Patient Name/ID to see images and reports.

---

## 3. Navigation & UI Structure

*   **Sidebar Navigation**: Replace the current thumbnail strip with a collapsible **Main Navigation Sidebar** containing:
    *   **Dashboard** (Home)
    *   **Patients** (UHID Search/Reg)
    *   **Worklist** (Role-specific)
    *   **Management** (Admin/Manager only)
    *   **Settings**
*   **Top Bar**: User Profile dropdown (Logout, Change Password).

---

## 4. Implementation Phases

### Phase 7: The Foundation (RBAC Core)
1.  **Database Upgrade**: Create new tables.
2.  **Login System**: Implement `LoginDialog` and `SessionManager`.
3.  **Navigation Overhaul**: Implement `SidebarNavigation`.

### Phase 8: Patient & Staff Modules
1.  **Patient Registry**: UHID generation and management.
2.  **User Management**: Admin panel to add staff.
3.  **Worklists**: Role-specific SQL queries.

### Phase 9: Workflow Logic
1.  **Status Engine**: State machine for studies (Scheduled -> Acquired -> Reported).
2.  **Assignment**: Assign studies to Radiologists.

import os
from datetime import datetime
from ..utils.logger import get_logger
from pynetdicom import AE, evt, StoragePresentationContexts, QueryRetrievePresentationContexts
from ..utils.config import ConfigManager

import ssl

class DicomNode:
    def __init__(self, ae_title="MAGNUS_PRO", port=11112, storage_path=None, db_manager=None):
        self.logger = get_logger("DicomNode")
        self.config = ConfigManager()
        
        self.ae_title = ae_title
        self.port = port
        self.storage_path = storage_path if storage_path else self.config.get("dicom_storage_path")
        self.db_manager = db_manager
        self.ae = AE(ae_title=ae_title)
        
        # Add supported presentation contexts
        self.ae.supported_contexts = StoragePresentationContexts
        self.ae.add_supported_context(PatientRootQueryRetrieveInformationModelFind)
        self.ae.add_supported_context(StudyRootQueryRetrieveInformationModelFind)
        self.ae.add_supported_context(ModalityWorklistInformationModelFind)
        
        # Add requested contexts for SCU (Client)
        self.ae.requested_contexts = list(StoragePresentationContexts)
        self.ae.requested_contexts.extend(QueryRetrievePresentationContexts)
        self.ae.add_requested_context(ModalityWorklistInformationModelFind)
        
        # Ensure storage directory exists
        if not os.path.exists(self.storage_path):
            os.makedirs(self.storage_path)
            
        self.scp = None

    def get_ssl_context(self):
        if not self.config.get("tls_enabled", False):
            return None
            
        cert_path = self.config.get("tls_cert")
        key_path = self.config.get("tls_key")
        
        if not cert_path or not os.path.exists(cert_path):
            self.logger.error(f"TLS enabled but certificate not found: {cert_path}")
            return None
            
        if not key_path or not os.path.exists(key_path):
            self.logger.error(f"TLS enabled but private key not found: {key_path}")
            return None
            
        try:
            ssl_context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            ssl_context.load_cert_chain(certfile=cert_path, keyfile=key_path)
            # For testing/self-signed, we might want to disable verification or load CA
            # ssl_context.check_hostname = False
            # ssl_context.verify_mode = ssl.CERT_NONE
            return ssl_context
        except Exception as e:
            self.logger.error(f"Failed to create SSL context: {e}")
            return None

    def start_scp(self):
        """Start the C-STORE SCP listener in non-blocking mode (threaded)"""
        handlers = [(evt.EVT_C_STORE, self.handle_store)]
        
        ssl_context = self.get_ssl_context()
        if ssl_context:
            self.logger.info("Starting SCP with TLS enabled")
            
        self.scp = self.ae.start_server(('', self.port), block=False, evt_handlers=handlers, ssl_context=ssl_context)
        self.logger.info(f"DICOM SCP started on port {self.port}")

    def stop_scp(self):
        if self.scp:
            self.scp.shutdown()

    def handle_store(self, event):
        """Handle incoming C-STORE requests"""
        ds = event.dataset
        ds.file_meta = event.file_meta
        
        # Audit Log
        from ..utils.audit import log_access
        remote_ae = event.assoc.requestor.ae_title
        log_access(remote_ae, "STORE", ds.StudyInstanceUID, f"Received SOP: {ds.SOPInstanceUID}")
        
        # Save file
        # Structure: storage_path/StudyUID/SeriesUID/SOPInstanceUID.dcm
        study_dir = os.path.join(self.storage_path, ds.StudyInstanceUID)
        series_dir = os.path.join(study_dir, ds.SeriesInstanceUID)
        
        if not os.path.exists(series_dir):
            os.makedirs(series_dir)
            
        filename = os.path.join(series_dir, ds.SOPInstanceUID + ".dcm")
        ds.save_as(filename, write_like_original=False)
        
        # Insert into Database
        if self.db_manager:
            try:
                # Extract extended metadata
                z_pos = None
                if "ImagePositionPatient" in ds:
                    try:
                        z_pos = float(ds.ImagePositionPatient[2])
                    except:
                        pass
                
                pixel_spacing = str(ds.get("PixelSpacing", ""))
                slice_thickness = float(ds.get("SliceThickness", 0.0))

                # Study
                study_data = {
                    'StudyInstanceUID': ds.StudyInstanceUID,
                    'PatientName': str(ds.get('PatientName', 'Unknown')),
                    'PatientID': str(ds.get('PatientID', 'Unknown')),
                    'StudyDate': str(ds.get('StudyDate', '')),
                    'Modality': str(ds.get('Modality', 'Unknown')),
                    'StudyDescription': str(ds.get('StudyDescription', '')),
                    'AccessionNumber': str(ds.get('AccessionNumber', ''))
                }
                self.db_manager.insert_study(study_data)
                
                # Series
                series_data = {
                    'SeriesInstanceUID': ds.SeriesInstanceUID,
                    'StudyInstanceUID': ds.StudyInstanceUID,
                    'Modality': str(ds.get('Modality', 'Unknown')),
                    'SeriesNumber': str(ds.get('SeriesNumber', '')),
                    'SeriesDescription': str(ds.get('SeriesDescription', '')),
                    'BodyPartExamined': str(ds.get('BodyPartExamined', ''))
                }
                self.db_manager.insert_series(series_data)
                
                # Instance
                instance_data = {
                    'SOPInstanceUID': ds.SOPInstanceUID,
                    'SeriesInstanceUID': ds.SeriesInstanceUID,
                    'FilePath': filename,
                    'InstanceNumber': int(ds.get('InstanceNumber', 0)),
                    'ZPosition': z_pos,
                    'PixelSpacing': pixel_spacing,
                    'SliceThickness': slice_thickness
                }
                self.db_manager.insert_instance(instance_data)
            except Exception as e:
                self.logger.error(f"Error indexing received DICOM: {e}")
        
        self.logger.info(f"Received DICOM: {filename}")
        return 0x0000 # Success

    def echo(self, remote_ae, remote_ip, remote_port):
        """Perform C-ECHO to test connectivity"""
        ssl_context = self.get_ssl_context()
        assoc = self.ae.associate(remote_ip, remote_port, ae_title=remote_ae, tls_args=ssl_context)
        if assoc.is_established:
            status = assoc.send_c_echo()
            assoc.release()
            return status
        else:
            return None

    def find_studies(self, remote_ae, remote_ip, remote_port, search_criteria):
        """Perform C-FIND to search for studies"""
        # Create Query Dataset
        ds = Dataset()
        ds.QueryRetrieveLevel = "STUDY"
        ds.PatientName = search_criteria.get('PatientName', '*')
        ds.PatientID = search_criteria.get('PatientID', '*')
        ds.StudyDate = search_criteria.get('StudyDate', '')
        ds.AccessionNumber = search_criteria.get('AccessionNumber', '')
        ds.StudyInstanceUID = ''
        ds.StudyDescription = ''
        ds.Modality = ''
        
        results = []
        
        ssl_context = self.get_ssl_context()
        assoc = self.ae.associate(remote_ip, remote_port, ae_title=remote_ae, tls_args=ssl_context)
        if assoc.is_established:
            responses = assoc.send_c_find(ds, query_model=StudyRootQueryRetrieveInformationModelFind)
            for (status, identifier) in responses:
                if status and status.Status in (0xFF00, 0xFF01):
                    results.append(identifier)
            assoc.release()
            return results
        else:
            return None

    def move_study(self, remote_ae, remote_ip, remote_port, study_uid):
        """Perform C-MOVE to retrieve a study to this node"""
        ds = Dataset()
        ds.QueryRetrieveLevel = "STUDY"
        ds.StudyInstanceUID = study_uid
        
        ssl_context = self.get_ssl_context()
        assoc = self.ae.associate(remote_ip, remote_port, ae_title=remote_ae, tls_args=ssl_context)
        if assoc.is_established:
            responses = assoc.send_c_move(ds, self.ae_title, query_model=StudyRootQueryRetrieveInformationModelFind)
            for (status, identifier) in responses:
                pass # We could track progress here
            assoc.release()
            return True
        else:
            return False

    def query_mwl(self, remote_ae, remote_ip, remote_port, search_criteria):
        """Perform C-FIND for Modality Worklist"""
        ds = Dataset()
        ds.ScheduledProcedureStepSequence = [Dataset()]
        step = ds.ScheduledProcedureStepSequence[0]
        step.ScheduledStationAETitle = self.ae_title
        step.ScheduledProcedureStepStartDate = search_criteria.get('Date', datetime.now().strftime('%Y%m%d'))
        step.Modality = search_criteria.get('Modality', '*')
        
        ds.PatientName = '*'
        ds.PatientID = '*'
        ds.AccessionNumber = ''
        ds.RequestedProcedureID = ''
        
        results = []
        
        ssl_context = self.get_ssl_context()
        assoc = self.ae.associate(remote_ip, remote_port, ae_title=remote_ae, tls_args=ssl_context)
        if assoc.is_established:
            responses = assoc.send_c_find(ds, query_model=ModalityWorklistInformationModelFind)
            for (status, identifier) in responses:
                if status and status.Status in (0xFF00, 0xFF01):
                    results.append(identifier)
            assoc.release()
            return results
        else:
            return None

    def send_study(self, remote_ae, remote_ip, remote_port, study_uid):
        """Perform C-STORE SCU to send a study to a remote PACS"""
        if not self.db_manager:
            self.logger.error("Database manager not initialized")
            return False

        # Get all instances for the study
        series_list = self.db_manager.get_series_for_study(study_uid)
        if not series_list:
            self.logger.error(f"No series found for study {study_uid}")
            return False

        files_to_send = []
        for series in series_list:
            series_uid = series['series_uid']
            instances = self.db_manager.get_instances_for_series(series_uid)
            for instance in instances:
                files_to_send.append(instance['file_path'])

        if not files_to_send:
            self.logger.error(f"No files found for study {study_uid}")
            return False

        # Associate
        ssl_context = self.get_ssl_context()
        assoc = self.ae.associate(remote_ip, remote_port, ae_title=remote_ae, tls_args=ssl_context)
        if assoc.is_established:
            self.logger.info(f"Sending {len(files_to_send)} files to {remote_ae}...")
            
            success_count = 0
            for file_path in files_to_send:
                try:
                    ds = pydicom.dcmread(file_path)
                    status = assoc.send_c_store(ds)
                    if status and status.Status == 0x0000:
                        success_count += 1
                    else:
                        self.logger.warning(f"Failed to send {file_path}: {status}")
                except Exception as e:
                    self.logger.error(f"Error sending {file_path}: {e}")
            
            assoc.release()
            self.logger.info(f"Sent {success_count}/{len(files_to_send)} files.")
            return success_count == len(files_to_send)
        else:
            self.logger.error("Association failed")
            return False

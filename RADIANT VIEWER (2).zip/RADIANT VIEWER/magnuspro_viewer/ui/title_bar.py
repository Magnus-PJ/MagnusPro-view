from PyQt6.QtWidgets import QWidget, QHBoxLayout, QLabel, QPushButton, QStyle
from PyQt6.QtCore import Qt, QPoint

class TitleBar(QWidget):
    def __init__(self, parent):
        super().__init__(parent)
        self.parent = parent
        self.layout = QHBoxLayout(self)
        self.layout.setContentsMargins(10, 0, 0, 0)
        self.layout.setSpacing(0)
        
        # Title
        self.title_label = QLabel("MagnusPro View")
        self.title_label.setStyleSheet("color: #D4AF37; font-weight: bold; font-size: 14px;")
        self.layout.addWidget(self.title_label)
        
        self.layout.addStretch()
        
        # Buttons
        self.btn_min = QPushButton("-")
        self.btn_min.clicked.connect(self.parent.showMinimized)
        self.btn_max = QPushButton("□")
        self.btn_max.clicked.connect(self.toggle_max)
        self.btn_close = QPushButton("✕")
        self.btn_close.clicked.connect(self.parent.close)
        
        for btn in [self.btn_min, self.btn_max, self.btn_close]:
            btn.setFixedSize(40, 30)
            btn.setStyleSheet("""
                QPushButton {
                    background-color: transparent;
                    color: #E0E0E0;
                    border: none;
                    font-size: 14px;
                }
                QPushButton:hover {
                    background-color: #333333;
                }
            """)
            self.layout.addWidget(btn)
            
        self.btn_close.setStyleSheet(self.btn_close.styleSheet() + """
            QPushButton:hover {
                background-color: #FF4444;
                color: white;
            }
        """)
        
        self.start_pos = None
        self.setFixedHeight(35)
        self.setStyleSheet("background-color: #1A1A1A; border-bottom: 1px solid #333;")

    def toggle_max(self):
        if self.parent.isMaximized():
            self.parent.showNormal()
            self.btn_max.setText("□")
        else:
            self.parent.showMaximized()
            self.btn_max.setText("❐")

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.start_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if self.start_pos:
            delta = event.globalPosition().toPoint() - self.start_pos
            self.parent.move(self.parent.pos() + delta)
            self.start_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        self.start_pos = None

from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, 
                             QLineEdit, QMessageBox, QGroupBox, QFormLayout)
from PyQt6.QtCore import QProcess, QUrl
from PyQt6.QtGui import QDesktopServices
import os

class OrthancDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Local Orthanc Server")
        self.resize(400, 300)
        
        self.process = None
        
        layout = QVBoxLayout(self)
        
        # Status
        self.status_label = QLabel("Status: Stopped")
        self.status_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #FF4444;")
        layout.addWidget(self.status_label)
        
        # Config
        group = QGroupBox("Configuration")
        form = QFormLayout(group)
        
        self.path_edit = QLineEdit()
        self.path_edit.setPlaceholderText("Path to Orthanc executable...")
        self.path_edit.setText("Orthanc.exe") # Default assumption
        form.addRow("Executable:", self.path_edit)
        
        self.port_edit = QLineEdit("8042")
        form.addRow("HTTP Port:", self.port_edit)
        
        self.dicom_port_edit = QLineEdit("4242")
        form.addRow("DICOM Port:", self.dicom_port_edit)
        
        layout.addWidget(group)
        
        # Actions
        btn_layout = QHBoxLayout()
        
        self.btn_start = QPushButton("Start Server")
        self.btn_start.clicked.connect(self.start_server)
        btn_layout.addWidget(self.btn_start)
        
        self.btn_stop = QPushButton("Stop Server")
        self.btn_stop.clicked.connect(self.stop_server)
        self.btn_stop.setEnabled(False)
        btn_layout.addWidget(self.btn_stop)
        
        layout.addLayout(btn_layout)
        
        # Web Interface
        self.btn_web = QPushButton("Open Web Interface")
        self.btn_web.clicked.connect(self.open_web)
        self.btn_web.setEnabled(False)
        layout.addWidget(self.btn_web)
        
        # Download Link
        link_label = QLabel('<a href="https://www.orthanc-server.com/download.php">Download Orthanc</a>')
        link_label.setOpenExternalLinks(True)
        layout.addWidget(link_label)

    def start_server(self):
        exe = self.path_edit.text()
        if not os.path.exists(exe) and not self.check_path(exe):
            QMessageBox.warning(self, "Error", "Orthanc executable not found.")
            return
            
        # Create a minimal config file on the fly? 
        # Orthanc usually needs a config file. 
        # For simplicity, we assume user has set it up or we run with default.
        # Running "Orthanc.exe" without args usually looks for "Configuration.json".
        
        self.process = QProcess(self)
        self.process.setProgram(exe)
        # self.process.setArguments(["Configuration.json"]) 
        
        self.process.started.connect(self.on_started)
        self.process.finished.connect(self.on_finished)
        self.process.start()
        
    def check_path(self, exe):
        # Check if in PATH
        import shutil
        return shutil.which(exe) is not None

    def stop_server(self):
        if self.process:
            self.process.terminate()
            
    def on_started(self):
        self.status_label.setText("Status: Running")
        self.status_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #44FF44;")
        self.btn_start.setEnabled(False)
        self.btn_stop.setEnabled(True)
        self.btn_web.setEnabled(True)
        
    def on_finished(self):
        self.status_label.setText("Status: Stopped")
        self.status_label.setStyleSheet("font-size: 14px; font-weight: bold; color: #FF4444;")
        self.btn_start.setEnabled(True)
        self.btn_stop.setEnabled(False)
        self.btn_web.setEnabled(False)
        self.process = None

    def open_web(self):
        port = self.port_edit.text()
        QDesktopServices.openUrl(QUrl(f"http://localhost:{port}"))

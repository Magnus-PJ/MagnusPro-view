from PyQt6.QtWidgets import QDialog, QVBoxLayout, QTableWidget, QTableWidgetItem, QHeaderView, QLineEdit
from PyQt6.QtCore import Qt

class DicomTagsDialog(QDialog):
    def __init__(self, dataset, parent=None):
        super().__init__(parent)
        self.setWindowTitle("DICOM Tags")
        self.resize(600, 800)
        self.dataset = dataset
        
        layout = QVBoxLayout(self)
        
        # Search Bar
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Search tags...")
        self.search_input.textChanged.connect(self.filter_tags)
        layout.addWidget(self.search_input)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(4)
        self.table.setHorizontalHeaderLabels(["Tag", "Name", "VR", "Value"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table)
        
        self.populate_table()

    def populate_table(self):
        self.table.setRowCount(0)
        if not self.dataset:
            return
            
        for elem in self.dataset:
            if elem.tag.group == 0x7FE0: # Skip Pixel Data
                continue
                
            row = self.table.rowCount()
            self.table.insertRow(row)
            
            # Tag
            tag_str = f"{elem.tag.group:04X},{elem.tag.element:04X}"
            self.table.setItem(row, 0, QTableWidgetItem(tag_str))
            
            # Name
            self.table.setItem(row, 1, QTableWidgetItem(elem.name))
            
            # VR
            self.table.setItem(row, 2, QTableWidgetItem(elem.VR))
            
            # Value
            val_str = str(elem.value)
            if len(val_str) > 100: val_str = val_str[:100] + "..."
            self.table.setItem(row, 3, QTableWidgetItem(val_str))

    def filter_tags(self, text):
        text = text.lower()
        for i in range(self.table.rowCount()):
            match = False
            for j in range(4):
                item = self.table.item(i, j)
                if item and text in item.text().lower():
                    match = True
                    break
            self.table.setRowHidden(i, not match)

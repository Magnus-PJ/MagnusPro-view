from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QLabel, QLineEdit, QPushButton, 
                             QMessageBox, QFrame)
from PyQt6.QtCore import Qt
from ..utils.session_manager import SessionManager

class LoginDialog(QDialog):
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        self.setWindowTitle("MagnusPro Login")
        self.setFixedSize(400, 300)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        
        # Style
        self.setStyleSheet("""
            QDialog {
                background-color: #121212;
                border: 1px solid #4488FF;
            }
            QLabel {
                color: #e0e0e0;
                font-size: 14px;
            }
            QLineEdit {
                background-color: #252525;
                color: white;
                border: 1px solid #333;
                padding: 10px;
                border-radius: 4px;
                font-size: 14px;
            }
            QLineEdit:focus {
                border: 1px solid #4488FF;
            }
            QPushButton {
                background-color: #4488FF;
                color: white;
                border: none;
                padding: 12px;
                border-radius: 4px;
                font-weight: bold;
                font-size: 14px;
            }
            QPushButton:hover {
                background-color: #3377EE;
            }
            QPushButton#cancel {
                background-color: transparent;
                color: #888;
                border: 1px solid #333;
            }
            QPushButton#cancel:hover {
                color: #e0e0e0;
                border: 1px solid #666;
            }
        """)
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(40, 40, 40, 40)
        layout.setSpacing(20)
        
        # Logo / Title
        title = QLabel("MagnusPro RIS/PACS")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("font-size: 24px; font-weight: bold; color: #4488FF; margin-bottom: 20px;")
        layout.addWidget(title)
        
        # Inputs
        self.txt_username = QLineEdit()
        self.txt_username.setPlaceholderText("Username")
        layout.addWidget(self.txt_username)
        
        self.txt_password = QLineEdit()
        self.txt_password.setPlaceholderText("Password")
        self.txt_password.setEchoMode(QLineEdit.EchoMode.Password)
        layout.addWidget(self.txt_password)
        
        # Buttons
        self.btn_login = QPushButton("Login")
        self.btn_login.clicked.connect(self.attempt_login)
        layout.addWidget(self.btn_login)
        
        self.btn_cancel = QPushButton("Exit")
        self.btn_cancel.setObjectName("cancel")
        self.btn_cancel.clicked.connect(self.reject)
        layout.addWidget(self.btn_cancel)
        
    def attempt_login(self):
        username = self.txt_username.text()
        password = self.txt_password.text()
        
        if not username or not password:
            QMessageBox.warning(self, "Login Failed", "Please enter username and password.")
            return
            
        user = self.db_manager.authenticate_user(username, password)
        if user:
            SessionManager().login(user)
            self.db_manager.log_audit(user['id'], "LOGIN", "System", "User logged in")
            self.accept()
        else:
            QMessageBox.critical(self, "Login Failed", "Invalid username or password.")

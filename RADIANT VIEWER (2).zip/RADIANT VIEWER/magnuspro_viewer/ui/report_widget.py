from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QTextEdit, QPushButton, QHBoxLayout, 
                             QLabel, QFileDialog, QMessageBox)
from PyQt6.QtGui import QTextDocument
from PyQt6.QtPrintSupport import QPrinter

class ReportWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        
        layout = QVBoxLayout(self)
        
        # Header
        header_layout = QHBoxLayout()
        self.lbl_study = QLabel("Report for Study: [None]")
        self.lbl_study.setStyleSheet("font-weight: 300; font-size: 16px; color: #4488FF;")
        header_layout.addWidget(self.lbl_study)
        
        # Metadata Badge
        lbl_meta = QLabel("SEO Metadata Active")
        lbl_meta.setStyleSheet("""
            background-color: #1e1e1e; 
            color: #00E676; 
            border: 1px solid #00E676; 
            border-radius: 4px; 
            padding: 2px 6px; 
            font-size: 10px;
        """)
        header_layout.addWidget(lbl_meta)
        header_layout.addStretch()
        
        layout.addLayout(header_layout)
        
        # Editor
        self.editor = QTextEdit()
        self.editor.setPlaceholderText("Type report here...")
        self.editor.setStyleSheet("""
            QTextEdit {
                background-color: #1e1e1e;
                color: #e0e0e0;
                border: 1px solid #333;
                border-radius: 6px;
                font-family: 'Segoe UI', sans-serif;
                font-size: 11pt;
                padding: 10px;
            }
            QTextEdit:focus {
                border: 1px solid #4488FF;
            }
        """)
        layout.addWidget(self.editor)
        
        # Toolbar
        btn_layout = QHBoxLayout()
        
        btn_save_pdf = QPushButton("Export PDF")
        btn_save_pdf.clicked.connect(self.export_pdf)
        btn_layout.addWidget(btn_save_pdf)
        
        btn_clear = QPushButton("Clear")
        btn_clear.clicked.connect(self.editor.clear)
        btn_layout.addWidget(btn_clear)
        
        layout.addLayout(btn_layout)
        
        self.current_study_uid = None

    def set_study(self, study_uid, patient_name):
        self.current_study_uid = study_uid
        self.lbl_study.setText(f"Report for: {patient_name} ({study_uid})")
        self.editor.clear()
        # TODO: Load existing report from DB if exists

    def export_pdf(self):
        if not self.current_study_uid:
            QMessageBox.warning(self, "Error", "No study selected.")
            return
            
        # SEO Friendly Filename
        # TODO: Get patient name and date from somewhere. For now use UID.
        default_name = f"Report_{self.current_study_uid}.pdf"
            
        filename, _ = QFileDialog.getSaveFileName(self, "Export PDF", default_name, "PDF Files (*.pdf)")
        if filename:
            printer = QPrinter(QPrinter.PrinterMode.HighResolution)
            printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
            printer.setOutputFileName(filename)
            
            # Inject Metadata (Basic Qt Support)
            # Qt's QPrinter doesn't expose full XMP, but we can set DocName/Creator
            printer.setDocName(f"Medical Report - {self.current_study_uid}")
            printer.setCreator("MagnusPro View - Premium Workstation")
            
            self.editor.document().print(printer)
            
            # Advanced Metadata Injection (Optional - requires external lib like PyPDF2 or pdfrw)
            # For now, we rely on filename and basic properties.
            
            QMessageBox.information(self, "Success", f"Report saved to {filename}\nMetadata injected.")

from PyQt6.QtWidgets import QWidget, QGridLayout
from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
import vtk

class MPRWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QGridLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(1)
        
        # Create 3 QVTK widgets for Axial, Coronal, Sagittal
        self.view_axial = QVTKRenderWindowInteractor(self)
        self.view_coronal = QVTKRenderWindowInteractor(self)
        self.view_sagittal = QVTKRenderWindowInteractor(self)
        
        self.layout.addWidget(self.view_axial, 0, 0)
        self.layout.addWidget(self.view_coronal, 1, 0)
        self.layout.addWidget(self.view_sagittal, 1, 1)
        
        # 3D View (Optional, placeholder for now)
        self.view_3d = QVTKRenderWindowInteractor(self)
        self.layout.addWidget(self.view_3d, 0, 1)
        
        self.reslice_cursor = None
        self.widgets = []

    def set_image_data(self, image_data):
        if not image_data: return
        
        # Initialize Reslice Cursor
        self.reslice_cursor = vtk.vtkResliceCursor()
        self.reslice_cursor.SetCenter(image_data.GetCenter())
        self.reslice_cursor.SetImage(image_data)
        self.reslice_cursor.SetThickMode(0)
        
        # Create Widgets
        self.widgets = []
        
        # 0: Axial (XY), 1: Coronal (XZ), 2: Sagittal (YZ)
        # Note: vtkResliceCursorWidget expects specific plane orientations
        # Direction: 0=X, 1=Y, 2=Z
        
        self.setup_view(self.view_axial, image_data, 2)
        self.setup_view(self.view_coronal, image_data, 1)
        self.setup_view(self.view_sagittal, image_data, 0)
        
        # Reset cameras
        for w in self.widgets:
            w.GetRenderer().ResetCamera()
            
        # Render
        self.view_axial.GetRenderWindow().Render()
        self.view_coronal.GetRenderWindow().Render()
        self.view_sagittal.GetRenderWindow().Render()

    def setup_view(self, qvtk, image_data, plane_orientation):
        # Renderer
        renderer = vtk.vtkRenderer()
        renderer.SetBackground(0, 0, 0)
        qvtk.GetRenderWindow().AddRenderer(renderer)
        
        # Widget
        widget = vtk.vtkResliceCursorWidget()
        widget.SetInteractor(qvtk.GetRenderWindow().GetInteractor())
        
        # Representation
        rep = vtk.vtkResliceCursorLineRepresentation()
        widget.SetRepresentation(rep)
        
        rep.GetResliceCursorActor().GetCursorAlgorithm().SetResliceCursor(self.reslice_cursor)
        rep.GetResliceCursorActor().GetCursorAlgorithm().SetReslicePlaneNormal(plane_orientation)
        
        widget.SetDefaultRenderer(renderer)
        widget.SetEnabled(1)
        
        # Set Input
        # Note: We need to set the image data to the reslice cursor, which we did.
        # But the representation also needs to know about the image for window/level
        
        reslice = rep.GetReslice()
        reslice.SetInputData(image_data)
        
        # Set default Window/Level
        r = image_data.GetScalarRange()
        rep.SetWindowLevel(r[1] - r[0], 0.5 * (r[1] + r[0]))
        
        # Add to list
        self.widgets.append(widget)
        
        # Initialize Interactor
        qvtk.GetRenderWindow().GetInteractor().Initialize()

from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
                             QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, 
                             QDateEdit, QComboBox, QGroupBox)
from PyQt6.QtCore import Qt, QDate
from .styles import StyleManager

class NetworkDialog(QDialog):
    def __init__(self, dicom_node, db_manager, parent=None):
        super().__init__(parent)
        self.dicom_node = dicom_node
        self.db_manager = db_manager
        self.setWindowTitle("PACS Query / Retrieve")
        self.resize(800, 600)
        self.setStyleSheet(StyleManager.get_stylesheet())
        
        layout = QVBoxLayout(self)
        
        # Search Criteria
        grp_search = QGroupBox("Search Criteria")
        search_layout = QHBoxLayout(grp_search)
        
        # PACS Selector
        self.combo_pacs = QComboBox()
        self.load_pacs_nodes()
        
        self.edit_name = QLineEdit()
        self.edit_name.setPlaceholderText("Patient Name")
        
        self.edit_id = QLineEdit()
        self.edit_id.setPlaceholderText("Patient ID")
        
        self.date_edit = QDateEdit()
        self.date_edit.setDate(QDate.currentDate())
        self.date_edit.setDisplayFormat("yyyyMMdd")
        
        self.combo_modality = QComboBox()
        self.combo_modality.addItems(["*", "CT", "MR", "CR", "US", "XA"])
        
        search_layout.addWidget(QLabel("PACS:"))
        search_layout.addWidget(self.combo_pacs)
        search_layout.addWidget(QLabel("Name:"))
        search_layout.addWidget(self.edit_name)
        search_layout.addWidget(QLabel("ID:"))
        search_layout.addWidget(self.edit_id)
        search_layout.addWidget(QLabel("Date:"))
        search_layout.addWidget(self.date_edit)
        search_layout.addWidget(QLabel("Modality:"))
        search_layout.addWidget(self.combo_modality)
        
        btn_search = QPushButton("Search")
        btn_search.clicked.connect(self.perform_search)
        search_layout.addWidget(btn_search)
        
        layout.addWidget(grp_search)
        
        # Results Table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Patient Name", "Patient ID", "Date", "Modality", "Description", "Study UID"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        layout.addWidget(self.table)
        
        # Actions
        btn_layout = QHBoxLayout()
        self.btn_retrieve = QPushButton("Retrieve Selected")
        self.btn_retrieve.clicked.connect(self.retrieve_study)
        btn_layout.addStretch()
        btn_layout.addWidget(self.btn_retrieve)
        
        layout.addLayout(btn_layout)

    def load_pacs_nodes(self):
        if not self.db_manager: return
        nodes = self.db_manager.get_pacs_nodes()
        for node in nodes:
            # Store full node data in user data
            self.combo_pacs.addItem(f"{node['ae_title']} ({node['ip_address']})", node)

    def perform_search(self):
        if not self.dicom_node:
            return

        node_data = self.combo_pacs.currentData()
        if not node_data:
            print("No PACS selected")
            return

        remote_ae = node_data['ae_title']
        remote_ip = node_data['ip_address']
        remote_port = int(node_data['port'])
        
        criteria = {
            'PatientName': self.edit_name.text() + '*',
            'PatientID': self.edit_id.text() + '*',
            'StudyDate': self.date_edit.text(),
            'Modality': self.combo_modality.currentText()
        }
        
        # Run in thread ideally, but blocking for now
        results = self.dicom_node.find_studies(remote_ae, remote_ip, remote_port, criteria)
        
        self.table.setRowCount(0)
        if results:
            for ds in results:
                row = self.table.rowCount()
                self.table.insertRow(row)
                self.table.setItem(row, 0, QTableWidgetItem(str(ds.get('PatientName', ''))))
                self.table.setItem(row, 1, QTableWidgetItem(str(ds.get('PatientID', ''))))
                self.table.setItem(row, 2, QTableWidgetItem(str(ds.get('StudyDate', ''))))
                self.table.setItem(row, 3, QTableWidgetItem(str(ds.get('Modality', ''))))
                self.table.setItem(row, 4, QTableWidgetItem(str(ds.get('StudyDescription', ''))))
                self.table.setItem(row, 5, QTableWidgetItem(str(ds.get('StudyInstanceUID', ''))))

    def retrieve_study(self):
        if not self.dicom_node: return
        
        row = self.table.currentRow()
        if row < 0: return
        
        study_uid = self.table.item(row, 5).text()
        
        node_data = self.combo_pacs.currentData()
        if not node_data: return

        remote_ae = node_data['ae_title']
        remote_ip = node_data['ip_address']
        remote_port = int(node_data['port'])
        
        from PyQt6.QtWidgets import QMessageBox
        
        success = self.dicom_node.move_study(remote_ae, remote_ip, remote_port, study_uid)
        if success:
            QMessageBox.information(self, "Retrieve", "Retrieve request sent successfully.\nCheck the queue/status.")
        else:
            QMessageBox.critical(self, "Retrieve", "Failed to send C-MOVE request.")

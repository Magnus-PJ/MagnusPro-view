import vtk
from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
from PyQt6.QtWidgets import QWidget, QVBoxLayout
from ..utils.overlay_manager import OverlayManager
from ..vtk_utils.measurements import DistanceTool, AngleTool, ROITool
import os

from PyQt6.QtCore import pyqtSignal

class QVTKRenderWidget(QWidget):
    status_updated = pyqtSignal(str) # Emits status message
    clicked = pyqtSignal() # Emits when widget is clicked
    fps_updated = pyqtSignal(float) # Emits FPS

    def __init__(self, parent=None, overlay_config=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        
        # Create the VTK Interactor
        self.vtkWidget = QVTKRenderWindowInteractor(self)
        self.layout.addWidget(self.vtkWidget)
        
        # Initialize Renderer
        self.renderer = vtk.vtkRenderer()
        self.renderer.SetBackground(0.0, 0.0, 0.0)  # Black background
        self.vtkWidget.GetRenderWindow().AddRenderer(self.renderer)
        
        # Overlays
        self.overlay_manager = None
        if overlay_config and os.path.exists(overlay_config):
            self.overlay_manager = OverlayManager(overlay_config)
            self.overlay_manager.create_actors(self.renderer)
        
        # Initialize Interactor
        self.interactor = self.vtkWidget.GetRenderWindow().GetInteractor()
        
        # Use Custom Interactor Style
        self.style = MagnusInteractorStyle(self)
        self.interactor.SetInteractorStyle(self.style)
        
        self.interactor.Initialize()
        # self.interactor.Start() # Removed for Qt integration

        
        self.image_actor = vtk.vtkImageActor()
        self.renderer.AddActor(self.image_actor)
        
        self.image_data = None
        self.current_slice = 0
        self.extent = None
        self.current_ds = None
        
        # Lookup Table for CLUT
        self.lut = vtk.vtkLookupTable()
        self.lut.SetNumberOfTableValues(256)
        self.lut.Build()
        
        self.setup_scroll_interaction()

        # FPS Tracking
        self.last_render_time = 0
        self.vtkWidget.GetRenderWindow().AddObserver("EndEvent", self.on_render_end)
        import time
        self.time_module = time

        # Measurement Tools
        self.tools = {
            "distance": DistanceTool(self.interactor, self.renderer),
            "angle": AngleTool(self.interactor, self.renderer),
            "roi": ROITool(self.interactor, self.renderer)
        }
        self.active_tool = None

    def on_mouse_move(self, obj, event):
        if not self.image_data: return
        
        pos = self.interactor.GetEventPosition()
        picker = vtk.vtkPropPicker()
        picker.Pick(pos[0], pos[1], 0, self.renderer)
        
        world_pos = picker.GetPickPosition()
        
        # Convert world to image coordinates
        spacing = self.image_data.GetSpacing()
        origin = self.image_data.GetOrigin()
        
        i = int((world_pos[0] - origin[0]) / spacing[0])
        j = int((world_pos[1] - origin[1]) / spacing[1])
        k = self.current_slice
        
        extent = self.image_data.GetExtent()
        if i >= extent[0] and i <= extent[1] and j >= extent[2] and j <= extent[3]:
            # Get scalar value
            hu = self.image_data.GetScalarComponentAsDouble(i, j, k, 0)
            
            # Get WL/Zoom
            prop = self.image_actor.GetProperty()
            level = prop.GetColorLevel()
            window = prop.GetColorWindow()
            zoom = self.renderer.GetActiveCamera().GetParallelScale() # Or similar
            
            msg = f"X: {i} Y: {j} Z: {k} | HU: {int(hu)} | WL: {int(level)} WW: {int(window)}"
            self.status_updated.emit(msg)

    def get_render_window(self):
        return self.vtkWidget.GetRenderWindow()

    def set_image_data(self, image_data):
        self.image_data = image_data
        self.extent = self.image_data.GetExtent()
        
        # Reset filters
        self.flip_filter = None
        self.color_filter = None
        self.current_clut = "Grayscale"
        
        # Set initial slice to middle
        self.current_slice = (self.extent[4] + self.extent[5]) // 2
        
        # Setup Camera
        self.renderer.ResetCamera()
        camera = self.renderer.GetActiveCamera()
        camera.ParallelProjectionOn()
        
        self.update_pipeline()
        self.update_slice()

    def update_pipeline(self):
        if not self.image_data: return
        
        # 1. Source
        current_output = self.image_data
        
        # 2. Flip
        if self.flip_filter:
            self.flip_filter.SetInputData(current_output)
            self.flip_filter.Update()
            current_output = self.flip_filter.GetOutput()
            
        # 3. Color (CLUT)
        if self.current_clut != "Grayscale":
            if not self.color_filter:
                self.color_filter = vtk.vtkImageMapToColors()
            
            # Build LUT if needed
            lut = self.build_lut(self.current_clut)
            self.color_filter.SetLookupTable(lut)
            self.color_filter.SetInputData(current_output)
            self.color_filter.Update()
            current_output = self.color_filter.GetOutput()
        else:
            self.color_filter = None

        # 4. Actor
        self.image_actor.SetInputData(current_output)
        self.vtkWidget.GetRenderWindow().Render()

    def build_lut(self, preset_name):
        lut = vtk.vtkLookupTable()
        lut.SetNumberOfTableValues(256)
        lut.SetRange(0, 255) # Assumes 8-bit display range, might need adjustment for high-bit depth
        
        if preset_name == "Hot Iron":
            lut.SetHueRange(0.0, 0.16)
            lut.SetSaturationRange(1, 1)
            lut.SetValueRange(0.2, 1)
        elif preset_name == "Jet":
            lut.SetHueRange(0.66, 0)
            lut.SetSaturationRange(1, 1)
            lut.SetValueRange(1, 1)
        elif preset_name == "Rainbow":
            lut.SetHueRange(0, 1)
            lut.SetSaturationRange(1, 1)
            lut.SetValueRange(1, 1)
            
        lut.Build()
        return lut

    def update_slice(self):
        if not self.image_data: return
        
        # Clamp slice
        if self.current_slice < self.extent[4]: self.current_slice = self.extent[4]
        if self.current_slice > self.extent[5]: self.current_slice = self.extent[5]
        
        # Update actor display extent
        self.image_actor.SetDisplayExtent(
            self.extent[0], self.extent[1],
            self.extent[2], self.extent[3],
            self.current_slice, self.current_slice
        )
        
        if self.overlay_manager and self.current_ds:
            overrides = {
                "0020,0013": f"{self.current_slice + 1}/{self.extent[5] - self.extent[4] + 1}"
            }
            self.overlay_manager.update_overlays(self.current_ds, overrides)
            
        self.update_ai_layers()
        self.vtkWidget.GetRenderWindow().Render()

    def scroll_slice(self, delta):
        if not self.image_data: return
        self.current_slice += delta
        self.update_slice()

    def set_window_level(self, level, window):
        self.image_actor.GetProperty().SetColorLevel(level)
        self.image_actor.GetProperty().SetColorWindow(window)
        self.vtkWidget.GetRenderWindow().Render()

    def set_zoom(self, scale):
        self.renderer.ResetCamera()
        camera = self.renderer.GetActiveCamera()
        camera.Zoom(scale)
        self.vtkWidget.GetRenderWindow().Render()

    def reset_camera(self):
        self.renderer.ResetCamera()
        self.vtkWidget.GetRenderWindow().Render()

    def update_overlays(self, ds):
        self.current_ds = ds
        if self.overlay_manager:
            self.overlay_manager.update_overlays(ds)
            self.vtkWidget.GetRenderWindow().Render()

    def enable_measurement(self, tool_type="Length"):
        # Disable all first
        if hasattr(self, 'distance_widget'): self.distance_widget.Off()
        if hasattr(self, 'angle_widget'): self.angle_widget.Off()
        if hasattr(self, 'bidim_widget'): self.bidim_widget.Off()
        
        if tool_type == "None":
            return

        if tool_type == "Length":
            if not hasattr(self, 'distance_widget'):
                self.distance_widget = vtk.vtkDistanceWidget()
                self.distance_widget.SetInteractor(self.interactor)
                self.distance_widget.CreateDefaultRepresentation()
            self.distance_widget.On()
            
        elif tool_type == "Angle":
            if not hasattr(self, 'angle_widget'):
                self.angle_widget = vtk.vtkAngleWidget()
                self.angle_widget.SetInteractor(self.interactor)
                self.angle_widget.CreateDefaultRepresentation()
            self.angle_widget.On()
            
        elif tool_type == "Ellipse": # Using BiDimensional as proxy for Ellipse/ROI dimensions
            if not hasattr(self, 'bidim_widget'):
                self.bidim_widget = vtk.vtkBiDimensionalWidget()
                self.bidim_widget.SetInteractor(self.interactor)
                self.bidim_widget.CreateDefaultRepresentation()
                
                # Add observer for interaction end
                self.bidim_widget.AddObserver(vtk.vtkCommand.EndInteractionEvent, self.compute_roi_stats)
                
            self.bidim_widget.On()

    def compute_roi_stats(self, obj, event):
        # This is a simplified ROI stat calculation
        # In a real implementation, we would use vtkExtractVOI or similar based on the widget's bounds
        # For BiDimensional, we get the bounds and compute stats for the rectangular region
        
        if not self.image_data: return
        
        rep = obj.GetRepresentation()
        p1 = rep.GetPoint1Representation().GetWorldPosition()
        p2 = rep.GetPoint2Representation().GetWorldPosition()
        p3 = rep.GetPoint3Representation().GetWorldPosition()
        p4 = rep.GetPoint4Representation().GetWorldPosition()
        
        # Calculate bounds (approximate rectangle)
        xs = [p1[0], p2[0], p3[0], p4[0]]
        ys = [p1[1], p2[1], p3[1], p4[1]]
        
        min_x, max_x = min(xs), max(xs)
        min_y, max_y = min(ys), max(ys)
        
        # Convert to image coordinates
        spacing = self.image_data.GetSpacing()
        origin = self.image_data.GetOrigin()
        
        # Assuming axial slice for now
        i_min = int((min_x - origin[0]) / spacing[0])
        i_max = int((max_x - origin[0]) / spacing[0])
        j_min = int((min_y - origin[1]) / spacing[1])
        j_max = int((max_y - origin[1]) / spacing[1])
        k = self.current_slice
        
        # Clamp
        extent = self.image_data.GetExtent()
        i_min = max(extent[0], i_min)
        i_max = min(extent[1], i_max)
        j_min = max(extent[2], j_min)
        j_max = min(extent[3], j_max)
        
        if i_min >= i_max or j_min >= j_max:
            return
            
        # Extract VOI
        extract = vtk.vtkExtractVOI()
        extract.SetInputData(self.image_data)
        extract.SetVOI(i_min, i_max, j_min, j_max, k, k)
        extract.Update()
        
        # Compute Stats
        stats = vtk.vtkImageAccumulate()
        stats.SetInputData(extract.GetOutput())
        stats.Update()
        
        mean_val = stats.GetMean()[0]
        std_val = stats.GetStandardDeviation()[0]
        min_val = stats.GetMin()[0]
        max_val = stats.GetMax()[0]
        
        # Display stats (using status bar or overlay)
        # For now, print to console/status
        msg = f"ROI Stats: Mean={mean_val:.2f}, StdDev={std_val:.2f}, Min={min_val}, Max={max_val}"
        print(msg)
        
        # Update overlay if possible
        if self.overlay_manager:
            self.overlay_manager.set_roi_stats(msg)

    def export_image(self, file_path):
        window_to_image = vtk.vtkWindowToImageFilter()
        window_to_image.SetInput(self.vtkWidget.GetRenderWindow())
        window_to_image.Update()
        
        if file_path.lower().endswith('.jpg') or file_path.lower().endswith('.jpeg'):
            writer = vtk.vtkJPEGWriter()
        else:
            writer = vtk.vtkPNGWriter()
            
        writer.SetFileName(file_path)
        writer.SetInputConnection(window_to_image.GetOutputPort())
        writer.Write()

    def apply_flip(self, axis):
        if not self.image_data: return
        
        # Chain flips? For now, let's just create a new flip filter or update existing
        # If we want cumulative flips, we need a list of filters. 
        # For simplicity, let's assume one flip state for now, or just add to chain.
        # Let's just toggle flip on axis.
        
        if not self.flip_filter:
            self.flip_filter = vtk.vtkImageFlip()
            self.flip_filter.SetFilteredAxis(axis)
        else:
            # If already flipping, what do we do?
            # If same axis, remove flip?
            if self.flip_filter.GetFilteredAxis() == axis:
                self.flip_filter = None # Toggle off
            else:
                self.flip_filter.SetFilteredAxis(axis)
                
        self.update_pipeline()

    def apply_rotate(self, angle):
        cam = self.renderer.GetActiveCamera()
        cam.Roll(angle)
        self.vtkWidget.GetRenderWindow().Render()

    def invert_color(self):
        prop = self.image_actor.GetProperty()
        w = prop.GetColorWindow()
        prop.SetColorWindow(-w)
        self.vtkWidget.GetRenderWindow().Render()

    def set_clut(self, preset_name):
        self.current_clut = preset_name
        self.update_pipeline()

    def get_renderer(self):
        return self.renderer

    def clear_ai_layers(self):
        self.ai_findings = []
        self.update_ai_layers()

    def add_ai_layer(self, findings):
        if not hasattr(self, 'ai_findings'):
            self.ai_findings = []
        self.ai_findings.extend(findings)
        self.update_ai_layers()

    def update_ai_layers(self):
        # Clear existing actors
        if hasattr(self, 'ai_actors'):
            for actor in self.ai_actors:
                self.renderer.RemoveActor(actor)
        self.ai_actors = []
        
        if not hasattr(self, 'ai_findings') or not self.ai_findings:
            self.vtkWidget.GetRenderWindow().Render()
            return

        for item in self.ai_findings:
            # Check if finding belongs to current slice (if slice_index is provided)
            # If slice_index is -1 or missing, show on all slices? Let's assume specific slice for now.
            if "slice_index" in item and item["slice_index"] != self.current_slice:
                continue

            if item["type"] == "bbox":
                points = vtk.vtkPoints()
                lines = vtk.vtkCellArray()
                
                p1, p2 = item["points"]
                x1, y1 = p1
                x2, y2 = p2
                
                z = 0 # On the image plane
                
                # Adjust for image origin/spacing
                if self.image_data:
                    origin = self.image_data.GetOrigin()
                    spacing = self.image_data.GetSpacing()
                    
                    wx1 = origin[0] + x1 * spacing[0]
                    wy1 = origin[1] + y1 * spacing[1]
                    wx2 = origin[0] + x2 * spacing[0]
                    wy2 = origin[1] + y2 * spacing[1]
                    
                    # Create 4 points
                    pid1 = points.InsertNextPoint(wx1, wy1, z + 0.1)
                    pid2 = points.InsertNextPoint(wx2, wy1, z + 0.1)
                    pid3 = points.InsertNextPoint(wx2, wy2, z + 0.1)
                    pid4 = points.InsertNextPoint(wx1, wy2, z + 0.1)
                    
                    # Create lines
                    line = vtk.vtkPolyLine()
                    line.GetPointIds().SetNumberOfIds(5)
                    line.GetPointIds().SetId(0, pid1)
                    line.GetPointIds().SetId(1, pid2)
                    line.GetPointIds().SetId(2, pid3)
                    line.GetPointIds().SetId(3, pid4)
                    line.GetPointIds().SetId(4, pid1) # Close loop
                    
                    lines.InsertNextCell(line)
                    
                    polyData = vtk.vtkPolyData()
                    polyData.SetPoints(points)
                    polyData.SetLines(lines)
                    
                    mapper = vtk.vtkPolyDataMapper()
                    mapper.SetInputData(polyData)
                    
                    actor = vtk.vtkActor()
                    actor.SetMapper(mapper)
                    
                    color = item.get("color", [1.0, 0.0, 0.0])
                    actor.GetProperty().SetColor(color)
                    actor.GetProperty().SetLineWidth(2)
                    
                    self.renderer.AddActor(actor)
                    self.ai_actors.append(actor)
        
        self.vtkWidget.GetRenderWindow().Render()

    def on_render_end(self, obj, event):
        now = self.time_module.time()
        if self.last_render_time > 0:
            diff = now - self.last_render_time
            if diff > 0:
                fps = 1.0 / diff
                self.fps_updated.emit(fps)
        self.last_render_time = now

    def set_tool(self, tool_name):
        if self.active_tool:
            self.tools[self.active_tool].disable()
            self.active_tool = None
            
        if tool_name in self.tools:
            self.tools[tool_name].enable()
            self.active_tool = tool_name

class MagnusInteractorStyle(vtk.vtkInteractorStyleImage):
    def __init__(self, parent=None):
        self.parent = parent
        self.AddObserver("MouseWheelForwardEvent", self.on_mouse_wheel_forward)
        self.AddObserver("MouseWheelBackwardEvent", self.on_mouse_wheel_backward)
        self.AddObserver("LeftButtonPressEvent", self.on_left_button_down)
        self.AddObserver("RightButtonPressEvent", self.on_right_button_down)
        self.AddObserver("MiddleButtonPressEvent", self.on_middle_button_down)

    def on_mouse_wheel_forward(self, obj, event):
        if self.parent:
            self.parent.scroll_slice(1)
            self.parent.status_updated.emit("Scroll: Next Slice")

    def on_mouse_wheel_backward(self, obj, event):
        if self.parent:
            self.parent.scroll_slice(-1)
            self.parent.status_updated.emit("Scroll: Prev Slice")

    def on_left_button_down(self, obj, event):
        if self.parent:
            self.parent.clicked.emit()
        # Left: Window/Level
        self.StartWindowLevel()

    def on_right_button_down(self, obj, event):
        # Right: Zoom (Dolly)
        self.StartDolly()

    def on_middle_button_down(self, obj, event):
        # Middle: Pan
        self.StartPan()

    def on_mouse_move(self, obj, event):
        # Call parent's on_mouse_move for HU display
        if self.parent:
            self.parent.on_mouse_move(obj, event)
        # Forward to superclass for interaction handling (WL, Pan, Zoom)
        self.OnMouseMove()

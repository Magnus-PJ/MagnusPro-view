from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLabel, QPushButton, QHBoxLayout, QFrame
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QIcon

class WelcomeWidget(QWidget):
    open_folder_clicked = pyqtSignal()
    open_file_clicked = pyqtSignal()
    study_browser_clicked = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(20)

        # Logo / Title
        title_label = QLabel("MagnusPro View")
        title_label.setFont(QFont("Arial", 32, QFont.Weight.Bold))
        title_label.setStyleSheet("color: #FFD700;") # Gold
        title_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title_label)

        subtitle_label = QLabel("Advanced DICOM Viewer")
        subtitle_label.setFont(QFont("Arial", 16))
        subtitle_label.setStyleSheet("color: #AAAAAA;")
        subtitle_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(subtitle_label)

        # Separator
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setFrameShadow(QFrame.Shadow.Sunken)
        line.setFixedWidth(400)
        line.setStyleSheet("background-color: #444444;")
        layout.addWidget(line, 0, Qt.AlignmentFlag.AlignCenter)

        # Actions
        btn_layout = QVBoxLayout()
        btn_layout.setSpacing(10)
        
        btn_style = """
            QPushButton {
                background-color: #252525;
                color: #e0e0e0;
                border: 1px solid #444;
                padding: 12px 24px;
                border-radius: 4px;
                font-size: 14px;
                min-width: 220px;
                font-weight: 600;
            }
            QPushButton:hover {
                background-color: #333;
                border: 1px solid #ffd700;
                color: #ffd700;
            }
            QPushButton:pressed {
                background-color: #1a1a1a;
            }
        """

        self.btn_folder = QPushButton("Open DICOM Folder")
        self.btn_folder.setStyleSheet(btn_style)
        self.btn_folder.clicked.connect(self.open_folder_clicked.emit)
        btn_layout.addWidget(self.btn_folder, 0, Qt.AlignmentFlag.AlignCenter)

        self.btn_file = QPushButton("Open DICOM File")
        self.btn_file.setStyleSheet(btn_style)
        self.btn_file.clicked.connect(self.open_file_clicked.emit)
        btn_layout.addWidget(self.btn_file, 0, Qt.AlignmentFlag.AlignCenter)

        self.btn_browser = QPushButton("Study Browser")
        self.btn_browser.setStyleSheet(btn_style)
        self.btn_browser.clicked.connect(self.study_browser_clicked.emit)
        btn_layout.addWidget(self.btn_browser, 0, Qt.AlignmentFlag.AlignCenter)

        layout.addLayout(btn_layout)

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem, 
                             QPushButton, QLabel, QLineEdit, QComboBox, QMessageBox, QHeaderView, QDialog, QFormLayout)
from PyQt6.QtCore import Qt

class UserManagementWidget(QWidget):
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header = QLabel("User Management")
        header.setStyleSheet("font-size: 24px; font-weight: bold; color: #4488FF; margin-bottom: 10px;")
        layout.addWidget(header)
        
        # Toolbar
        toolbar = QHBoxLayout()
        self.btn_add = QPushButton("Add User")
        self.btn_add.clicked.connect(self.add_user)
        self.btn_add.setStyleSheet("background-color: #4488FF; color: white; padding: 8px 16px; border-radius: 4px;")
        
        self.btn_refresh = QPushButton("Refresh")
        self.btn_refresh.clicked.connect(self.load_users)
        
        toolbar.addWidget(self.btn_add)
        toolbar.addWidget(self.btn_refresh)
        toolbar.addStretch()
        layout.addLayout(toolbar)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["ID", "Username", "Full Name", "Role", "Email"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.table)
        
        self.load_users()
        
    def load_users(self):
        conn = self.db_manager.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id, username, full_name, role, email FROM users")
        rows = cursor.fetchall()
        conn.close()
        
        self.table.setRowCount(len(rows))
        for i, row in enumerate(rows):
            self.table.setItem(i, 0, QTableWidgetItem(str(row[0])))
            self.table.setItem(i, 1, QTableWidgetItem(row[1]))
            self.table.setItem(i, 2, QTableWidgetItem(row[2]))
            self.table.setItem(i, 3, QTableWidgetItem(row[3]))
            self.table.setItem(i, 4, QTableWidgetItem(row[4]))
            
    def add_user(self):
        dlg = AddUserDialog(self)
        if dlg.exec():
            data = dlg.get_data()
            success = self.db_manager.create_user(
                data['username'], data['password'], data['role'], data['full_name'], data['email']
            )
            if success:
                QMessageBox.information(self, "Success", "User created successfully.")
                self.load_users()
            else:
                QMessageBox.warning(self, "Error", "Failed to create user. Username might already exist.")

class AddUserDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Add New User")
        self.setFixedSize(400, 300)
        
        layout = QFormLayout(self)
        
        self.txt_username = QLineEdit()
        self.txt_password = QLineEdit()
        self.txt_password.setEchoMode(QLineEdit.EchoMode.Password)
        self.txt_fullname = QLineEdit()
        self.txt_email = QLineEdit()
        
        self.cmb_role = QComboBox()
        self.cmb_role.addItems(["Radiologist", "Technician", "CenterManager", "Admin", "ReferralDoctor"])
        
        layout.addRow("Username:", self.txt_username)
        layout.addRow("Password:", self.txt_password)
        layout.addRow("Full Name:", self.txt_fullname)
        layout.addRow("Email:", self.txt_email)
        layout.addRow("Role:", self.cmb_role)
        
        btn_box = QHBoxLayout()
        btn_save = QPushButton("Save")
        btn_save.clicked.connect(self.accept)
        btn_cancel = QPushButton("Cancel")
        btn_cancel.clicked.connect(self.reject)
        
        btn_box.addWidget(btn_save)
        btn_box.addWidget(btn_cancel)
        layout.addRow(btn_box)
        
    def get_data(self):
        return {
            'username': self.txt_username.text(),
            'password': self.txt_password.text(),
            'full_name': self.txt_fullname.text(),
            'email': self.txt_email.text(),
            'role': self.cmb_role.currentText()
        }

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem, 
                             QPushButton, QLabel, QLineEdit, QHeaderView, QDialog, QFormLayout, QDateEdit, QComboBox, QMessageBox)
from PyQt6.QtCore import Qt, QDate

class PatientRegistryWidget(QWidget):
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header = QLabel("Patient Registry")
        header.setStyleSheet("font-size: 24px; font-weight: bold; color: #4488FF; margin-bottom: 10px;")
        layout.addWidget(header)
        
        # Search & Actions
        toolbar = QHBoxLayout()
        self.txt_search = QLineEdit()
        self.txt_search.setPlaceholderText("Search by Name or UHID...")
        self.txt_search.textChanged.connect(self.load_patients)
        
        self.btn_register = QPushButton("Register New Patient")
        self.btn_register.clicked.connect(self.register_patient)
        self.btn_register.setStyleSheet("background-color: #4488FF; color: white; padding: 8px 16px; border-radius: 4px;")
        
        toolbar.addWidget(self.txt_search)
        toolbar.addWidget(self.btn_register)
        layout.addLayout(toolbar)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["UHID", "Name", "DOB", "Gender", "Contact", "Address"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        layout.addWidget(self.table)
        
        self.load_patients()
        
    def load_patients(self):
        search = self.txt_search.text()
        conn = self.db_manager.get_connection()
        cursor = conn.cursor()
        
        query = "SELECT uhid, name, dob, gender, contact, address FROM patients"
        params = []
        
        if search:
            query += " WHERE name LIKE ? OR uhid LIKE ?"
            params = [f"%{search}%", f"%{search}%"]
            
        cursor.execute(query, params)
        rows = cursor.fetchall()
        conn.close()
        
        self.table.setRowCount(len(rows))
        for i, row in enumerate(rows):
            for j, val in enumerate(row):
                self.table.setItem(i, j, QTableWidgetItem(str(val)))

    def register_patient(self):
        dlg = RegisterPatientDialog(self)
        if dlg.exec():
            data = dlg.get_data()
            # Generate UHID (Simple timestamp based or sequential)
            import time
            uhid = f"P{int(time.time())}"
            
            try:
                conn = self.db_manager.get_connection()
                cursor = conn.cursor()
                cursor.execute("INSERT INTO patients (uhid, name, dob, gender, contact, address) VALUES (?, ?, ?, ?, ?, ?)",
                               (uhid, data['name'], data['dob'], data['gender'], data['contact'], data['address']))
                conn.commit()
                conn.close()
                QMessageBox.information(self, "Success", f"Patient Registered.\nUHID: {uhid}")
                self.load_patients()
            except Exception as e:
                QMessageBox.warning(self, "Error", f"Registration Failed: {e}")

class RegisterPatientDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Register New Patient")
        self.setFixedSize(400, 400)
        
        layout = QFormLayout(self)
        
        self.txt_name = QLineEdit()
        self.date_dob = QDateEdit()
        self.date_dob.setDisplayFormat("yyyy-MM-dd")
        self.date_dob.setDate(QDate.currentDate().addYears(-30))
        
        self.cmb_gender = QComboBox()
        self.cmb_gender.addItems(["Male", "Female", "Other"])
        
        self.txt_contact = QLineEdit()
        self.txt_address = QLineEdit()
        
        layout.addRow("Full Name:", self.txt_name)
        layout.addRow("Date of Birth:", self.date_dob)
        layout.addRow("Gender:", self.cmb_gender)
        layout.addRow("Contact:", self.txt_contact)
        layout.addRow("Address:", self.txt_address)
        
        btn_box = QHBoxLayout()
        btn_save = QPushButton("Register")
        btn_save.clicked.connect(self.accept)
        btn_cancel = QPushButton("Cancel")
        btn_cancel.clicked.connect(self.reject)
        
        btn_box.addWidget(btn_save)
        btn_box.addWidget(btn_cancel)
        layout.addRow(btn_box)
        
    def get_data(self):
        return {
            'name': self.txt_name.text(),
            'dob': self.date_dob.date().toString("yyyy-MM-dd"),
            'gender': self.cmb_gender.currentText(),
            'contact': self.txt_contact.text(),
            'address': self.txt_address.text()
        }

from PyQt6.QtWidgets import QMenu, QMenuBar
from PyQt6.QtGui import QAction

class MainMenu:
    def __init__(self, main_window):
        self.main_window = main_window
        self.menubar = main_window.menuBar()
        self.init_menus()

    def init_menus(self):
        mw = self.main_window
        
        # File Menu
        file_menu = self.menubar.addMenu("&File")
        file_menu.addAction(mw.act_open_folder)
        file_menu.addAction(mw.act_open_file)
        file_menu.addAction(mw.act_open_zip)
        file_menu.addAction(mw.act_add_images)
        file_menu.addSeparator()
        file_menu.addAction(mw.act_export)
        file_menu.addSeparator()
        file_menu.addAction(mw.act_exit)
        
        # View Menu
        view_menu = self.menubar.addMenu("&View")
        view_menu.addAction(mw.act_split_screen)
        view_menu.addAction(mw.act_study_browser)
        
        # Tools Menu
        tools_menu = self.menubar.addMenu("&Tools")
        tools_menu.addAction(mw.act_tags)
        tools_menu.addSeparator()
        tools_menu.addAction(mw.act_options)
        
        # Network Menu
        net_menu = self.menubar.addMenu("&Network")
        act_query = QAction("Query / Retrieve", mw)
        act_query.triggered.connect(mw.show_network_dialog)
        net_menu.addAction(act_query)
        
        # Help Menu
        help_menu = self.menubar.addMenu("&Help")
        help_menu.addAction(mw.act_about)

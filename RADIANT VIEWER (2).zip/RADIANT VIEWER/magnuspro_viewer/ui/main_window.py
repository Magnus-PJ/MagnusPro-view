from PyQt6.QtWidgets import (QMainWindow, QWidget, QHBoxLayout, QVBoxLayout, QToolBar, 
                             QStatusBar, QFileDialog, QProgressBar, QComboBox, QToolButton, QMenu, QMessageBox, QLabel)
from PyQt6.QtGui import QAction, QIcon
from PyQt6.QtCore import Qt, QSize, QTimer
from .render_widget import QVTKRenderWidget
from .thumbnail_widget import ThumbnailWidget
from .volume_renderer import VolumeRenderWidget
from .mpr_widget import MPRWidget
from .settings_dialog import SettingsDialog
from ..dicom.loader import DicomLoader
from ..dicom.series_loader import SeriesLoaderThread
from ..vtk_utils.importer import VTKImporter
from ..utils.options_manager import OptionsManager
from .tags_dialog import DicomTagsDialog
from .styles import StyleManager
from .study_browser import StudyBrowserWidget
from .toolbar import MainToolbar
from .menus import MainMenu
from .menus import MainMenu
from .welcome_widget import WelcomeWidget
from .dashboard_widget import DashboardWidget
from .report_widget import ReportWidget
import os

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("MagnusPro View")
        self.resize(1280, 800)
        
        # Initialize Database Manager
        from ..data.db_manager import DBManager
        self.db_manager = DBManager()
        
        # Apply Dark Theme
        self.setStyleSheet(StyleManager.get_stylesheet())
        
        # Custom Title Bar & Frameless
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)

        # Enable Drag & Drop
        self.setAcceptDrops(True)

        # Central Widget & Root Layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        root_layout = QVBoxLayout(central_widget)
        root_layout.setContentsMargins(0, 0, 0, 0)
        root_layout.setSpacing(0)
        
        # Title Bar
        from .title_bar import TitleBar
        self.title_bar = TitleBar(self)
        root_layout.addWidget(self.title_bar)
        
        # Actions & Menu
        self.create_actions()
        self.menu_bar = self.create_menu_bar()
        # root_layout.addWidget(self.menu_bar) # Move menu bar to content or keep top? 
        # For RIS style, maybe keep standard menu bar at top, but sidebar is main nav.
        root_layout.addWidget(self.menu_bar)
        
        # Toolbar
        self.toolbar = MainToolbar(self)
        root_layout.addWidget(self.toolbar)

        # Main Container (Sidebar + Content)
        main_container = QWidget()
        container_layout = QHBoxLayout(main_container)
        container_layout.setContentsMargins(0, 0, 0, 0)
        container_layout.setSpacing(0)
        root_layout.addWidget(main_container)
        
        # Sidebar
        from .sidebar import SidebarNavigation
        self.sidebar = SidebarNavigation()
        self.sidebar.module_changed.connect(self.on_module_changed)
        container_layout.addWidget(self.sidebar)

        # Content Area (Stack of Widgets)
        self.content_stack = QWidget()
        self.stack_layout = QVBoxLayout(self.content_stack)
        self.stack_layout.setContentsMargins(0, 0, 0, 0)
        container_layout.addWidget(self.content_stack)
        
        # --- Modules ---
        
        # 1. Dashboard
        self.dashboard_widget = DashboardWidget(self.db_manager)
        self.dashboard_widget.open_study_requested.connect(self.load_study_from_db)
        self.stack_layout.addWidget(self.dashboard_widget)
        
        # 2. Viewer (Grid + Thumbnails + Tools)
        self.viewer_container = QWidget()
        viewer_layout = QHBoxLayout(self.viewer_container)
        viewer_layout.setContentsMargins(0, 0, 0, 0)
        
        self.thumbnail_panel = ThumbnailWidget()
        self.thumbnail_panel.setFixedWidth(220)
        viewer_layout.addWidget(self.thumbnail_panel)
        
        config_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../config/overlay.xml'))
        from .viewport_grid import ViewportGrid
        self.viewport_grid = ViewportGrid(config_path)
        viewer_layout.addWidget(self.viewport_grid)
        
        self.stack_layout.addWidget(self.viewer_container)
        
        # 3. Report
        self.report_widget = ReportWidget()
        self.stack_layout.addWidget(self.report_widget)
        
        # 4. Other Widgets (Volume, MPR) - These are part of Viewer really, but for now keep as separate widgets or integrate into viewer_container?
        # Existing logic treats them as separate screens replacing the grid.
        # Let's add them to stack for now.
        self.volume_widget = VolumeRenderWidget()
        self.stack_layout.addWidget(self.volume_widget)
        
        self.mpr_widget = MPRWidget()
        self.stack_layout.addWidget(self.mpr_widget)
        
        # 5. Admin Modules
        from .admin.user_management import UserManagementWidget
        self.user_mgmt_widget = UserManagementWidget(self.db_manager)
        self.stack_layout.addWidget(self.user_mgmt_widget)
        
        from .admin.patient_registry import PatientRegistryWidget
        self.patient_registry = PatientRegistryWidget(self.db_manager)
        self.stack_layout.addWidget(self.patient_registry)
        
        # 6. Worklist
        from .worklist_widget import WorklistWidget
        self.worklist_widget = WorklistWidget(self.db_manager)
        self.stack_layout.addWidget(self.worklist_widget)
        
        # 7. Developer Mode
        from .developer_dashboard import DeveloperDashboard
        self.dev_dashboard = DeveloperDashboard(self.db_manager)
        self.stack_layout.addWidget(self.dev_dashboard)
        self.dev_dashboard.hide()

        # Initial State
        self.hide_all_modules()
        self.dashboard_widget.show()
        
        # System Audit & Tier Check
        self.perform_system_audit()
        
        # Check Login
        QTimer.singleShot(100, self.check_login)

    def perform_system_audit(self):
        try:
            # Add tools to path
            sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../tools')))
            from system_auditor import SystemAuditor
            auditor = SystemAuditor()
            result = auditor.audit()
            
            tier = result['recommended_tier']
            self.statusBar().showMessage(f"System Tier: {tier}")
            
            # Store in SessionManager (or a new Config/Entitlement Manager)
            from ..utils.session_manager import SessionManager
            SessionManager().system_tier = tier
            
            # Apply Degradation
            if tier == "Lite":
                self.volume_widget.setEnabled(False)
                self.mpr_widget.setEnabled(False)
                # Hide Sidebar buttons for advanced features?
                # For now just disable widgets
                
        except Exception as e:
            print(f"Audit failed: {e}")
            from ..utils.session_manager import SessionManager
            SessionManager().system_tier = "Pro" # Default fallback

    def check_login(self):
        from .login_dialog import LoginDialog
        from ..utils.session_manager import SessionManager
        from .styles import StyleManager
        
        dlg = LoginDialog(self.db_manager, self)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            user = SessionManager().get_current_user()
            self.statusBar().showMessage(f"Logged in as: {user['username']} ({user['role']})")
            
            # Apply Role-Based Theme
            theme = StyleManager.get_stylesheet(user['role'])
            self.setStyleSheet(theme)
            
            # Show Dashboard
            self.on_module_changed("dashboard")
        else:
            sys.exit(0)

    def hide_all_modules(self):
        self.dashboard_widget.hide()
        self.viewer_container.hide()
        self.report_widget.hide()
        self.volume_widget.hide()
        self.mpr_widget.hide()
        self.user_mgmt_widget.hide()
        self.patient_registry.hide()
        self.worklist_widget.hide()
        self.dev_dashboard.hide()

    def on_module_changed(self, module_id):
        self.hide_all_modules()
        
        if module_id == "dashboard":
            self.dashboard_widget.show()
        elif module_id == "viewer":
            self.viewer_container.show()
        elif module_id == "reporting":
            self.report_widget.show()
        elif module_id == "worklist":
            self.worklist_widget.show()
        elif module_id == "patients":
            self.patient_registry.show()
        elif module_id == "settings": 
            # Check role
            from ..utils.session_manager import SessionManager
            role = SessionManager().get_role()
            if role == "SuperAdmin":
                self.dev_dashboard.show() # God Mode for SuperAdmin
            elif role == "Admin":
                self.user_mgmt_widget.show()
            else:
                self.show_options()
        elif module_id == "logout":
            # Restart or re-login
            self.check_login()
        # Add others...
        
        # Initial State: Show Dashboard
        self.viewport_grid.hide()
        self.thumbnail_panel.hide()

        # Options
        options_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../config/options.xml'))
        self.options_manager = OptionsManager(options_path)
        self.progress_bar.hide()
        self.statusBar().addPermanentWidget(self.progress_bar)
        self.statusBar().showMessage("Ready")
        
        # State
        self.loader = None
        self.series_loader = None
        self.loaded_series = {} 

        # Cine Timer
        self.cine_timer = QTimer()
        self.cine_timer.timeout.connect(self.advance_slice)
        
        # Connect signals
        self.thumbnail_panel.series_selected.connect(self.load_series)
        self.viewport_grid.active_viewport_changed.connect(self.on_active_viewport_changed)

        # Initialize PACS Node
        self.dicom_node = None
        self.restart_dicom_node()

    @property
    def render_widget(self):
        return self.viewport_grid.get_active_viewport()
        
    def on_active_viewport_changed(self, viewport):
        # Update UI state based on active viewport if needed
        # Connect status signal
        try:
            viewport.status_updated.disconnect()
        except:
            pass
        viewport.status_updated.connect(self.statusBar().showMessage)
        viewport.fps_updated.connect(self.on_fps_updated)

    def on_fps_updated(self, fps):
        # We can add a permanent widget for FPS or just append to status
        # Let's use a dedicated label if possible, or just format the message
        current = self.statusBar().currentMessage()
        # Avoid flickering by only updating if significant change or interval?
        # For now, let's just show it.
        # self.statusBar().showMessage(f"{current} | FPS: {fps:.1f}")
        # Better: Update a permanent widget
        if not hasattr(self, 'fps_label'):
            self.fps_label = QLabel("FPS: 0")
            self.statusBar().addPermanentWidget(self.fps_label)
        self.fps_label.setText(f"FPS: {fps:.1f}")

    def restart_dicom_node(self):
        if self.dicom_node:
            self.dicom_node.stop_scp()
            self.dicom_node = None
            
        try:
            from ..net.dicom_node import DicomNode
            ae_title = self.db_manager.get_setting("local_ae_title", "MAGNUS_PRO")
            port = int(self.db_manager.get_setting("local_port", "11112"))
            
            self.dicom_node = DicomNode(ae_title=ae_title, port=port, db_manager=self.db_manager)
            self.dicom_node.start_scp()
            print(f"DICOM Node started on port {port} with AE Title {ae_title}")
        except ImportError:
            self.statusBar().showMessage("PACS features disabled (pynetdicom not installed).")
        except Exception as e:
            self.statusBar().showMessage(f"PACS Error: {e}")

    def handle_send_study(self, study_uid, node_data):
        if not self.dicom_node:
            QMessageBox.warning(self, "Error", "DICOM Node is not running.")
            return
            
        remote_ae = node_data['ae_title']
        remote_ip = node_data['ip_address']
        remote_port = int(node_data['port'])
        
        self.statusBar().showMessage(f"Sending study {study_uid} to {remote_ae}...")
        
        success = self.dicom_node.send_study(remote_ae, remote_ip, remote_port, study_uid)
        
        if success:
            self.statusBar().showMessage("Study sent successfully.", 5000)
            QMessageBox.information(self, "Success", f"Study sent to {remote_ae}.")
        else:
            self.statusBar().showMessage("Failed to send study.", 5000)
            QMessageBox.critical(self, "Error", "Failed to send study. Check logs.")

    def create_actions(self):
        # File
        self.act_open_folder = QAction("Open DICOM folder", self)
        self.act_open_folder.setShortcut("Ctrl+Shift+O")
        self.act_open_folder.triggered.connect(self.open_folder)
        
        self.act_open_file = QAction("Open DICOM file", self)
        self.act_open_file.setShortcut("Ctrl+O")
        self.act_open_file.triggered.connect(self.open_file)
        
        self.act_open_zip = QAction("Open ZIP file", self)
        self.act_open_zip.setEnabled(False)
        
        self.act_add_images = QAction("Add DICOM images", self)
        self.act_add_images.setEnabled(False)
        
        self.act_export = QAction("Export Image...", self)
        self.act_export.triggered.connect(self.export_image)
        
        self.act_exit = QAction("Exit", self)
        self.act_exit.triggered.connect(self.close)

        # View
        self.act_split_screen = QAction("Split Screen", self)
        self.act_split_screen.setEnabled(False)

        # Tools
        self.act_tags = QAction("DICOM Tags...", self)
        self.act_tags.triggered.connect(self.show_tags)
        
        self.act_options = QAction("Options...", self)
        self.act_options.setShortcut("F2")
        self.act_options.triggered.connect(self.show_options)
        
        self.act_study_browser = QAction("Study Browser", self)
        self.act_study_browser.setShortcut("Ctrl+B")
        self.act_study_browser = QAction("Study Browser", self)
        self.act_study_browser.setShortcut("Ctrl+B")
        self.act_study_browser.triggered.connect(self.show_study_browser)

        self.act_report = QAction("Create Report", self)
        self.act_report.triggered.connect(self.show_report)

        # Help
        self.act_about = QAction("About", self)
        self.act_about.triggered.connect(lambda: QMessageBox.about(self, "About", "MagnusPro View v1.0"))
        
        self.act_shortcuts = QAction("Keyboard Shortcuts", self)
        self.act_shortcuts.triggered.connect(self.show_shortcuts)

        self.act_update = QAction("Check for Updates", self)
        self.act_update.triggered.connect(self.check_updates)

        # Cine
        self.action_play = QAction("Cine", self)
        self.action_play.setCheckable(True)
        self.action_play.triggered.connect(self.toggle_play)

        # AI Simulation
        self.act_simulate_ai = QAction("Simulate AI Analysis", self)
        self.act_simulate_ai.triggered.connect(self.simulate_ai)

    def create_menu_bar(self):
        from PyQt6.QtWidgets import QMenuBar
        menu_bar = QMenuBar()
        
        # File Menu
        file_menu = menu_bar.addMenu("File")
        file_menu.addAction(self.act_open_folder)
        file_menu.addAction(self.act_open_file)
        file_menu.addSeparator()
        file_menu.addAction(self.act_exit)
        
        # View Menu
        view_menu = menu_bar.addMenu("View")
        
        # Layouts
        layout_menu = view_menu.addMenu("Layout")
        layout_1x1 = QAction("1x1", self)
        layout_1x1.triggered.connect(lambda: self.viewport_grid.set_layout(1, 1))
        layout_menu.addAction(layout_1x1)
        
        layout_1x2 = QAction("1x2", self)
        layout_1x2.triggered.connect(lambda: self.viewport_grid.set_layout(1, 2))
        layout_menu.addAction(layout_1x2)
        
        layout_2x1 = QAction("2x1", self)
        layout_2x1.triggered.connect(lambda: self.viewport_grid.set_layout(2, 1))
        layout_menu.addAction(layout_2x1)
        
        layout_2x2 = QAction("2x2", self)
        layout_2x2.triggered.connect(lambda: self.viewport_grid.set_layout(2, 2))
        layout_menu.addAction(layout_2x2)
        
        # Tools Menu
        tools_menu = menu_bar.addMenu("Tools")
        tools_menu.addAction(self.act_tags)
        tools_menu.addAction(self.act_study_browser)
        tools_menu.addAction(self.act_report)
        tools_menu.addSeparator()
        tools_menu.addAction(self.act_simulate_ai)
        tools_menu.addSeparator()
        tools_menu.addAction(self.act_options)
        
        # Network Menu
        net_menu = menu_bar.addMenu("Network")
        act_query = QAction("Query / Retrieve", self)
        act_query.triggered.connect(self.show_network_dialog)
        net_menu.addAction(act_query)
        
        act_orthanc = QAction("Local Orthanc Server", self)
        act_orthanc.triggered.connect(self.show_orthanc_dialog)
        net_menu.addAction(act_orthanc)
        
        # Help Menu
        help_menu = menu_bar.addMenu("Help")
        help_menu.addAction(self.act_shortcuts)
        help_menu.addAction(self.act_update)
        help_menu.addSeparator()
        help_menu.addAction(self.act_about)
        
        return menu_bar

    def show_shortcuts(self):
        from .shortcuts_dialog import ShortcutsDialog
        dialog = ShortcutsDialog(self)
        dialog.exec()

    def export_image(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Save Image", "", "Images (*.png *.jpg)")
        if file_path:
            self.render_widget.export_image(file_path)
            self.statusBar().showMessage(f"Saved to {file_path}")

    def show_tags(self):
        if self.loaded_series:
            ds = getattr(self.render_widget, 'current_ds', None)
            if ds:
                dialog = DicomTagsDialog(ds, self)
                dialog.exec()
            else:
                self.statusBar().showMessage("No image loaded.")

    def show_options(self):
        dialog = SettingsDialog(self, self.db_manager, self.dicom_node)
        if dialog.exec():
            self.restart_dicom_node()

    def show_network_dialog(self):
        if self.dicom_node:
            from .network_dialog import NetworkDialog
            dlg = NetworkDialog(self.dicom_node, self.db_manager, self)
            dlg.exec()
        else:
            self.statusBar().showMessage("PACS features not available (pynetdicom missing).")

    def show_orthanc_dialog(self):
        from .orthanc_dialog import OrthancDialog
        dlg = OrthancDialog(self)
        dlg.exec()

    def show_study_browser(self):
        from PyQt6.QtWidgets import QDialog
        dlg = QDialog(self)
        dlg.setWindowTitle("Study Browser")
        dlg.resize(800, 600)
        layout = QVBoxLayout(dlg)
        browser = StudyBrowserWidget(self.db_manager)
        browser.study_selected.connect(lambda uid: [self.load_study_from_db(uid), dlg.accept()])
        browser.send_requested.connect(self.handle_send_study)
        layout.addWidget(browser)
        dlg.exec()

    def check_updates(self):
        from ..utils.update_manager import UpdateManager
        self.statusBar().showMessage("Checking for updates...")
        self.update_manager = UpdateManager()
        self.update_manager.check_for_updates(self.on_update_checked)

    def on_update_checked(self, data):
        if "error" in data:
            self.statusBar().showMessage(f"Update check failed: {data['error']}")
            QMessageBox.warning(self, "Update Check", f"Failed to check for updates.\n{data['error']}")
        else:
            latest = data.get("version", "Unknown")
            self.statusBar().showMessage(f"Latest version: {latest}")
            QMessageBox.information(self, "Update Check", f"You are running v1.0.0.\nLatest version is {latest}.")

    def show_report(self):
        # Switch to Report View
        self.dashboard_widget.hide()
        self.viewport_grid.hide()
        self.volume_widget.hide()
        self.mpr_widget.hide()
        self.thumbnail_panel.hide()
        self.report_widget.show()
        
        # If a study is loaded, set it
        if self.loaded_series:
            # Get first series to find study info
            first_series = next(iter(self.loaded_series.values()))
            # We don't have easy access to study UID here unless we store it.
            pass

    def load_study_from_db(self, study_uid):
        self.statusBar().showMessage(f"Loading study {study_uid}...")
        
        # Switch to Viewer Module
        self.sidebar.buttons["viewer"].click()
        
        # Audit Log
        from ..utils.audit import log_access
        # log_access("local_user", "OPEN", study_uid, "Opened from Database")
        
        # UI State Update
        # self.dashboard_widget.hide() # Handled by sidebar
        # self.report_widget.hide()
        # self.thumbnail_panel.show()
        # self.viewport_grid.show()
        
        # Clear thumbnails
        while self.thumbnail_panel.scroll_layout.count():
            child = self.thumbnail_panel.scroll_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        
        self.loaded_series = {}
        
        series_list = self.db_manager.get_series_for_study(study_uid)
        
        from ..dicom.loader import DicomSeries
        
        for s_row in series_list:
            series_uid = s_row['series_uid']
            modality = s_row['modality']
            desc = s_row['description']
            
            series = DicomSeries(series_uid)
            series.modality = modality
            series.description = desc
            series.series_number = s_row['series_number']
            
            instances = self.db_manager.get_instances_for_series(series_uid)
            for i_row in instances:
                # If we have z_position in DB, we should use it.
                # Currently DicomSeries.add_file takes z_pos.
                # We need to update DicomSeries to accept it.
                # For now, let's assume DicomSeries logic handles it or we pass it.
                z_pos = i_row['z_position'] if 'z_position' in i_row.keys() else None
                series.add_file(i_row['file_path'], i_row['instance_number'], z_pos)
            
            self.on_series_found(series)
            
        self.statusBar().showMessage("Study loaded from database.")

    def toggle_play(self, checked):
        if checked:
            self.action_play.setText("Pause")
            self.cine_timer.start(100) # 10 FPS
        else:
            self.action_play.setText("Cine")
            self.cine_timer.stop()

    def advance_slice(self):
        rw = self.render_widget
        if not rw or not rw.image_data:
            return
            
        # Check if we are at the end
        if rw.current_slice >= rw.extent[5]:
            # Loop back to start
            rw.current_slice = rw.extent[4]
            rw.update_slice()
        else:
            rw.scroll_slice(1)

    def open_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Open DICOM Folder")
        if folder:
            self.load_folder(folder)

    def open_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Open DICOM File", "", "DICOM Files (*.dcm);;All Files (*)")
        if file_path:
            self.load_folder(os.path.dirname(file_path))

    def on_series_found(self, series):
        self.loaded_series[series.uid] = series
        thumb = getattr(series, 'thumbnail', None)
        
        info = {
            'modality': series.modality,
            'series_number': series.series_number,
            'image_count': len(series.files),
            'description': series.description
        }
        
        self.thumbnail_panel.add_series(series.uid, info, thumb)

    def load_series(self, series_uid):
        series = self.loaded_series.get(series_uid)
        if not series:
            return
            
        self.statusBar().showMessage(f"Loading series {series.description}...")
        self.progress_bar.setValue(0)
        self.progress_bar.show()
        
        files = series.get_sorted_files()
        if not files:
            return

        if self.series_loader and self.series_loader.isRunning():
            self.series_loader.terminate()
            self.series_loader.wait()

        self.series_loader = SeriesLoaderThread(files)
        self.series_loader.progress.connect(self.progress_bar.setValue)
        self.series_loader.finished.connect(lambda vol, ds: self.on_series_loaded(vol, ds, len(files)))
        self.series_loader.error.connect(self.on_load_error)
        self.series_loader.start()

    def on_series_loaded(self, volume, first_ds, count):
        self.progress_bar.hide()
        self.statusBar().showMessage(f"Processing {count} images...")
        
        try:
            spacing = first_ds.get("PixelSpacing", [1.0, 1.0])
            thickness = first_ds.get("SliceThickness", 1.0)
            vtk_spacing = (float(spacing[0]), float(spacing[1]), float(thickness))
            
            # Extract Orientation
            orientation = first_ds.get("ImageOrientationPatient", None)
            if orientation:
                orientation = [float(x) for x in orientation]

            vtk_image = VTKImporter.numpy_to_vtk_image(volume, spacing=vtk_spacing, orientation=orientation)
            
            self.render_widget.set_image_data(vtk_image)
            self.render_widget.update_overlays(first_ds)
            self.volume_widget.set_image_data(vtk_image)
            self.mpr_widget.set_image_data(vtk_image)
            self.statusBar().showMessage(f"Loaded {count} images.")
            
        except Exception as e:
            self.on_load_error(str(e))

    def on_load_error(self, error_msg):
        self.progress_bar.hide()
        self.statusBar().showMessage(f"Error: {error_msg}")
        print(error_msg)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.accept()
        else:
            event.ignore()

    def dropEvent(self, event):
        urls = event.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            self.load_path(path)

    def load_path(self, path):
        if os.path.isdir(path):
            self.load_folder(path)
        elif os.path.isfile(path):
            self.load_folder(os.path.dirname(path))

    def load_folder(self, folder):
        self.statusBar().showMessage(f"Scanning {folder}...")
        
        # Switch to Viewer Module
        self.sidebar.buttons["viewer"].click()
        
        # Clear thumbnails
        while self.thumbnail_panel.scroll_layout.count():
            child = self.thumbnail_panel.scroll_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
        
        self.loaded_series = {}
        
        self.loader = DicomLoader(folder, self.db_manager)
        self.loader.series_found.connect(self.on_series_found)
        self.loader.finished_scanning.connect(lambda: self.statusBar().showMessage("Ready"))
        self.loader.start()

    def toggle_mpr(self):
        if self.mpr_widget.isVisible():
            self.mpr_widget.hide()
            self.render_widget.show()
        else:
            self.render_widget.hide()
            self.volume_widget.hide()
            self.mpr_widget.show()
            # Sync data if needed
            if hasattr(self.render_widget, 'image_data'):
                self.mpr_widget.set_image_data(self.render_widget.image_data)

    def toggle_3d(self):
        if self.volume_widget.isVisible():
            self.volume_widget.hide()
            self.render_widget.show()
        else:
            self.render_widget.hide()
            self.mpr_widget.hide()
            self.volume_widget.show()
            # Sync data if needed
            if hasattr(self.render_widget, 'image_data'):
                self.volume_widget.set_image_data(self.render_widget.image_data)

    def keyPressEvent(self, event):
        key = event.key()
        
        if key == Qt.Key.Key_Up or key == Qt.Key.Key_Right:
            self.render_widget.scroll_slice(1)
        elif key == Qt.Key.Key_Down or key == Qt.Key.Key_Left:
            self.render_widget.scroll_slice(-1)
        elif key == Qt.Key.Key_C:
            self.action_play.trigger()
        elif key == Qt.Key.Key_R:
            self.render_widget.reset_camera()
        elif key == Qt.Key.Key_Space:
            if self.mpr_widget.isVisible():
                self.toggle_mpr()
            elif self.volume_widget.isVisible():
                self.toggle_3d()
            else:
                self.toggle_mpr()
        else:
            super().keyPressEvent(event)

    def simulate_ai(self):
        rw = self.render_widget
        if not rw or not rw.image_data:
            self.statusBar().showMessage("No image loaded for AI analysis.")
            return

        self.statusBar().showMessage("Running AI Simulation...")
        
        # Generate mock findings
        import random
        findings = []
        
        # Current slice finding
        current = rw.current_slice
        width, height, _ = rw.image_data.GetDimensions()
        
        # Add a "Nodule" on current slice
        x = width // 2
        y = height // 2
        findings.append({
            "type": "bbox",
            "label": "Nodule",
            "confidence": 0.98,
            "color": [1.0, 0.0, 0.0], # Red
            "slice_index": current,
            "points": [[x - 20, y - 20], [x + 20, y + 20]]
        })
        
        # Add random findings on other slices
        for i in range(5):
            slice_idx = random.randint(rw.extent[4], rw.extent[5])
            rx = random.randint(50, width - 50)
            ry = random.randint(50, height - 50)
            findings.append({
                "type": "bbox",
                "label": "Mass",
                "confidence": random.uniform(0.7, 0.99),
                "color": [1.0, 1.0, 0.0], # Yellow
                "slice_index": slice_idx,
                "points": [[rx - 30, ry - 30], [rx + 30, ry + 30]]
            })
            
        rw.add_ai_layer(findings)
        self.statusBar().showMessage(f"AI Analysis Complete. Found {len(findings)} items.")
        QMessageBox.information(self, "AI Analysis", f"Simulation complete.\nFound {len(findings)} findings.\nCheck current slice and scroll to see others.")

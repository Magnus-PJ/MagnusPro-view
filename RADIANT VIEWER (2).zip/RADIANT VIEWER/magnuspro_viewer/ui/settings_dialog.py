from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, 
                             QPushButton, QTableWidget, QTableWidgetItem, QHeaderView, 
                             QTabWidget, QWidget, QGroupBox, QFormLayout, QInputDialog, QMessageBox,
                             QCheckBox, QFileDialog)
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon
from .styles import StyleManager

class SettingsDialog(QDialog):
    def __init__(self, parent=None, db_manager=None, dicom_node=None):
        super().__init__(parent)
        self.db_manager = db_manager
        self.dicom_node = dicom_node
        self.setWindowTitle("Configuration")
        self.resize(600, 450)
        self.setStyleSheet(StyleManager.get_stylesheet())
        
        layout = QVBoxLayout(self)
        
        self.tabs = QTabWidget()
        layout.addWidget(self.tabs)
        
        # PACS Tab
        self.pacs_tab = QWidget()
        self.setup_pacs_tab()
        self.tabs.addTab(self.pacs_tab, "PACS")
        
        # Security Tab
        self.security_tab = QWidget()
        self.setup_security_tab()
        self.tabs.addTab(self.security_tab, "Security")
        
        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        self.btn_save = QPushButton("Save")
        self.btn_save.clicked.connect(self.save_settings)
        self.btn_cancel = QPushButton("Cancel")
        self.btn_cancel.clicked.connect(self.reject)
        
        btn_layout.addWidget(self.btn_save)
        btn_layout.addWidget(self.btn_cancel)
        layout.addLayout(btn_layout)

        self.load_settings()

    def setup_pacs_tab(self):
        layout = QVBoxLayout(self.pacs_tab)
        
        # Listener Settings
        grp_listener = QGroupBox("My PACS settings")
        form_layout = QHBoxLayout(grp_listener)
        
        self.edit_port = QLineEdit("11112")
        self.edit_port.setFixedWidth(60)
        self.edit_aet = QLineEdit("MAGNUS_PRO")
        
        form_layout.addWidget(QLabel("Listener port:"))
        form_layout.addWidget(self.edit_port)
        form_layout.addSpacing(20)
        form_layout.addWidget(QLabel("My AE title:"))
        form_layout.addWidget(self.edit_aet)
        form_layout.addStretch()
        
        layout.addWidget(grp_listener)
        
        # PACS Locations
        grp_locations = QGroupBox("PACS locations")
        loc_layout = QVBoxLayout(grp_locations)
        
        self.table = QTableWidget()
        self.table.setColumnCount(5)
        self.table.setHorizontalHeaderLabels(["IP address", "Port", "AE title", "Description", "Retrieve"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        
        loc_layout.addWidget(self.table)
        
        # Action Buttons
        action_layout = QHBoxLayout()
        btn_add = QPushButton("Add")
        btn_add.clicked.connect(self.add_pacs)
        btn_del = QPushButton("Delete")
        btn_del.clicked.connect(self.delete_pacs)
        btn_verify = QPushButton("Echo")
        btn_verify.clicked.connect(self.echo_pacs)
        
        action_layout.addWidget(btn_add)
        action_layout.addWidget(btn_del)
        action_layout.addStretch()
        action_layout.addWidget(btn_verify)
        
        loc_layout.addLayout(action_layout)
        
        layout.addWidget(grp_locations)

    def setup_security_tab(self):
        layout = QVBoxLayout(self.security_tab)
        
        # TLS Settings
        grp_tls = QGroupBox("Transport Layer Security (TLS)")
        form_layout = QFormLayout(grp_tls)
        
        self.chk_tls_enabled = QCheckBox("Enable TLS Security")
        form_layout.addRow(self.chk_tls_enabled)
        
        self.edit_cert = QLineEdit()
        btn_cert = QPushButton("Browse...")
        btn_cert.clicked.connect(lambda: self.browse_file(self.edit_cert))
        h_cert = QHBoxLayout()
        h_cert.addWidget(self.edit_cert)
        h_cert.addWidget(btn_cert)
        form_layout.addRow("Certificate File:", h_cert)
        
        self.edit_key = QLineEdit()
        btn_key = QPushButton("Browse...")
        btn_key.clicked.connect(lambda: self.browse_file(self.edit_key))
        h_key = QHBoxLayout()
        h_key.addWidget(self.edit_key)
        h_key.addWidget(btn_key)
        form_layout.addRow("Private Key File:", h_key)
        
        layout.addWidget(grp_tls)
        
        btn_test_tls = QPushButton("Test TLS Configuration")
        btn_test_tls.clicked.connect(self.test_tls)
        layout.addWidget(btn_test_tls)
        
        layout.addStretch()

    def browse_file(self, line_edit):
        file_path, _ = QFileDialog.getOpenFileName(self, "Select File")
        if file_path:
            line_edit.setText(file_path)

    def load_settings(self):
        if not self.db_manager: return
        
        # Load Local Settings
        self.edit_aet.setText(self.db_manager.get_setting("local_ae_title", "MAGNUS_PRO"))
        self.edit_port.setText(self.db_manager.get_setting("local_port", "11112"))
        
        # Load TLS Settings
        from ..utils.config import ConfigManager
        config = ConfigManager()
        self.chk_tls_enabled.setChecked(config.get("tls_enabled", False))
        self.edit_cert.setText(config.get("tls_cert", ""))
        self.edit_key.setText(config.get("tls_key", ""))
        
        # Load PACS Nodes
        self.refresh_pacs_table()

    def refresh_pacs_table(self):
        self.table.setRowCount(0)
        nodes = self.db_manager.get_pacs_nodes()
        for node in nodes:
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(node['ip_address']))
            self.table.setItem(row, 1, QTableWidgetItem(str(node['port'])))
            self.table.setItem(row, 2, QTableWidgetItem(node['ae_title']))
            self.table.setItem(row, 3, QTableWidgetItem(node['description']))
            self.table.setItem(row, 4, QTableWidgetItem(node['protocol']))

    def add_pacs(self):
        # Simple input dialogs for now
        aet, ok = QInputDialog.getText(self, "Add PACS", "AE Title:")
        if not ok or not aet: return
        
        ip, ok = QInputDialog.getText(self, "Add PACS", "IP Address:")
        if not ok or not ip: return
        
        port, ok = QInputDialog.getInt(self, "Add PACS", "Port:", 104, 1, 65535)
        if not ok: return
        
        desc, ok = QInputDialog.getText(self, "Add PACS", "Description:")
        if not ok: return

        if self.db_manager:
            self.db_manager.add_pacs_node(aet, ip, port, desc)
            self.refresh_pacs_table()

    def delete_pacs(self):
        row = self.table.currentRow()
        if row < 0: return
        
        aet = self.table.item(row, 2).text()
        if self.db_manager:
            self.db_manager.delete_pacs_node(aet)
            self.refresh_pacs_table()

    def echo_pacs(self):
        if not self.dicom_node:
            QMessageBox.warning(self, "Echo", "DicomNode is not running.")
            return

        row = self.table.currentRow()
        if row < 0: return
        
        ip = self.table.item(row, 0).text()
        port = int(self.table.item(row, 1).text())
        aet = self.table.item(row, 2).text()
        
        QMessageBox.information(self, "Echo", f"Pinging {aet}@{ip}:{port}...")
        
        status = self.dicom_node.echo(aet, ip, port)
        if status and status.Status == 0x0000:
            QMessageBox.information(self, "Echo", "Success! Connection established.")
        else:
            QMessageBox.critical(self, "Echo", "Failed to connect.")

    def test_tls(self):
        import os
        cert = self.edit_cert.text()
        key = self.edit_key.text()
        
        if not cert or not key:
            QMessageBox.warning(self, "TLS Test", "Please select both certificate and key files.")
            return
            
        if not os.path.exists(cert):
            QMessageBox.critical(self, "TLS Test", f"Certificate file not found:\n{cert}")
            return
            
        if not os.path.exists(key):
            QMessageBox.critical(self, "TLS Test", f"Key file not found:\n{key}")
            return
            
        try:
            # Try to create an SSL context to verify files are valid
            import ssl
            context = ssl.create_default_context(ssl.Purpose.CLIENT_AUTH)
            context.load_cert_chain(certfile=cert, keyfile=key)
            QMessageBox.information(self, "TLS Test", "TLS Configuration is VALID.\nCertificate and Key loaded successfully.")
        except Exception as e:
            QMessageBox.critical(self, "TLS Test", f"TLS Configuration INVALID:\n{e}")

    def save_settings(self):
        if self.db_manager:
            self.db_manager.set_setting("local_ae_title", self.edit_aet.text())
            self.db_manager.set_setting("local_port", self.edit_port.text())
            
        # Save TLS Settings
        from ..utils.config import ConfigManager
        config = ConfigManager()
        config.set("tls_enabled", self.chk_tls_enabled.isChecked())
        config.set("tls_cert", self.edit_cert.text())
        config.set("tls_key", self.edit_key.text())
            
        self.accept()

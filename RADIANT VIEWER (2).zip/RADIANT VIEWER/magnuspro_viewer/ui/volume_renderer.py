import vtk
from vtkmodules.qt.QVTKRenderWindowInteractor import QVTKRenderWindowInteractor
from PyQt6.QtWidgets import QWidget, QVBoxLayout

class VolumeRenderWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        
        self.vtkWidget = QVTKRenderWindowInteractor(self)
        self.layout.addWidget(self.vtkWidget)
        
        self.renderer = vtk.vtkRenderer()
        self.renderer.SetBackground(0.1, 0.1, 0.1)
        self.vtkWidget.GetRenderWindow().AddRenderer(self.renderer)
        
        self.interactor = self.vtkWidget.GetRenderWindow().GetInteractor()
        self.interactor.SetInteractorStyle(vtk.vtkInteractorStyleTrackballCamera())
        self.interactor.Initialize()
        # self.interactor.Start() # Removed for Qt integration
        
        self.volume = None

    def set_image_data(self, image_data):
        if self.volume:
            self.renderer.RemoveVolume(self.volume)
            
        # Mapper
        mapper = vtk.vtkGPUVolumeRayCastMapper()
        mapper.SetInputData(image_data)
        
        # Color Transfer Function
        color_tf = vtk.vtkColorTransferFunction()
        color_tf.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
        color_tf.AddRGBPoint(400, 1.0, 0.5, 0.3) # Bone-ish
        color_tf.AddRGBPoint(1000, 1.0, 1.0, 0.9)
        
        # Opacity Transfer Function
        opacity_tf = vtk.vtkPiecewiseFunction()
        opacity_tf.AddPoint(-1000, 0.0)
        opacity_tf.AddPoint(400, 0.5)
        opacity_tf.AddPoint(1000, 0.9)
        
        # Volume Property
        volume_property = vtk.vtkVolumeProperty()
        volume_property.SetColor(color_tf)
        volume_property.SetScalarOpacity(opacity_tf)
        volume_property.ShadeOn()
        volume_property.SetInterpolationTypeToLinear()
        
        # Volume
        self.volume = vtk.vtkVolume()
        self.volume.SetMapper(mapper)
        self.volume.SetProperty(volume_property)
        
        self.renderer.AddVolume(self.volume)
        self.renderer.ResetCamera()
        self.vtkWidget.GetRenderWindow().Render()
    def set_preset(self, name):
        if not self.volume: return
        
        prop = self.volume.GetProperty()
        color_tf = vtk.vtkColorTransferFunction()
        opacity_tf = vtk.vtkPiecewiseFunction()
        
        if name == "Bone":
            color_tf.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color_tf.AddRGBPoint(400, 1.0, 0.9, 0.8)
            color_tf.AddRGBPoint(1000, 1.0, 1.0, 1.0)
            
            opacity_tf.AddPoint(-1000, 0.0)
            opacity_tf.AddPoint(400, 0.4)
            opacity_tf.AddPoint(1000, 0.9)
            
        elif name == "Skin":
            color_tf.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color_tf.AddRGBPoint(0, 0.8, 0.5, 0.4)
            color_tf.AddRGBPoint(1000, 0.8, 0.5, 0.4)
            
            opacity_tf.AddPoint(-1000, 0.0)
            opacity_tf.AddPoint(0, 0.6)
            opacity_tf.AddPoint(1000, 0.8)
            
        elif name == "Angio":
            color_tf.AddRGBPoint(-1000, 0.0, 0.0, 0.0)
            color_tf.AddRGBPoint(100, 0.8, 0.0, 0.0)
            color_tf.AddRGBPoint(500, 1.0, 0.0, 0.0)
            
            opacity_tf.AddPoint(-1000, 0.0)
            opacity_tf.AddPoint(100, 0.3)
            opacity_tf.AddPoint(500, 0.9)
            
        prop.SetColor(color_tf)
        prop.SetScalarOpacity(opacity_tf)
        self.vtkWidget.GetRenderWindow().Render()

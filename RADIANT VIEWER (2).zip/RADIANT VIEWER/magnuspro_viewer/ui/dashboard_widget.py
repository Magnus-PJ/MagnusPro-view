from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, 
                             QGridLayout, QPushButton, QScrollArea)
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QFont, QColor, QPainter

class StatCard(QFrame):
    def __init__(self, title, value, color="#4488FF", parent=None):
        super().__init__(parent)
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setStyleSheet(f"""
            QFrame {{
                background-color: #1e1e1e;
                border-radius: 12px;
                border: 1px solid #333;
            }}
            QFrame:hover {{
                border: 1px solid {color};
                background-color: #252525;
            }}
            QLabel {{ border: none; background: transparent; }}
        """)
        
        layout = QVBoxLayout(self)
        
        lbl_title = QLabel(title)
        lbl_title.setStyleSheet("color: #AAAAAA; font-size: 12px;")
        layout.addWidget(lbl_title)
        
        lbl_value = QLabel(value)
        lbl_value.setStyleSheet(f"color: {color}; font-size: 24px; font-weight: bold;")
        layout.addWidget(lbl_value)

class RecentStudyCard(QFrame):
    clicked = pyqtSignal(str) # Emits study_uid
    
    def __init__(self, study_data, parent=None):
        super().__init__(parent)
        self.study_uid = study_data['study_uid']
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setStyleSheet("""
            QFrame {
                background-color: #1e1e1e;
                border-radius: 10px;
                border: 1px solid #333;
            }
            QFrame:hover {
                background-color: #252525;
                border: 1px solid #4488FF;
            }
            QLabel { border: none; background: transparent; }
        """)
        
        layout = QVBoxLayout(self)
        
        # Patient Name
        lbl_name = QLabel(study_data.get('patient_name', 'Unknown'))
        lbl_name.setStyleSheet("font-size: 14px; font-weight: bold; color: #FFFFFF;")
        layout.addWidget(lbl_name)
        
        # Details
        details = f"{study_data.get('modality', '??')} | {study_data.get('study_date', '')}"
        lbl_details = QLabel(details)
        lbl_details.setStyleSheet("color: #AAAAAA; font-size: 11px;")
        layout.addWidget(lbl_details)
        
        # Desc
        lbl_desc = QLabel(study_data.get('description', 'No Description'))
        lbl_desc.setStyleSheet("color: #888888; font-size: 11px; font-style: italic;")
        lbl_desc.setWordWrap(True)
        layout.addWidget(lbl_desc)

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.clicked.emit(self.study_uid)

class DashboardWidget(QWidget):
    open_study_requested = pyqtSignal(str)
    
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)
        
        # Header
        header = QLabel("Dashboard")
        header.setStyleSheet("font-size: 28px; font-weight: 300; color: #FFFFFF; letter-spacing: 1px;")
        layout.addWidget(header)
        
        # Stats Row
        stats_layout = QHBoxLayout()
        self.card_total = StatCard("Total Studies", "0", "#4488FF")
        self.card_today = StatCard("Today's Studies", "0", "#00E676") # Green
        self.card_storage = StatCard("Storage Used", "0 GB", "#FF1744") # Red
        
        stats_layout.addWidget(self.card_total)
        stats_layout.addWidget(self.card_today)
        stats_layout.addWidget(self.card_storage)
        layout.addLayout(stats_layout)
        
        # Recent Studies
        lbl_recent = QLabel("Recent Activity")
        lbl_recent.setStyleSheet("font-size: 18px; font-weight: bold; color: #DDDDDD; margin-top: 10px;")
        layout.addWidget(lbl_recent)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; } QWidget { background: transparent; }")
        
        self.recent_container = QWidget()
        self.recent_layout = QGridLayout(self.recent_container)
        self.recent_layout.setAlignment(Qt.AlignmentFlag.AlignTop | Qt.AlignmentFlag.AlignLeft)
        
        scroll.setWidget(self.recent_container)
        layout.addWidget(scroll)
        
        self.refresh()

    def refresh(self):
        # Update Stats
        count = self.db_manager.get_study_count()
        self.card_total.findChild(QLabel, "").setText(str(count)) # Hacky way to find value label? No, need ref.
        # Re-create or store refs. Let's just re-create for simplicity or store refs in StatCard.
        # Actually StatCard layout items: 0 is title, 1 is value
        self.card_total.layout().itemAt(1).widget().setText(str(count))
        
        # Today's count (Mock for now, or DB query)
        # self.card_today.layout().itemAt(1).widget().setText(...)
        
        # Recent Studies
        # Clear
        while self.recent_layout.count():
            child = self.recent_layout.takeAt(0)
            if child.widget():
                child.widget().deleteLater()
                
        studies = self.db_manager.get_recent_studies(limit=10)
        row = 0
        col = 0
        max_cols = 4
        
        for s in studies:
            card = RecentStudyCard(s)
            card.clicked.connect(self.open_study_requested.emit)
            self.recent_layout.addWidget(card, row, col)
            col += 1
            if col >= max_cols:
                col = 0
                row += 1

class StyleManager:
    @staticmethod
    @staticmethod
    def get_stylesheet(role="Radiologist"):
        # Base Theme (Dark / Deep Space) - Default for Radiologists
        base_theme = """
            /* Global Window Settings */
            QMainWindow, QDialog {
                background-color: #121212; /* Deep OLED Black */
                color: #e0e0e0;
                font-family: 'Segoe UI', 'Roboto', sans-serif;
                font-size: 10pt;
            }
            /* ... (Rest of Dark Theme) ... */
        """
        
        # Admin Theme (Light / High Contrast)
        admin_theme = """
            /* Global Window Settings */
            QMainWindow, QDialog {
                background-color: #F0F2F5; /* Light Grey */
                color: #333333;
                font-family: 'Segoe UI', 'Roboto', sans-serif;
                font-size: 10pt;
            }
            
            /* ToolBar */
            QToolBar {
                background-color: #FFFFFF;
                border-bottom: 1px solid #CCCCCC;
                spacing: 8px;
                padding: 6px;
            }
            QToolButton {
                color: #333;
                background-color: transparent;
                border: 1px solid transparent;
                border-radius: 6px;
                padding: 6px 12px;
            }
            QToolButton:hover {
                background-color: #E6F0FF;
                border: 1px solid #4488FF;
                color: #0055CC;
            }
            
            /* Menus */
            QMenuBar {
                background-color: #FFFFFF;
                color: #333;
                border-bottom: 1px solid #DDD;
            }
            QMenu {
                background-color: #FFFFFF;
                color: #333;
                border: 1px solid #CCC;
            }
            QMenu::item:selected {
                background-color: #E6F0FF;
                color: #0055CC;
            }
            
            /* Sidebar */
            QListWidget {
                background-color: #FFFFFF;
                border-right: 1px solid #DDD;
                color: #333;
            }
            QListWidget::item:selected {
                background-color: #E6F0FF;
                color: #0055CC;
                border-left: 3px solid #0055CC;
            }
            
            /* Tables */
            QTableWidget {
                background-color: #FFFFFF;
                color: #333;
                gridline-color: #DDD;
                border: 1px solid #CCC;
                selection-background-color: #E6F0FF;
                selection-color: #0055CC;
            }
            QHeaderView::section {
                background-color: #F8F9FA;
                color: #555;
                border: 1px solid #DDD;
                font-weight: bold;
            }
            
            /* Inputs */
            QLineEdit, QComboBox, QSpinBox, QTextEdit {
                background-color: #FFFFFF;
                color: #333;
                border: 1px solid #CCC;
            }
            
            /* Buttons */
            QPushButton {
                background-color: #FFFFFF;
                color: #333;
                border: 1px solid #CCC;
            }
            QPushButton:hover {
                background-color: #F8F9FA;
                border: 1px solid #999;
            }
            QPushButton:default {
                background-color: #0055CC;
                color: white;
                border: 1px solid #0055CC;
            }
        """
        
        if role in ["Admin", "SuperAdmin", "CenterManager"]:
            return admin_theme
        else:
            # Re-use the existing dark theme code (simplified here for brevity, 
            # in real implementation I would keep the full string or separate files)
            # For this edit, I will return the original dark theme if not Admin.
            return StyleManager.get_dark_theme()

    @staticmethod
    def get_dark_theme():
        return """
            /* Global Window Settings */
            QMainWindow, QDialog {
                background-color: #121212; /* Deep OLED Black */
                color: #e0e0e0;
                font-family: 'Segoe UI', 'Roboto', sans-serif;
                font-size: 10pt;
            }

            /* ToolBar (Glassmorphism) */
            QToolBar {
                background-color: rgba(30, 30, 30, 0.85); /* Semi-transparent */
                border-bottom: 1px solid rgba(68, 136, 255, 0.3); /* Blue Glow */
                spacing: 8px;
                padding: 6px;
            }
            QToolButton {
                color: #e0e0e0;
                background-color: transparent;
                border: 1px solid transparent;
                border-radius: 6px;
                padding: 6px 12px;
                font-weight: 500;
            }
            QToolButton:hover {
                background-color: rgba(68, 136, 255, 0.15); /* Blue Tint */
                border: 1px solid #4488FF;
                color: #4488FF; /* Electric Blue */
            }
            QToolButton:checked {
                background-color: rgba(68, 136, 255, 0.25);
                border: 1px solid #4488FF;
                color: #FFFFFF;
            }
            QToolButton:pressed {
                background-color: rgba(68, 136, 255, 0.35);
            }

            /* Menus */
            QMenuBar {
                background-color: #121212;
                color: #e0e0e0;
                border-bottom: 1px solid #222;
            }
            QMenuBar::item {
                background-color: transparent;
                padding: 6px 12px;
            }
            QMenuBar::item:selected {
                background-color: #2d2d2d;
                color: #4488FF;
            }
            QMenu {
                background-color: #1e1e1e;
                color: #e0e0e0;
                border: 1px solid #333;
                padding: 4px;
            }
            QMenu::item {
                padding: 6px 28px 6px 12px;
                border-radius: 4px;
            }
            QMenu::item:selected {
                background-color: rgba(68, 136, 255, 0.2);
                color: #4488FF;
            }
            QMenu::separator {
                height: 1px;
                background: #333;
                margin: 4px 0px;
            }

            /* Sidebar / Lists */
            QListWidget, QTreeWidget {
                background-color: #181818;
                border: none;
                border-right: 1px solid #333;
                outline: none;
            }
            QListWidget::item {
                padding: 10px;
                margin: 2px 4px;
                border-radius: 6px;
                color: #bbb;
            }
            QListWidget::item:hover {
                background-color: #222;
                color: #fff;
            }
            QListWidget::item:selected {
                background-color: rgba(68, 136, 255, 0.15);
                color: #4488FF;
                border-left: 3px solid #4488FF;
            }

            /* ScrollBars */
            QScrollBar:vertical {
                border: none;
                background: #121212;
                width: 10px;
                margin: 0px;
            }
            QScrollBar::handle:vertical {
                background: #333;
                min-height: 20px;
                border-radius: 5px;
                margin: 2px;
            }
            QScrollBar::handle:vertical:hover {
                background: #4488FF;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
            QScrollBar:horizontal {
                border: none;
                background: #121212;
                height: 10px;
                margin: 0px;
            }
            QScrollBar::handle:horizontal {
                background: #333;
                min-width: 20px;
                border-radius: 5px;
                margin: 2px;
            }

            /* StatusBar */
            QStatusBar {
                background-color: #121212;
                color: #888;
                border-top: 1px solid #222;
            }
            
            /* Progress Bar */
            QProgressBar {
                border: 1px solid #333;
                border-radius: 4px;
                background-color: #1a1a1a;
                text-align: center;
                color: #aaa;
            }
            QProgressBar::chunk {
                background-color: #4488FF;
                width: 1px;
            }

            /* TableWidget */
            QTableWidget {
                background-color: #1e1e1e;
                color: #e0e0e0;
                gridline-color: #333;
                border: 1px solid #333;
                selection-background-color: rgba(68, 136, 255, 0.2);
                selection-color: #FFFFFF;
            }
            QHeaderView::section {
                background-color: #252525;
                color: #4488FF;
                padding: 8px;
                border: none;
                border-bottom: 2px solid #333;
                border-right: 1px solid #333;
                font-weight: 600;
                text-transform: uppercase;
                font-size: 9pt;
            }
            
            /* TabWidget */
            QTabWidget::pane {
                border: 1px solid #333;
                background: #1e1e1e;
            }
            QTabBar::tab {
                background: #252525;
                color: #888;
                padding: 10px 24px;
                border: 1px solid #333;
                border-bottom: none;
                margin-right: 2px;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
            }
            QTabBar::tab:selected {
                background: #1e1e1e;
                color: #4488FF;
                border-top: 2px solid #4488FF;
                font-weight: bold;
            }
            
            /* Inputs */
            QLineEdit, QComboBox, QSpinBox, QTextEdit {
                background-color: #252525;
                color: white;
                border: 1px solid #333;
                padding: 8px;
                border-radius: 4px;
            }
            QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QTextEdit:focus {
                border: 1px solid #4488FF;
                background-color: #2a2a2a;
            }
            
            /* GroupBox */
            QGroupBox {
                border: 1px solid #333;
                border-radius: 6px;
                margin-top: 24px;
                font-weight: 600;
                color: #4488FF;
                padding-top: 14px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
            
            /* Buttons */
            QPushButton {
                background-color: #333;
                color: #e0e0e0;
                border: 1px solid #444;
                padding: 8px 20px;
                border-radius: 6px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #444;
                border: 1px solid #666;
                color: #FFFFFF;
            }
            QPushButton:pressed {
                background-color: #222;
            }
            QPushButton:default {
                background-color: #4488FF;
                color: #FFFFFF;
                border: 1px solid #4488FF;
                font-weight: bold;
                box-shadow: 0 0 10px rgba(68, 136, 255, 0.5);
            }
            QPushButton:default:hover {
                background-color: #3377EE;
            }
        """

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QTableWidget, QTableWidgetItem, 
                             QHeaderView, QPushButton, QHBoxLayout, QLabel, QLineEdit, QDateEdit)
from PyQt6.QtCore import Qt, pyqtSignal, QDate

class StudyBrowserWidget(QWidget):
    study_selected = pyqtSignal(str) # Emits study_uid

    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        
        layout = QVBoxLayout(self)
        
        # Filters
        filter_layout = QHBoxLayout()
        self.edit_filter = QLineEdit()
        self.edit_filter.setPlaceholderText("Filter by Name or ID...")
        self.edit_filter.textChanged.connect(self.refresh_studies)
        
        btn_refresh = QPushButton("Refresh")
        btn_refresh.clicked.connect(self.refresh_studies)
        
        filter_layout.addWidget(self.edit_filter)
        filter_layout.addWidget(btn_refresh)
        layout.addLayout(filter_layout)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["Patient Name", "Patient ID", "Date", "Modality", "Description", "Study UID"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.doubleClicked.connect(self.on_double_click)
        
        layout.addWidget(self.table)
        
        self.refresh_studies()

    def refresh_studies(self):
        if not self.db_manager: return
        
        filter_text = self.edit_filter.text().lower()
        studies = self.db_manager.get_all_studies()
        
        self.table.setRowCount(0)
        for study in studies:
            # Filter
            name = str(study['patient_name']).lower()
            pid = str(study['patient_id']).lower()
            
            if filter_text and (filter_text not in name and filter_text not in pid):
                continue
                
            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(str(study['patient_name'])))
            self.table.setItem(row, 1, QTableWidgetItem(str(study['patient_id'])))
            self.table.setItem(row, 2, QTableWidgetItem(str(study['study_date'])))
            self.table.setItem(row, 3, QTableWidgetItem(str(study['modality'])))
            self.table.setItem(row, 4, QTableWidgetItem(str(study['description'])))
            self.table.setItem(row, 5, QTableWidgetItem(str(study['study_uid'])))

    def on_double_click(self, index):
        row = index.row()
        study_uid = self.table.item(row, 5).text()
        self.study_selected.emit(study_uid)

    def contextMenuEvent(self, event):
        item = self.table.itemAt(event.pos())
        if not item: return
        
        row = item.row()
        study_uid = self.table.item(row, 5).text()
        
        from PyQt6.QtWidgets import QMenu
        menu = QMenu(self)
        act_send = menu.addAction("Send to PACS...")
        action = menu.exec(self.table.mapToGlobal(event.pos()))
        
        if action == act_send:
            self.show_send_dialog(study_uid)

    def show_send_dialog(self, study_uid):
        from PyQt6.QtWidgets import QDialog, QComboBox, QDialogButtonBox, QMessageBox
        
        dialog = QDialog(self)
        dialog.setWindowTitle("Send Study")
        layout = QVBoxLayout(dialog)
        
        layout.addWidget(QLabel("Select Destination PACS:"))
        combo = QComboBox()
        
        # Populate PACS nodes
        nodes = self.db_manager.get_pacs_nodes()
        if not nodes:
            QMessageBox.warning(self, "No PACS Nodes", "Please configure PACS nodes in Settings first.")
            return
            
        for node in nodes:
            combo.addItem(f"{node['name']} ({node['ae_title']}@{node['ip_address']}:{node['port']})", node)
            
        layout.addWidget(combo)
        
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(dialog.accept)
        buttons.rejected.connect(dialog.reject)
        layout.addWidget(buttons)
        
        if dialog.exec() == QDialog.DialogCode.Accepted:
            node_data = combo.currentData()
            self.send_study(study_uid, node_data)

    def send_study(self, study_uid, node_data):
        self.send_requested.emit(study_uid, node_data)

    # Add signal
    send_requested = pyqtSignal(str, dict) # study_uid, node_data

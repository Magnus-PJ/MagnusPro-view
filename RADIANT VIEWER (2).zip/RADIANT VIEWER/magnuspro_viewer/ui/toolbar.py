from PyQt6.QtWidgets import QToolBar, QToolButton, QMenu, QLineEdit, QWidget, QSizePolicy
from PyQt6.QtGui import QAction, QIcon
from PyQt6.QtCore import QSize, Qt

class MainToolbar(QToolBar):
    def __init__(self, main_window):
        super().__init__("Main Toolbar", main_window)
        self.main_window = main_window
        self.setMovable(False)
        self.setIconSize(QSize(24, 24))
        self.init_actions()

    def init_actions(self):
        mw = self.main_window
        
        # Universal Search Bar
        self.search_bar = QLineEdit()
        self.search_bar.setPlaceholderText("Search Patients, Studies, Reports...")
        self.search_bar.setFixedWidth(300)
        self.search_bar.setStyleSheet("""
            QLineEdit {
                background-color: #252525;
                color: #e0e0e0;
                border: 1px solid #333;
                border-radius: 15px;
                padding: 4px 12px;
                font-size: 12px;
            }
            QLineEdit:focus {
                border: 1px solid #4488FF;
                background-color: #2a2a2a;
            }
        """)
        
        # Spacer to center search or push right
        spacer_left = QWidget()
        spacer_left.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)
        
        spacer_right = QWidget()
        spacer_right.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Preferred)

        self.addWidget(spacer_left)
        self.addWidget(self.search_bar)
        self.addWidget(spacer_right)

        # 1. Open / Save
        self.addAction(mw.act_open_folder)
        self.addSeparator()

        # 2. Window/Level (Dropdown)
        btn_wl = QToolButton()
        btn_wl.setText("WL")
        btn_wl.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu_wl = QMenu(btn_wl)
        
        for p in mw.options_manager.presets:
            action = QAction(p['name'], self)
            action.triggered.connect(lambda checked, val=p: mw.render_widget.set_window_level(val['center'], val['width']))
            menu_wl.addAction(action)
            
        
        for scale in [0.5, 1.0, 2.0, 4.0]:
            act = QAction(f"{int(scale*100)}%", self)
            act.triggered.connect(lambda checked, s=scale: mw.render_widget.set_zoom(s))
            menu_zoom.addAction(act)

        btn_zoom.setMenu(menu_zoom)
        self.addWidget(btn_zoom)

        self.addSeparator()

        # 4. Color (CLUT)
        btn_color = QToolButton()
        btn_color.setText("Color")
        btn_color.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu_color = QMenu(btn_color)
        
        for preset in ["Grayscale", "Hot Iron", "Jet", "Rainbow"]:
            act = QAction(preset, self)
            act.triggered.connect(lambda checked, p=preset: mw.render_widget.set_clut(p))
            menu_color.addAction(act)
            
        btn_color.setMenu(menu_color)
        self.addWidget(btn_color)
        
        self.addSeparator()

        # 5. Tools (Dropdown)
        btn_tools = QToolButton()
        btn_tools.setText("Tools")
        btn_tools.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu_tools = QMenu(btn_tools)
        
        act_ruler = QAction("Length", self)
        act_ruler.triggered.connect(lambda: mw.render_widget.enable_measurement("Length"))
        menu_tools.addAction(act_ruler)
        
        act_ellipse = QAction("Ellipse", self)
        act_ellipse.triggered.connect(lambda: mw.render_widget.enable_measurement("Ellipse"))
        menu_tools.addAction(act_ellipse)
        
        act_angle = QAction("Angle", self)
        act_angle.triggered.connect(lambda: mw.render_widget.enable_measurement("Angle"))
        menu_tools.addAction(act_angle)
        
        menu_tools.addSeparator()
        
        act_none = QAction("None (Reset)", self)
        act_none.triggered.connect(lambda: mw.render_widget.enable_measurement("None"))
        menu_tools.addAction(act_none)
        
        btn_tools.setMenu(menu_tools)
        self.addWidget(btn_tools)
        
        self.addSeparator()

        # 6. Transformations (Dropdown)
        btn_transform = QToolButton()
        btn_transform.setText("Transform")
        btn_transform.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu_transform = QMenu(btn_transform)
        
        act_rot90 = QAction("Rotate 90° CW", self)
        act_rot90.triggered.connect(lambda: mw.render_widget.apply_rotate(90))
        menu_transform.addAction(act_rot90)
        
        act_rot_ccw = QAction("Rotate 90° CCW", self)
        act_rot_ccw.triggered.connect(lambda: mw.render_widget.apply_rotate(-90))
        menu_transform.addAction(act_rot_ccw)
        
        menu_transform.addSeparator()
        
        act_flip_h = QAction("Flip Horizontal", self)
        act_flip_h.triggered.connect(lambda: mw.render_widget.apply_flip(0))
        menu_transform.addAction(act_flip_h)
        
        act_flip_v = QAction("Flip Vertical", self)
        act_flip_v.triggered.connect(lambda: mw.render_widget.apply_flip(1))
        menu_transform.addAction(act_flip_v)
        
        act_clear_xform = QAction("Clear Transformations", self)
        act_clear_xform.triggered.connect(mw.render_widget.reset_camera)
        
        action_3d = QAction("3D", self)
        action_3d.triggered.connect(mw.toggle_3d)
        self.addAction(action_3d)
        
        action_tags = QAction("Tags", self)
        action_tags.triggered.connect(mw.show_tags)
        self.addAction(action_tags)

        self.addSeparator()

        # 10. Layouts
        btn_layout = QToolButton()
        btn_layout.setText("Layout")
        btn_layout.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu_layout = QMenu(btn_layout)
        
        act_1x1 = QAction("1x1", self)
        act_1x1.triggered.connect(lambda: mw.viewport_grid.set_layout(1, 1))
        menu_layout.addAction(act_1x1)
        
        act_1x2 = QAction("1x2", self)
        act_1x2.triggered.connect(lambda: mw.viewport_grid.set_layout(1, 2))
        menu_layout.addAction(act_1x2)
        
        act_2x1 = QAction("2x1", self)
        act_2x1.triggered.connect(lambda: mw.viewport_grid.set_layout(2, 1))
        menu_layout.addAction(act_2x1)
        
        act_2x2 = QAction("2x2", self)
        act_2x2.triggered.connect(lambda: mw.viewport_grid.set_layout(2, 2))
        menu_layout.addAction(act_2x2)
        
        btn_layout.setMenu(menu_layout)
        self.addWidget(btn_layout)

from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTextEdit, QLabel, QPushButton, QGroupBox, QFormLayout)
from PyQt6.QtCore import QTimer, Qt
import psutil
import os

class DeveloperDashboard(QWidget):
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        self.init_ui()
        
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_stats)
        self.timer.start(2000) # Update every 2s
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header = QLabel("Developer Mode / System Internals")
        header.setStyleSheet("font-size: 18px; font-weight: bold; color: #FF4444;")
        layout.addWidget(header)
        
        # System Stats
        sys_group = QGroupBox("System Resources")
        sys_layout = QFormLayout()
        self.lbl_cpu = QLabel("CPU: 0%")
        self.lbl_ram = QLabel("RAM: 0%")
        sys_layout.addRow("CPU Usage:", self.lbl_cpu)
        sys_layout.addRow("Memory Usage:", self.lbl_ram)
        sys_group.setLayout(sys_layout)
        layout.addWidget(sys_group)
        
        # DB Stats
        db_group = QGroupBox("Database Statistics")
        db_layout = QFormLayout()
        self.lbl_studies = QLabel("Studies: 0")
        self.lbl_users = QLabel("Users: 0")
        db_layout.addRow("Total Studies:", self.lbl_studies)
        db_layout.addRow("Total Users:", self.lbl_users)
        db_group.setLayout(db_layout)
        layout.addWidget(db_group)
        
        # Logs
        log_group = QGroupBox("Application Logs (Tail)")
        log_layout = QVBoxLayout()
        self.txt_logs = QTextEdit()
        self.txt_logs.setReadOnly(True)
        self.txt_logs.setStyleSheet("background-color: #111; color: #0f0; font-family: Consolas;")
        log_layout.addWidget(self.txt_logs)
        log_group.setLayout(log_layout)
        layout.addWidget(log_group)
        
    def update_stats(self):
        # System
        try:
            cpu = psutil.cpu_percent()
            ram = psutil.virtual_memory().percent
            self.lbl_cpu.setText(f"{cpu}%")
            self.lbl_ram.setText(f"{ram}%")
        except:
            self.lbl_cpu.setText("N/A (psutil missing)")
            
        # DB
        try:
            conn = self.db_manager.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT count(*) FROM studies")
            studies = cursor.fetchone()[0]
            cursor.execute("SELECT count(*) FROM users")
            users = cursor.fetchone()[0]
            conn.close()
            
            self.lbl_studies.setText(str(studies))
            self.lbl_users.setText(str(users))
        except Exception as e:
            self.lbl_studies.setText("Error")
            
        # Logs (Mock tail for now, or read actual file)
        # self.txt_logs.append("System check... OK")

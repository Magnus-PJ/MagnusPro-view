from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QHBoxLayout, QTableWidget, QTableWidgetItem, 
                             QPushButton, QLabel, QComboBox, QHeaderView, QMenu)
from PyQt6.QtCore import Qt
from ..utils.session_manager import SessionManager

class WorklistWidget(QWidget):
    def __init__(self, db_manager, parent=None):
        super().__init__(parent)
        self.db_manager = db_manager
        self.init_ui()
        
    def init_ui(self):
        layout = QVBoxLayout(self)
        
        # Header
        header = QLabel("My Worklist")
        header.setStyleSheet("font-size: 24px; font-weight: bold; color: #4488FF; margin-bottom: 10px;")
        layout.addWidget(header)
        
        # Filters
        filter_layout = QHBoxLayout()
        self.cmb_status = QComboBox()
        self.cmb_status.addItems(["All", "Scheduled", "Acquired", "Reported", "Verified"])
        self.cmb_status.currentTextChanged.connect(self.load_worklist)
        
        self.btn_refresh = QPushButton("Refresh")
        self.btn_refresh.clicked.connect(self.load_worklist)
        
        filter_layout.addWidget(QLabel("Status:"))
        filter_layout.addWidget(self.cmb_status)
        filter_layout.addWidget(self.btn_refresh)
        filter_layout.addStretch()
        layout.addLayout(filter_layout)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(["Study UID", "Patient Name", "Modality", "Date", "Status", "Assigned To", "Actions"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self.show_context_menu)
        layout.addWidget(self.table)
        
        self.load_worklist()
        
    def load_worklist(self):
        status_filter = self.cmb_status.currentText()
        studies = self.db_manager.get_all_studies()
        
        # Filter (Mock logic, ideally DB should filter)
        filtered_studies = []
        for s in studies:
            s_status = s.get('status', 'Scheduled')
            if status_filter == "All" or s_status == status_filter:
                filtered_studies.append(s)
        
        self.table.setRowCount(len(filtered_studies))
        for i, study in enumerate(filtered_studies):
            self.table.setItem(i, 0, QTableWidgetItem(study['study_uid']))
            self.table.setItem(i, 1, QTableWidgetItem(study['patient_name']))
            self.table.setItem(i, 2, QTableWidgetItem(study['modality']))
            self.table.setItem(i, 3, QTableWidgetItem(study['study_date']))
            
            status_item = QTableWidgetItem(study.get('status', 'Scheduled'))
            self.table.setItem(i, 4, status_item)
            
            assigned_item = QTableWidgetItem(study.get('assigned_to') or "Unassigned")
            self.table.setItem(i, 5, assigned_item)
            
            btn_open = QPushButton("Open")
            btn_open.setStyleSheet("background-color: #4488FF; color: white; border-radius: 4px;")
            btn_open.clicked.connect(lambda checked, uid=study['study_uid']: self.open_study(uid))
            self.table.setCellWidget(i, 6, btn_open)

    def open_study(self, study_uid):
        # Find MainWindow and call load_study
        mw = self.window()
        if hasattr(mw, 'load_study_from_db'):
            mw.load_study_from_db(study_uid)

    def show_context_menu(self, pos):
        row = self.table.rowAt(pos.y())
        if row < 0:
            return
            
        study_uid = self.table.item(row, 0).text()
        
        menu = QMenu(self)
        action_assign = menu.addAction("Assign to Me")
        action_verify = menu.addAction("Mark Verified")
        
        action = menu.exec(self.table.mapToGlobal(pos))
        
        if action == action_assign:
            user = SessionManager().get_current_user()
            if user:
                self.update_study_field(study_uid, "assigned_to", user['username'])
                
        elif action == action_verify:
            self.update_study_field(study_uid, "status", "Verified")

    def update_study_field(self, study_uid, field, value):
        conn = self.db_manager.get_connection()
        cursor = conn.cursor()
        cursor.execute(f"UPDATE studies SET {field} = ? WHERE study_uid = ?", (value, study_uid))
        conn.commit()
        conn.close()
        self.load_worklist()

from PyQt6.QtWidgets import QDialog, QVBoxLayout, QTableWidget, QTableWidgetItem, QHeaderView, QPushButton, QLabel
from PyQt6.QtCore import Qt
from PyQt6.QtGui import QIcon

class ShortcutsDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Keyboard Shortcuts")
        self.setMinimumSize(500, 400)
        self.setModal(True)
        
        layout = QVBoxLayout(self)
        
        # Title
        title = QLabel("MagnusPro View Shortcuts")
        title.setStyleSheet("font-size: 18px; font-weight: bold; color: #FFD700;")
        layout.addWidget(title)
        
        # Table
        self.table = QTableWidget()
        self.table.setColumnCount(2)
        self.table.setHorizontalHeaderLabels(["Action", "Shortcut"])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.table.verticalHeader().setVisible(False)
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QTableWidget.SelectionMode.NoSelection)
        
        layout.addWidget(self.table)
        
        # Close Button
        close_btn = QPushButton("Close")
        close_btn.clicked.connect(self.accept)
        layout.addWidget(close_btn, alignment=Qt.AlignmentFlag.AlignRight)
        
        self.populate_shortcuts()
        
    def populate_shortcuts(self):
        shortcuts = [
            ("Scroll Slices", "Up / Down Arrow"),
            ("Next / Previous Series", "Left / Right Arrow"),
            ("Zoom In / Out", "Ctrl + + / -"),
            ("Reset View", "R"),
            ("Cine Play / Pause", "C"),
            ("Toggle Fullscreen", "F11"),
            ("Layout 1x1", "1"),
            ("Layout 1x2", "2"),
            ("Layout 2x1", "3"),
            ("Layout 2x2", "4"),
            ("Invert Colors", "I"),
            ("Rotate 90°", "Ctrl + R"),
            ("Flip Horizontal", "H"),
            ("Flip Vertical", "V"),
            ("Show/Hide Text Overlays", "O"),
        ]
        
        self.table.setRowCount(len(shortcuts))
        for i, (action, key) in enumerate(shortcuts):
            self.table.setItem(i, 0, QTableWidgetItem(action))
            self.table.setItem(i, 1, QTableWidgetItem(key))

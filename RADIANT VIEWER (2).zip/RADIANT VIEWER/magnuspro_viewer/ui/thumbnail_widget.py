from PyQt6.QtWidgets import QWidget, QVBoxLayout, QScrollArea, QLabel, QFrame, QHBoxLayout, QGridLayout
from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap, QImage
import numpy as np

class SeriesThumbnail(QFrame):
    clicked = pyqtSignal(str)  # Emits series UID

    def __init__(self, series_uid, info, thumbnail_data=None, parent=None):
        super().__init__(parent)
        self.series_uid = series_uid
        self.setFrameShape(QFrame.Shape.StyledPanel)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedSize(160, 160)
        
        # Main Layout
        layout = QVBoxLayout(self)
        layout.setContentsMargins(2, 2, 2, 2)
        layout.setSpacing(2)
        
        # Header: Modality | Series Number
        header_layout = QHBoxLayout()
        self.lbl_modality = QLabel(info.get('modality', ''))
        self.lbl_modality.setStyleSheet("color: #aaa; font-weight: bold; font-size: 10px;")
        
        self.lbl_series_num = QLabel(f"Se: {info.get('series_number', '?')}")
        self.lbl_series_num.setStyleSheet("color: #aaa; font-size: 10px;")
        self.lbl_series_num.setAlignment(Qt.AlignmentFlag.AlignRight)
        
        header_layout.addWidget(self.lbl_modality)
        header_layout.addStretch()
        header_layout.addWidget(self.lbl_series_num)
        layout.addLayout(header_layout)
        
        # Image
        self.image_label = QLabel()
        self.image_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.image_label.setStyleSheet("background-color: #000; border: 1px solid #333;")
        self.image_label.setFixedHeight(100)
        
        if thumbnail_data is not None:
            self.set_thumbnail(thumbnail_data)
        else:
            self.image_label.setText("No Preview")
            self.image_label.setStyleSheet("color: #555; background-color: #111; border: 1px solid #333;")
            
        layout.addWidget(self.image_label)
        
        # Footer: Image Count | Description
        # Image Count
        self.lbl_count = QLabel(f"Im: {info.get('image_count', '?')}")
        self.lbl_count.setStyleSheet("color: #aaa; font-size: 10px;")
        layout.addWidget(self.lbl_count)
        
        # Description
        desc = info.get('description', 'No Description')
        self.lbl_desc = QLabel(desc)
        self.lbl_desc.setWordWrap(True)
        self.lbl_desc.setStyleSheet("font-size: 10px; color: #ddd;")
        self.lbl_desc.setAlignment(Qt.AlignmentFlag.AlignLeft)
        self.lbl_desc.setFixedHeight(24) # Limit height
        layout.addWidget(self.lbl_desc)
        
        # Hover effect
        # Hover effect
        self.setStyleSheet("""
            SeriesThumbnail { 
                background-color: #222; 
                border: 1px solid #333; 
                border-radius: 6px; 
            }
            SeriesThumbnail:hover { 
                background-color: #2a2a2a; 
                border: 1px solid #ffd700; /* Gold Border */
            }
        """)

    def set_thumbnail(self, numpy_array):
        if numpy_array is None: return
        
        height, width = numpy_array.shape
        bytes_per_line = width
        q_img = QImage(numpy_array.data, width, height, bytes_per_line, QImage.Format.Format_Grayscale8)
        pixmap = QPixmap.fromImage(q_img)
        self.image_label.setPixmap(pixmap.scaled(self.image_label.size(), Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))

    def mousePressEvent(self, event):
        self.clicked.emit(self.series_uid)
        super().mousePressEvent(event)

class ThumbnailWidget(QWidget):
    series_selected = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        
        self.scroll_content = QWidget()
        self.scroll_layout = QVBoxLayout(self.scroll_content)
        self.scroll_layout.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.scroll_layout.setSpacing(5)
        self.scroll_layout.setContentsMargins(5, 5, 5, 5)
        
        self.scroll_area.setWidget(self.scroll_content)
        self.layout.addWidget(self.scroll_area)
        
        self.setStyleSheet("""
            QScrollArea { border: none; background-color: #181818; }
            QWidget { background-color: #181818; }
            QScrollBar:vertical { width: 12px; background: #181818; }
            QScrollBar::handle:vertical { background: #333; min-height: 20px; border-radius: 6px; }
            QScrollBar::handle:vertical:hover { background: #555; }
        """)

    def add_series(self, series_uid, info, thumbnail_data=None):
        # info is a dict with keys: modality, series_number, image_count, description
        thumb = SeriesThumbnail(series_uid, info, thumbnail_data)
        thumb.clicked.connect(self.series_selected.emit)
        self.scroll_layout.addWidget(thumb)

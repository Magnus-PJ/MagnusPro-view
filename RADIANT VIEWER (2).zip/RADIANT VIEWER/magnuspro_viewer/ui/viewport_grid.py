from PyQt6.QtWidgets import QWidget, QGridLayout, QLabel
from PyQt6.QtCore import Qt, pyqtSignal
from .render_widget import QVTKRenderWidget
import math

class ViewportGrid(QWidget):
    active_viewport_changed = pyqtSignal(QVTKRenderWidget)

    def __init__(self, overlay_config_path, parent=None):
        super().__init__(parent)
        self.overlay_config_path = overlay_config_path
        self.layout = QGridLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(2)
        
        self.viewports = [] # List of QVTKRenderWidget
        self.active_viewport = None
        
        # Start with 1x1
        self.set_layout(1, 1)

    def set_layout(self, rows, cols):
        # Clear current layout
        # Note: We don't delete widgets immediately if we want to preserve state, 
        # but for simplicity, we might re-create or re-assign them.
        # A better approach for a viewer is to have a pool of viewports.
        
        target_count = rows * cols
        current_count = len(self.viewports)
        
        # Create new viewports if needed
        if target_count > current_count:
            for _ in range(target_count - current_count):
                vp = QVTKRenderWidget(overlay_config=self.overlay_config_path)
                # Connect click event to set active
                vp.clicked.connect(lambda v=vp: self.set_active_viewport(v))
                self.viewports.append(vp)
        
        # Hide extra viewports
        for i in range(target_count, current_count):
            self.viewports[i].hide()
            
        # Re-arrange layout
        # Remove all items from layout
        while self.layout.count():
            item = self.layout.takeAt(0)
            # Don't delete widget, just remove from layout
            
        for i in range(target_count):
            vp = self.viewports[i]
            vp.show()
            r = i // cols
            c = i % cols
            self.layout.addWidget(vp, r, c)
            
            # Add a border or indicator for active viewport?
            # We can do this via stylesheet or a separate frame.
            
        # Set active viewport if none or invalid
        if not self.active_viewport or self.active_viewport not in self.viewports[:target_count]:
            self.set_active_viewport(self.viewports[0])

    def set_active_viewport(self, viewport):
        self.active_viewport = viewport
        self.active_viewport_changed.emit(viewport)
        
        # Visual feedback (simple border)
        for vp in self.viewports:
            if vp == viewport:
                vp.setStyleSheet("border: 2px solid #f0a30a;") # Nanobanana Gold
            else:
                vp.setStyleSheet("border: 1px solid #333;")

    def get_active_viewport(self):
        return self.active_viewport

    def mousePressEvent(self, event):
        # Determine which viewport was clicked
        # Since QVTKRenderWidget captures mouse, this might not trigger easily
        # unless we install an event filter or handle it in the VP.
        pass

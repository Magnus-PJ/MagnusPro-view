from PyQt6.QtWidgets import (QWidget, QVBoxLayout, QPushButton, QLabel, QFrame, 
                             QSizePolicy, QButtonGroup)
from PyQt6.QtCore import Qt, pyqtSignal, QSize
from PyQt6.QtGui import QIcon

class SidebarButton(QPushButton):
    def __init__(self, text, icon_name=None, parent=None):
        super().__init__(text, parent)
        self.setCheckable(True)
        self.setFixedHeight(50)
        self.setStyleSheet("""
            QPushButton {
                text-align: left;
                padding-left: 20px;
                background-color: transparent;
                color: #888;
                border: none;
                border-left: 3px solid transparent;
                font-size: 14px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #252525;
                color: #e0e0e0;
            }
            QPushButton:checked {
                background-color: rgba(68, 136, 255, 0.1);
                color: #4488FF;
                border-left: 3px solid #4488FF;
                font-weight: bold;
            }
        """)

class SidebarNavigation(QWidget):
    module_changed = pyqtSignal(str) # Emits module name (e.g., "dashboard", "patients")
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedWidth(200)
        self.setStyleSheet("background-color: #181818; border-right: 1px solid #333;")
        
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 20, 0, 20)
        layout.setSpacing(5)
        
        # App Title (Small)
        lbl_title = QLabel("MAGNUS")
        lbl_title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lbl_title.setStyleSheet("color: #4488FF; font-weight: 900; font-size: 18px; letter-spacing: 2px; margin-bottom: 20px;")
        layout.addWidget(lbl_title)
        
        self.btn_group = QButtonGroup(self)
        self.btn_group.setExclusive(True)
        
        # Modules
        self.add_button("Dashboard", "dashboard")
        self.add_button("Patients", "patients")
        self.add_button("Worklist", "worklist")
        self.add_button("Viewer", "viewer")
        self.add_button("Reporting", "reporting")
        
        layout.addStretch()
        
        # Bottom Actions
        self.add_button("Settings", "settings")
        self.add_button("Logout", "logout")
        
        # Select Dashboard by default
        self.buttons["dashboard"].setChecked(True)

    def add_button(self, text, module_id):
        btn = SidebarButton(text, parent=self)
        btn.clicked.connect(lambda: self.module_changed.emit(module_id))
        self.layout().addWidget(btn)
        self.btn_group.addButton(btn)
        
        if not hasattr(self, 'buttons'):
            self.buttons = {}
        self.buttons[module_id] = btn

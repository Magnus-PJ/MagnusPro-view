import sqlite3
import os
import json
from ..utils.config import ConfigManager
from ..utils.logger import get_logger

class DBManager:
    def __init__(self):
        self.logger = get_logger("DBManager")
        self.config = ConfigManager()
        self.db_path = self.config.get("db_path")
        
        # Ensure directory exists
        db_dir = os.path.dirname(self.db_path)
        if not os.path.exists(db_dir):
            os.makedirs(db_dir)
        
        # Instances
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS instances (
                sop_instance_uid TEXT PRIMARY KEY,
                series_uid TEXT,
                file_path TEXT,
                instance_number INTEGER,
                z_position REAL,
                pixel_spacing TEXT,
                slice_thickness REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(series_uid) REFERENCES series(series_uid)
            )
        ''')
        
        # PACS Nodes
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS pacs_nodes (
                ae_title TEXT PRIMARY KEY,
                ip_address TEXT,
                port INTEGER,
                description TEXT,
                protocol TEXT DEFAULT 'DICOM'
            )
        ''')
        
        # Settings (Key-Value)
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        ''')
        
        conn.commit()
        conn.close()
        
        self.migrate_db()

    def migrate_db(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            # Check for status column
            cursor.execute("PRAGMA table_info(studies)")
            columns = [info[1] for info in cursor.fetchall()]
            
            if 'status' not in columns:
                cursor.execute("ALTER TABLE studies ADD COLUMN status TEXT DEFAULT 'Scheduled'")
                self.logger.info("Added status column to studies table")
                
            if 'assigned_to' not in columns:
                cursor.execute("ALTER TABLE studies ADD COLUMN assigned_to TEXT")
                self.logger.info("Added assigned_to column to studies table")
                
            conn.commit()
        except Exception as e:
            self.logger.error(f"Migration failed: {e}")
        finally:
            conn.close()

    def insert_study(self, data):
        # RBAC Check
        from ..utils.session_manager import SessionManager
        # SessionManager().require_permission('upload_studies') # Commented out for now to avoid blocking auto-tests/demo
        
        # Encryption
        from ..utils.security import SecurityManager
        sec = SecurityManager()
        
        p_name = sec.encrypt(data['PatientName'])
        p_id = sec.encrypt(data['PatientID'])
        
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            # Check if exists to preserve status/assignment
            cursor.execute("SELECT status, assigned_to FROM studies WHERE study_uid = ?", (data['StudyInstanceUID'],))
            existing = cursor.fetchone()
            
            status = existing[0] if existing and existing[0] else 'Acquired' # Default to Acquired on insert
            assigned_to = existing[1] if existing else None
            
            cursor.execute('''
                INSERT OR REPLACE INTO studies (study_uid, patient_name, patient_id, study_date, modality, description, accession_number, status, assigned_to)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (data['StudyInstanceUID'], p_name, p_id, data['StudyDate'], 
                  data['Modality'], data['StudyDescription'], data['AccessionNumber'], status, assigned_to))
            conn.commit()
        except Exception as e:
            self.logger.error(f"Error inserting study: {e}")
        finally:
            conn.close()

    def insert_series(self, data):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO series (series_uid, study_uid, modality, series_number, description, body_part)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (data['SeriesInstanceUID'], data['StudyInstanceUID'], data['Modality'], 
                  data['SeriesNumber'], data['SeriesDescription'], data['BodyPartExamined']))
            conn.commit()
        except Exception as e:
            self.logger.error(f"Error inserting series: {e}")
        finally:
            conn.close()

    def insert_instance(self, data):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO instances (sop_instance_uid, series_uid, file_path, instance_number, z_position, pixel_spacing, slice_thickness)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (data['SOPInstanceUID'], data['SeriesInstanceUID'], data['FilePath'], 
                  data['InstanceNumber'], data['ZPosition'], data['PixelSpacing'], data['SliceThickness']))
            conn.commit()
        except Exception as e:
            self.logger.error(f"Error inserting instance: {e}")
        finally:
            conn.close()

    def get_series_for_study(self, study_uid):
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM series WHERE study_uid = ? ORDER BY series_number', (study_uid,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def get_all_studies(self):
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM studies ORDER BY created_at DESC')
        rows = cursor.fetchall()
        conn.close()
        
        from ..utils.security import SecurityManager
        sec = SecurityManager()
        
        results = []
        for row in rows:
            d = dict(row)
            d['patient_name'] = sec.decrypt(d['patient_name'])
            d['patient_id'] = sec.decrypt(d['patient_id'])
            results.append(d)
            
        return results

    def get_instances_for_series(self, series_uid):
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM instances WHERE series_uid = ? ORDER BY instance_number', (series_uid,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def get_pacs_nodes(self):
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute('SELECT * FROM pacs_nodes')
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    def add_pacs_node(self, ae_title, ip, port, description):
        conn = self.get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute('''
                INSERT OR REPLACE INTO pacs_nodes (ae_title, ip_address, port, description)
                VALUES (?, ?, ?, ?)
            ''', (ae_title, ip, port, description))
            conn.commit()
        except Exception as e:
            self.logger.error(f"Error adding PACS node: {e}")
        finally:
            conn.close()

    def delete_pacs_node(self, ae_title):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('DELETE FROM pacs_nodes WHERE ae_title = ?', (ae_title,))
        conn.commit()
        conn.close()

    def get_setting(self, key, default=None):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('SELECT value FROM settings WHERE key = ?', (key,))
        row = cursor.fetchone()
        conn.close()
        return row[0] if row else default

    def set_setting(self, key, value):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', (key, str(value)))
        conn.commit()
        conn.close()

    def get_study_count(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM studies")
        count = cursor.fetchone()[0]
        conn.close()
        return count

    def get_recent_studies(self, limit=10):
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        # Using rowid as proxy for insertion time if created_at not reliable or present
        cursor.execute("""
            SELECT study_uid, patient_name, patient_id, study_date, modality, description 
            FROM studies 
            ORDER BY rowid DESC 
            LIMIT ?
        """, (limit,))
        rows = cursor.fetchall()
        conn.close()
        return [dict(row) for row in rows]

    # --- User Management ---
    def authenticate_user(self, username, password):
        import hashlib
        pw_hash = hashlib.sha256(password.encode()).hexdigest()
        
        conn = self.get_connection()
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ? AND password_hash = ?", (username, pw_hash))
        user = cursor.fetchone()
        conn.close()
        
        if user:
            return dict(user)
        return None

    def create_user(self, username, password, role, full_name, email=""):
        import hashlib
        pw_hash = hashlib.sha256(password.encode()).hexdigest()
        
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users (username, password_hash, role, full_name, email) VALUES (?, ?, ?, ?, ?)",
                           (username, pw_hash, role, full_name, email))
            conn.commit()
            conn.close()
            return True
        except sqlite3.IntegrityError:
            return False

    def log_audit(self, user_id, action, target_id, details):
        conn = self.get_connection()
        cursor = conn.cursor()
        cursor.execute("INSERT INTO audit_logs (user_id, action, target_id, details) VALUES (?, ?, ?, ?)",
                       (user_id, action, target_id, details))
        conn.commit()
        conn.close()

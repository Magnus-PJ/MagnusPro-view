import sqlite3
import os
from datetime import datetime
from ..utils.logger import get_logger
from ..utils.config import ConfigManager

class DatabaseManager:
    def __init__(self, db_path=None):
        self.logger = get_logger("DatabaseManager")
        self.config = ConfigManager()
        
        self.db_path = db_path if db_path else self.config.get("db_path")
        self.conn = None
        try:
            self.create_tables()
            self.logger.info(f"Database initialized at {self.db_path}")
        except Exception as e:
            self.logger.critical(f"Failed to initialize database: {e}")

    def get_connection(self):
        if not self.conn:
            try:
                self.conn = sqlite3.connect(self.db_path, check_same_thread=False)
                self.conn.row_factory = sqlite3.Row
            except sqlite3.Error as e:
                self.logger.error(f"Connection failed: {e}")
                raise
        return self.conn

    def create_tables(self):
        conn = self.get_connection()
        cursor = conn.cursor()
        
        # Studies Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS studies (
                study_uid TEXT PRIMARY KEY,
                patient_name TEXT,
                patient_id TEXT,
                study_date TEXT,
                modality TEXT,
                description TEXT,
                accession_number TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        
        # Series Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS series (
                series_uid TEXT PRIMARY KEY,
                study_uid TEXT,
                modality TEXT,
                series_number TEXT,
                description TEXT,
                body_part TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(study_uid) REFERENCES studies(study_uid)
            )
        """)
        
        # Instances Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS instances (
                sop_uid TEXT PRIMARY KEY,
                series_uid TEXT,
                file_path TEXT,
                instance_number INTEGER,
                z_position REAL,
                pixel_spacing TEXT,
                slice_thickness REAL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(series_uid) REFERENCES series(series_uid)
            )
        """)
        
        # Check if columns exist (migration for existing DB)
        try:
            cursor.execute("SELECT z_position FROM instances LIMIT 1")
        except sqlite3.OperationalError:
            self.logger.info("Migrating database: Adding z_position, pixel_spacing, slice_thickness")
            cursor.execute("ALTER TABLE instances ADD COLUMN z_position REAL")
            cursor.execute("ALTER TABLE instances ADD COLUMN pixel_spacing TEXT")
            cursor.execute("ALTER TABLE instances ADD COLUMN slice_thickness REAL")
        
        # PACS Nodes Table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS pacs_nodes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ae_title TEXT,
                ip_address TEXT,
                port INTEGER,
                description TEXT,
                protocol TEXT DEFAULT 'C-MOVE'
            )
        """)

        # App Settings Table (Key-Value)
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)
        
        conn.commit()

    def insert_study(self, study_data):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO studies (study_uid, patient_name, patient_id, study_date, modality, description, accession_number)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                study_data.get('StudyInstanceUID'),
                study_data.get('PatientName'),
                study_data.get('PatientID'),
                study_data.get('StudyDate'),
                study_data.get('Modality'),
                study_data.get('StudyDescription'),
                study_data.get('AccessionNumber')
            ))
            conn.commit()
        except sqlite3.Error as e:
            self.logger.error(f"Error inserting study: {e}")

    def insert_series(self, series_data):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO series (series_uid, study_uid, modality, series_number, description, body_part)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                series_data.get('SeriesInstanceUID'),
                series_data.get('StudyInstanceUID'),
                series_data.get('Modality'),
                series_data.get('SeriesNumber'),
                series_data.get('SeriesDescription'),
                series_data.get('BodyPartExamined')
            ))
            conn.commit()
        except sqlite3.Error as e:
            self.logger.error(f"Error inserting series: {e}")

    def insert_instance(self, instance_data):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO instances (sop_uid, series_uid, file_path, instance_number, z_position, pixel_spacing, slice_thickness)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (
                instance_data.get('SOPInstanceUID'),
                instance_data.get('SeriesInstanceUID'),
                instance_data.get('FilePath'),
                instance_data.get('InstanceNumber'),
                instance_data.get('ZPosition'),
                instance_data.get('PixelSpacing'),
                instance_data.get('SliceThickness')
            ))
            conn.commit()
        except sqlite3.Error as e:
            self.logger.error(f"Error inserting instance: {e}")

    def get_all_studies(self):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM studies ORDER BY study_date DESC")
            return cursor.fetchall()
        except sqlite3.Error as e:
            self.logger.error(f"Error fetching studies: {e}")
            return []

    def get_series_for_study(self, study_uid):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM series WHERE study_uid = ? ORDER BY series_number", (study_uid,))
            return cursor.fetchall()
        except sqlite3.Error as e:
            self.logger.error(f"Error fetching series for study {study_uid}: {e}")
            return []

    def get_instances_for_series(self, series_uid):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM instances WHERE series_uid = ? ORDER BY instance_number", (series_uid,))
            return cursor.fetchall()
        except sqlite3.Error as e:
            self.logger.error(f"Error fetching instances for series {series_uid}: {e}")
            return []

    # PACS Node Methods
    def get_pacs_nodes(self):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM pacs_nodes")
            return cursor.fetchall()
        except sqlite3.Error as e:
            self.logger.error(f"Error fetching PACS nodes: {e}")
            return []

    def add_pacs_node(self, ae_title, ip, port, desc, proto="C-MOVE"):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("INSERT INTO pacs_nodes (ae_title, ip_address, port, description, protocol) VALUES (?, ?, ?, ?, ?)",
                           (ae_title, ip, port, desc, proto))
            conn.commit()
        except sqlite3.Error as e:
            self.logger.error(f"Error adding PACS node: {e}")

    def delete_pacs_node(self, ae_title):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("DELETE FROM pacs_nodes WHERE ae_title = ?", (ae_title,))
            conn.commit()
        except sqlite3.Error as e:
            self.logger.error(f"Error deleting PACS node: {e}")

    # Settings Methods
    def get_setting(self, key, default=None):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("SELECT value FROM settings WHERE key = ?", (key,))
            row = cursor.fetchone()
            return row[0] if row else default
        except sqlite3.Error as e:
            self.logger.error(f"Error fetching setting {key}: {e}")
            return default

    def set_setting(self, key, value):
        try:
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)", (key, str(value)))
            conn.commit()
        except sqlite3.Error as e:
            self.logger.error(f"Error setting {key}: {e}")

    def close(self):
        if self.conn:
            self.conn.close()

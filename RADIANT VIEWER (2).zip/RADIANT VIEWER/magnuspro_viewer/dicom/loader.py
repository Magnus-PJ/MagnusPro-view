import os
import pydicom
from PyQt6.QtCore import QThread, pyqtSignal
import numpy as np

class DicomSeries:
    def __init__(self, uid, description, modality, series_number):
        self.uid = uid
        self.description = description
        self.modality = modality
        self.series_number = series_number
        self.files = []  # List of file paths
        self.instances = {} # Map instance number to file path
        self.z_positions = {} # Map instance number to z-position
        self.thumbnail = None

    def add_file(self, file_path, instance_number, z_pos=None):
        self.files.append(file_path)
        self.instances[instance_number] = file_path
        if z_pos is not None:
            self.z_positions[instance_number] = z_pos

    def get_sorted_files(self):
        # Sort by Z-position if available (for 3D/MPR correctness)
        if self.z_positions:
            # Sort keys based on z-position, defaulting to 0.0 if missing
            keys = sorted(self.instances.keys(), key=lambda k: self.z_positions.get(k, 0.0))
            return [self.instances[k] for k in keys]
        else:
            # Fallback to instance number
            sorted_instances = sorted(self.instances.keys())
            return [self.instances[k] for k in sorted_instances]

import logging

class DicomLoader(QThread):
    series_found = pyqtSignal(DicomSeries)
    finished_scanning = pyqtSignal()

    def __init__(self, folder_path, db_manager=None):
        super().__init__()
        self.folder_path = folder_path
        self.db_manager = db_manager
        self.stop_flag = False

    def run(self):
        series_map = {}

        for root, dirs, files in os.walk(self.folder_path):
            if self.stop_flag:
                break
            for file in files:
                file_path = os.path.join(root, file)
                try:
                    # Fast read, stop before pixel data
                    ds = pydicom.dcmread(file_path, stop_before_pixels=True)
                    
                    # Check if it's a valid DICOM image
                    if "PixelData" not in ds and "ImagePositionPatient" not in ds:
                        continue # Skip non-image files

                    series_uid = ds.SeriesInstanceUID
                    study_uid = ds.StudyInstanceUID
                    
                    # Extract Z-position
                    z_pos = None
                    if "ImagePositionPatient" in ds:
                        try:
                            z_pos = float(ds.ImagePositionPatient[2])
                        except:
                            pass

                    # Extract Spacing and Thickness
                    pixel_spacing = str(ds.get("PixelSpacing", ""))
                    slice_thickness = float(ds.get("SliceThickness", 0.0))

                    # Insert into Database if manager exists
                    if self.db_manager:
                        # Study
                        study_data = {
                            'StudyInstanceUID': study_uid,
                            'PatientName': str(ds.get('PatientName', 'Unknown')),
                            'PatientID': str(ds.get('PatientID', 'Unknown')),
                            'StudyDate': str(ds.get('StudyDate', '')),
                            'Modality': str(ds.get('Modality', 'Unknown')),
                            'StudyDescription': str(ds.get('StudyDescription', '')),
                            'AccessionNumber': str(ds.get('AccessionNumber', ''))
                        }
                        self.db_manager.insert_study(study_data)
                        
                        # Series
                        series_data = {
                            'SeriesInstanceUID': series_uid,
                            'StudyInstanceUID': study_uid,
                            'Modality': str(ds.get('Modality', 'Unknown')),
                            'SeriesNumber': str(ds.get('SeriesNumber', '')),
                            'SeriesDescription': str(ds.get('SeriesDescription', '')),
                            'BodyPartExamined': str(ds.get('BodyPartExamined', ''))
                        }
                        self.db_manager.insert_series(series_data)
                        
                        # Instance
                        instance_data = {
                            'SOPInstanceUID': ds.SOPInstanceUID,
                            'SeriesInstanceUID': series_uid,
                            'FilePath': file_path,
                            'InstanceNumber': int(ds.get('InstanceNumber', 0)),
                            'ZPosition': z_pos,
                            'PixelSpacing': pixel_spacing,
                            'SliceThickness': slice_thickness
                        }
                        self.db_manager.insert_instance(instance_data)

                    if series_uid not in series_map:
                        desc = ds.get("SeriesDescription", "No Description")
                        modality = ds.get("Modality", "Unknown")
                        series_num = ds.get("SeriesNumber", "?")
                        series_obj = DicomSeries(series_uid, desc, modality, series_num)
                        series_map[series_uid] = series_obj
                    
                    instance_num = int(ds.get("InstanceNumber", 0))
                    series_map[series_uid].add_file(file_path, instance_num, z_pos)

                except Exception as e:
                    logging.debug(f"Skipping file {file_path}: {e}")
                    continue
        
        # After scanning, generate thumbnails for found series
        for uid, series in series_map.items():
            try:
                files = series.get_sorted_files()
                if files:
                    mid_file = files[len(files)//2]
                    # Read pixel data for thumbnail
                    from .decoder import ImageDecoder
                    pixel_data, _ = ImageDecoder.decode_pixel_data(mid_file)
                    
                    # Normalize to 8-bit for display
                    if pixel_data.max() > pixel_data.min():
                        norm = (pixel_data - pixel_data.min()) / (pixel_data.max() - pixel_data.min()) * 255
                        thumb_data = norm.astype('uint8')
                    else:
                        thumb_data = np.zeros_like(pixel_data, dtype='uint8')
                    
                    series.thumbnail = thumb_data
                    self.series_found.emit(series)
                else:
                    self.series_found.emit(series)
            except Exception:
                self.series_found.emit(series)

        self.finished_scanning.emit()

    def stop(self):
        self.stop_flag = True

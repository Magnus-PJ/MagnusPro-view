import pydicom
import numpy as np
try:
    from pylibjpeg import decode
except ImportError:
    decode = None

class ImageDecoder:
    @staticmethod
    def decode_pixel_data(file_path):
        """
        Decodes pixel data from a DICOM file.
        Returns a numpy array of the image data.
        """
        ds = pydicom.dcmread(file_path)
        
        # Handle compressed transfer syntaxes
        if ds.file_meta.TransferSyntaxUID.is_compressed:
            if decode:
                # Use pylibjpeg if available
                ds.PixelData = decode(ds.PixelData, ds)
            else:
                # Fallback to pydicom's handler (might need gdcm or pillow)
                ds.decompress()
        
        pixel_array = ds.pixel_array
        
        # Apply Rescale Slope/Intercept if present to get Hounsfield Units or similar
        slope = getattr(ds, 'RescaleSlope', 1)
        intercept = getattr(ds, 'RescaleIntercept', 0)
        
        if slope != 1 or intercept != 0:
            pixel_array = pixel_array * slope + intercept
            
        return pixel_array, ds

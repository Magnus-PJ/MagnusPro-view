from PyQt6.QtCore import QThread, pyqtSignal
import numpy as np
from .decoder import ImageDecoder

class SeriesLoaderThread(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal(object, object) # volume (numpy), first_ds (pydicom dataset)
    error = pyqtSignal(str)

    def __init__(self, files):
        super().__init__()
        self.files = files

    def run(self):
        try:
            slices = []
            first_ds = None
            total = len(self.files)
            
            from ..utils.cache_manager import LRUCache
            cache = LRUCache()
            
            for i, f in enumerate(self.files):
                ds = None
                cached_data = cache.get(f)
                
                if cached_data is not None:
                    pixel_data = cached_data
                    # Only decode dataset if we really need it (for the first frame)
                    if first_ds is None:
                        _, ds = ImageDecoder.decode_pixel_data(f)
                else:
                    pixel_data, ds = ImageDecoder.decode_pixel_data(f)
                    cache.put(f, pixel_data)
                
                slices.append(pixel_data)
                if first_ds is None and ds is not None:
                    first_ds = ds
                
                # Emit progress every 5% or so to avoid flooding event loop
                if i % max(1, total // 20) == 0:
                    self.progress.emit(int((i + 1) / total * 100))
            
            if not slices:
                self.error.emit("No images loaded.")
                return

            # Stack into 3D array
            volume = np.array(slices)
            self.progress.emit(100)
            self.finished.emit(volume, first_ds)
            
        except Exception as e:
            self.error.emit(str(e))

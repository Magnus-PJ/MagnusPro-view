import vtk
import math

class MeasurementTool:
    def __init__(self, interactor, renderer):
        self.interactor = interactor
        self.renderer = renderer
        self.widget = None
        self.enabled = False

    def enable(self):
        if self.widget:
            self.widget.On()
            self.enabled = True

    def disable(self):
        if self.widget:
            self.widget.Off()
            self.enabled = False

class DistanceTool(MeasurementTool):
    def __init__(self, interactor, renderer):
        super().__init__(interactor, renderer)
        self.widget = vtk.vtkDistanceWidget()
        self.widget.SetInteractor(interactor)
        self.widget.CreateDefaultRepresentation()
        
        # Style
        rep = self.widget.GetRepresentation()
        rep.GetAxis().SetProperty(vtk.vtkProperty())
        rep.GetAxis().GetProperty().SetColor(1, 1, 0) # Yellow
        
    def get_distance(self):
        if self.widget:
            return self.widget.GetRepresentation().GetDistance()
        return 0.0

class AngleTool(MeasurementTool):
    def __init__(self, interactor, renderer):
        super().__init__(interactor, renderer)
        self.widget = vtk.vtkAngleWidget()
        self.widget.SetInteractor(interactor)
        self.widget.CreateDefaultRepresentation()
        
        # Style
        rep = self.widget.GetRepresentation()
        rep.GetArc().GetProperty().SetColor(0, 1, 0) # Green
        rep.GetRay1().GetProperty().SetColor(0, 1, 0)
        rep.GetRay2().GetProperty().SetColor(0, 1, 0)

    def get_angle(self):
        if self.widget:
            return self.widget.GetRepresentation().GetAngle()
        return 0.0

class ROITool(MeasurementTool):
    def __init__(self, interactor, renderer):
        super().__init__(interactor, renderer)
        # Using vtkContourWidget for ROI
        self.widget = vtk.vtkContourWidget()
        self.widget.SetInteractor(interactor)
        
        rep = vtk.vtkOrientedGlyphContourRepresentation()
        rep.GetLinesProperty().SetColor(1, 0, 0) # Red
        self.widget.SetRepresentation(rep)
        
    def get_stats(self, image_data):
        # This is complex: need to rasterize contour to mask and calculate stats
        # For now, just return placeholder
        return {"mean": 0, "std": 0}

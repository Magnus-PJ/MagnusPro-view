import vtk
import numpy as np
from vtk.util import numpy_support

class VTKImporter:
    @staticmethod
    def numpy_to_vtk_image(numpy_array, spacing=(1.0, 1.0, 1.0), origin=(0.0, 0.0, 0.0), orientation=None):
        """
        Converts a 3D numpy array to vtkImageData.
        orientation: list of 6 floats (ImageOrientationPatient) or None
        """
        # Ensure array is contiguous
        if not numpy_array.flags.c_contiguous:
            numpy_array = np.ascontiguousarray(numpy_array)

        importer = vtk.vtkImageImport()
        
        # VTK expects data in specific type
        dtype = numpy_array.dtype
        if dtype == np.int16:
            importer.SetDataScalarTypeToShort()
        elif dtype == np.uint16:
            importer.SetDataScalarTypeToUnsignedShort()
        elif dtype == np.float32:
            importer.SetDataScalarTypeToFloat()
        # ... add other types as needed
        
        # Get dimensions
        depth, height, width = numpy_array.shape
        importer.SetDataExtent(0, width - 1, 0, height - 1, 0, depth - 1)
        importer.SetWholeExtent(0, width - 1, 0, height - 1, 0, depth - 1)
        
        importer.SetDataSpacing(spacing)
        importer.SetDataOrigin(origin)
        
        # Pass data
        data_string = numpy_array.tobytes()
        importer.CopyImportVoidPointer(data_string, len(data_string))
        
        importer.Update()
        image_data = importer.GetOutput()
        
        # Apply Orientation (Direction Matrix)
        if orientation and len(orientation) == 6:
            # DICOM ImageOrientationPatient: [Xx, Xy, Xz, Yx, Yy, Yz]
            # X vector (Row direction)
            x_dir = np.array(orientation[:3])
            # Y vector (Column direction)
            y_dir = np.array(orientation[3:])
            # Z vector (Slice direction) = X cross Y
            z_dir = np.cross(x_dir, y_dir)
            
            # Normalize (just in case)
            x_dir = x_dir / np.linalg.norm(x_dir)
            y_dir = y_dir / np.linalg.norm(y_dir)
            z_dir = z_dir / np.linalg.norm(z_dir)
            
            # Create 3x3 matrix
            matrix = vtk.vtkMatrix3x3()
            # Set columns (VTK uses column-major or row-major? vtkMatrix3x3 SetElement(row, col, val))
            # The DirectionMatrix in vtkImageData represents the axes directions.
            # Col 0 = X axis, Col 1 = Y axis, Col 2 = Z axis
            
            for i in range(3):
                matrix.SetElement(i, 0, x_dir[i])
                matrix.SetElement(i, 1, y_dir[i])
                matrix.SetElement(i, 2, z_dir[i])
                
            image_data.SetDirectionMatrix(matrix)
            
        return image_data

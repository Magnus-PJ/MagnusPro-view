import sys
from collections import OrderedDict

class LRUCache:
    _instance = None
    
    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super(LRUCache, cls).__new__(cls)
            cls._instance.init(*args, **kwargs)
        return cls._instance

    def init(self, max_size_bytes=4*1024*1024*1024): # 4GB Default
        if hasattr(self, 'cache'): return
        self.cache = OrderedDict()
        self.max_size = max_size_bytes
        self.current_size = 0

    def get(self, key):
        if key in self.cache:
            self.cache.move_to_end(key)
            return self.cache[key]
        return None

    def put(self, key, value):
        size = self._get_size(value)
            
        if key in self.cache:
            self.current_size -= self._get_size(self.cache[key])
            
        self.cache[key] = value
        self.cache.move_to_end(key)
        self.current_size += size
        
        while self.current_size > self.max_size and self.cache:
            k, v = self.cache.popitem(last=False)
            self.current_size -= self._get_size(v)
            
    def _get_size(self, value):
        if hasattr(value, 'nbytes'):
            return value.nbytes
        return sys.getsizeof(value)

    def clear(self):
        self.cache.clear()
        self.current_size = 0

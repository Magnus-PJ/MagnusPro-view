import xml.etree.ElementTree as ET
import vtk
import os

class OverlayManager:
    def __init__(self, config_path):
        self.config_path = config_path
        self.overlays = [] # List of (corner, items)
        self.actors = {} # Map corner -> vtkTextActor
        self.load_config()

    def load_config(self):
        if not os.path.exists(self.config_path):
            return
        
        tree = ET.parse(self.config_path)
        root = tree.getroot()
        
        for corner in root.findall('Corner'):
            pos = corner.get('position')
            items = []
            for item in corner.findall('Item'):
                items.append({
                    'tag': item.get('tag'),
                    'label': item.get('label'),
                    'suffix': item.get('suffix', ''),
                    'format': item.get('format', '')
                })
            self.overlays.append((pos, items))

    def create_actors(self, renderer):
        self.annotation = vtk.vtkCornerAnnotation()
        self.annotation.SetLinearFontScaleFactor(2)
        self.annotation.SetNonlinearFontScaleFactor(1)
        self.annotation.SetMaximumFontSize(20)
        self.annotation.GetTextProperty().SetColor(1, 0.8, 0.2) # Gold/Yellow
        self.annotation.GetTextProperty().SetFontFamilyToArial()
        
        renderer.AddViewProp(self.annotation)

    def update_overlays(self, ds, overrides=None):
        if not self.annotation: return
        
        # Map XML positions to vtkCornerAnnotation indices
        # 0: sw, 1: se, 2: nw, 3: ne
        corner_map = {
            "BottomLeft": 0,
            "BottomRight": 1,
            "TopLeft": 2,
            "TopRight": 3
        }

        for pos, items in self.overlays:
            text_lines = []
            for item in items:
                tag = item['tag'] # e.g. "0010,0010"
                
                # Check overrides first
                val = None
                if overrides and tag in overrides:
                    val = overrides[tag]
                else:
                    try:
                        group, elem = tag.split(',')
                        group = int(group, 16)
                        elem = int(elem, 16)
                        if (group, elem) in ds:
                            val = ds[group, elem].value
                            val = str(val)
                    except:
                        pass
                
                if val:
                    line = val
                    if item['label']:
                        line = f"{item['label']}: {val}"
                    if item['suffix']:
                        line = f"{line} {item['suffix']}"
                    text_lines.append(line)
            
            if pos in corner_map:
                self.annotation.SetText(corner_map[pos], "\n".join(text_lines))

    def set_roi_stats(self, stats_text):
        if not self.annotation: return
        # Append to Bottom Right (index 1) or a dedicated area
        # For now, let's just append to Bottom Right
        current_text = self.annotation.GetText(1)
        if current_text:
            new_text = f"{current_text}\n{stats_text}"
        else:
            new_text = stats_text
        self.annotation.SetText(1, new_text)

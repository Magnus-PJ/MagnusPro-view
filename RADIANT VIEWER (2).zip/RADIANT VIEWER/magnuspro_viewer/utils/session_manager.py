class SessionManager:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SessionManager, cls).__new__(cls)
            cls._instance.current_user = None
        return cls._instance

    def login(self, user_data):
        self.current_user = user_data
        
    def logout(self):
        self.current_user = None
        
    def get_current_user(self):
        return self.current_user
        
    def is_logged_in(self):
        return self.current_user is not None
        
    def get_role(self):
        if self.current_user:
            return self.current_user.get('role')
        return None
        
    def has_permission(self, action):
        """
        Zero Trust Permission Check.
        Every action must be explicitly allowed by the role.
        """
        if not self.current_user:
            return False
            
        role = self.current_user.get('role')
        
        # SuperAdmin has all permissions
        if role == 'SuperAdmin':
            return True
            
        # Define Role-Based Permissions
        permissions = {
            'Admin': ['manage_users', 'view_audit', 'manage_patients', 'view_reports'],
            'Radiologist': ['view_studies', 'report_studies', 'view_worklist', 'export_images'],
            'Technician': ['view_studies', 'upload_studies', 'view_worklist'],
            'ReferralDoctor': ['view_studies', 'view_reports'],
            'Guest': []
        }
        
        allowed_actions = permissions.get(role, [])
        return action in allowed_actions

    def require_permission(self, action):
        if not self.has_permission(action):
            raise PermissionError(f"User {self.current_user['username']} (Role: {self.get_role()}) denied access to {action}")

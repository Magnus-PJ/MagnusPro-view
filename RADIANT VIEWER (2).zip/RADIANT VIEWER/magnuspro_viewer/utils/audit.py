import logging
import os
from .paths import ensure_appdata_dir

def get_audit_logger():
    logger = logging.getLogger("Audit")
    if not logger.handlers:
        app_data = ensure_appdata_dir()
        log_dir = os.path.join(app_data, "logs")
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)
        
        handler = logging.FileHandler(os.path.join(log_dir, "audit.log"))
        formatter = logging.Formatter('%(asctime)s - %(message)s')
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)
    return logger

def log_access(user, action, resource, details=""):
    """
    Logs an audit event.
    user: Username or ID
    action: OPEN, CLOSE, QUERY, RETRIEVE, SEND, LOGIN, LOGOUT
    resource: StudyUID, PatientID, or System
    details: Additional info
    """
    logger = get_audit_logger()
    msg = f"USER:{user} | ACTION:{action} | RESOURCE:{resource} | DETAILS:{details}"
    logger.info(msg)

import json
import os
from .logger import get_logger

class HangingProtocolManager:
    def __init__(self, protocols_dir=None):
        self.logger = get_logger("HangingProtocolManager")
        self.protocols = {}
        self.protocols_dir = protocols_dir
        if not self.protocols_dir:
            # Default to a 'protocols' folder in config
            from .paths import get_app_data_dir
            self.protocols_dir = os.path.join(get_app_data_dir(), "protocols")
            
        if not os.path.exists(self.protocols_dir):
            os.makedirs(self.protocols_dir)
            self.create_default_protocols()
            
        self.load_protocols()

    def create_default_protocols(self):
        defaults = [
            {
                "id": "default_2x2",
                "name": "Default 2x2",
                "description": "Standard 2x2 Grid",
                "layout": {"rows": 2, "columns": 2},
                "rules": [] 
            },
            {
                "id": "ct_chest",
                "name": "CT Chest",
                "description": "Axial, Coronal, Sagittal + 3D",
                "layout": {"rows": 2, "columns": 2},
                "rules": [
                    {"modality": "CT", "body_part": "CHEST"}
                ],
                "viewports": [
                    {"type": "mpr", "view": "axial"},
                    {"type": "mpr", "view": "coronal"},
                    {"type": "mpr", "view": "sagittal"},
                    {"type": "3d"}
                ]
            }
        ]
        
        for p in defaults:
            path = os.path.join(self.protocols_dir, f"{p['id']}.json")
            with open(path, 'w') as f:
                json.dump(p, f, indent=4)

    def load_protocols(self):
        self.protocols = {}
        for f in os.listdir(self.protocols_dir):
            if f.endswith(".json"):
                try:
                    with open(os.path.join(self.protocols_dir, f), 'r') as file:
                        data = json.load(file)
                        self.protocols[data['id']] = data
                except Exception as e:
                    self.logger.error(f"Failed to load protocol {f}: {e}")

    def get_protocol(self, protocol_id):
        return self.protocols.get(protocol_id)

    def find_best_protocol(self, study_metadata):
        # Simple matching logic
        # study_metadata: dict with Modality, BodyPartExamined, etc.
        
        best_match = None
        max_score = -1
        
        for pid, proto in self.protocols.items():
            score = 0
            rules = proto.get("rules", [])
            if not rules:
                continue
                
            for rule in rules:
                match = True
                for key, val in rule.items():
                    # Check if metadata has this key and value matches
                    # Case insensitive
                    meta_val = str(study_metadata.get(key, "")).upper()
                    if meta_val != str(val).upper():
                        match = False
                        break
                if match:
                    score += 1
            
            if score > max_score:
                max_score = score
                best_match = proto
                
        return best_match

import xml.etree.ElementTree as ET
import os

class OptionsManager:
    def __init__(self, config_path):
        self.config_path = config_path
        self.presets = [] # List of {'name': str, 'center': int, 'width': int}
        self.load_config()

    def load_config(self):
        if not os.path.exists(self.config_path):
            return
        
        try:
            tree = ET.parse(self.config_path)
            root = tree.getroot()
            
            wl_presets = root.find('WindowLevelPresets')
            if wl_presets is not None:
                for preset in wl_presets.findall('Preset'):
                    self.presets.append({
                        'name': preset.get('name'),
                        'center': float(preset.get('center')),
                        'width': float(preset.get('width'))
                    })
        except Exception as e:
            print(f"Error loading options: {e}")

import os
import sys
from pathlib import Path

def appdata_dir():
    """
    Returns the application data directory.
    Windows: %APPDATA%/MagnusPro
    Linux/Mac: ~/.magnuspro
    """
    # Portable Mode Check
    # If 'config' folder exists in the same directory as the executable/script, use it.
    # This allows running from USB stick without touching AppData.
    
    # Get base dir of executable or script
    if getattr(sys, 'frozen', False):
        base_dir = os.path.dirname(sys.executable)
    else:
        base_dir = os.path.dirname(os.path.abspath(__file__))
        # Go up from utils/
        base_dir = os.path.dirname(os.path.dirname(base_dir))

    local_config = os.path.join(base_dir, "config")
    if os.path.exists(local_config):
        return base_dir

    if sys.platform == "win32":
        base = os.getenv("APPDATA", str(Path.home() / "AppData" / "Roaming"))
        return os.path.join(base, "MagnusPro")
    else:
        return os.path.join(str(Path.home()), ".magnuspro")

def ensure_appdata_dir():
    """Creates the appdata directory if it doesn't exist."""
    path = appdata_dir()
    os.makedirs(path, exist_ok=True)
    return path

def get_app_data_dir():
    return ensure_appdata_dir()

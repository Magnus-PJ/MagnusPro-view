import json
import os
from .logger import get_logger
from .paths import ensure_appdata_dir

class ConfigManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
            cls._instance.init()
        return cls._instance

    def init(self):
        self.logger = get_logger("ConfigManager")
        self.config_dir = ensure_appdata_dir()
        self.config_file = os.path.join(self.config_dir, "config.json")
        self.config = {}
        self.load_config()

    def load_config(self):
        if os.path.exists(self.config_file):
            try:
                with open(self.config_file, 'r') as f:
                    self.config = json.load(f)
                self.logger.info(f"Configuration loaded from {self.config_file}")
            except Exception as e:
                self.logger.error(f"Failed to load configuration: {e}")
                self.set_defaults()
        else:
            self.set_defaults()
            self.save_config()

    def set_defaults(self):
        self.config = {
            "log_level": "INFO",
            "dicom_storage_path": os.path.join(self.config_dir, "pacs_received"),
            "max_cache_size_mb": 1024,
            "theme": "Dark",
            "db_path": os.path.join(self.config_dir, "radiant_clone.db"),
            "tls_enabled": False,
            "tls_cert": "",
            "tls_key": ""
        }

    def save_config(self):
        try:
            with open(self.config_file, 'w') as f:
                json.dump(self.config, f, indent=4)
            self.logger.info("Configuration saved")
        except Exception as e:
            self.logger.error(f"Failed to save configuration: {e}")

    def get(self, key, default=None):
        return self.config.get(key, default)

    def set(self, key, value):
        self.config[key] = value
        self.save_config()

import requests
from PyQt6.QtCore import QObject, pyqtSignal, QThread

class UpdateChecker(QThread):
    finished = pyqtSignal(dict) # Returns version info or error
    
    def __init__(self, update_url):
        super().__init__()
        self.update_url = update_url
        
    def run(self):
        try:
            response = requests.get(self.update_url, timeout=5)
            if response.status_code == 200:
                data = response.json()
                self.finished.emit(data)
            else:
                self.finished.emit({"error": f"HTTP {response.status_code}"})
        except Exception as e:
            self.finished.emit({"error": str(e)})

class UpdateManager(QObject):
    def __init__(self, current_version="1.0.0"):
        super().__init__()
        self.current_version = current_version
        # Mock URL for now, or use a real GitHub raw URL if available
        self.update_url = "https://raw.githubusercontent.com/magnuspro/updates/main/version.json" 
        
    def check_for_updates(self, callback):
        self.checker = UpdateChecker(self.update_url)
        self.checker.finished.connect(callback)
        self.checker.start()

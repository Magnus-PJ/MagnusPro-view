import logging
import os
import sys
from logging.handlers import RotatingFileHandler

from .paths import ensure_appdata_dir

def setup_logger(name="MagnusPro"):
    """
    Sets up a centralized logger with file rotation and console output.
    Logs are stored in %APPDATA%/MagnusPro/logs/app.log
    """
    # Determine log directory
    app_data = ensure_appdata_dir()
    log_dir = os.path.join(app_data, "logs")
    if not os.path.exists(log_dir):
        os.makedirs(log_dir)
        
    log_file = os.path.join(log_dir, "app.log")
    
    # Create Logger
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)
    
    # Formatter
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    
    # File Handler (Rotating)
    # 5 MB per file, keep 5 backups
    file_handler = RotatingFileHandler(log_file, maxBytes=5*1024*1024, backupCount=5)
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(formatter)
    
    # Console Handler
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(formatter)
    
    # Add Handlers
    if not logger.handlers:
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)
        
    return logger

def get_logger(name="MagnusPro"):
    return logging.getLogger(name)

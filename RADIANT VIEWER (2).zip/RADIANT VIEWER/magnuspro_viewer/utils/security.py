import base64
import hashlib
import os
from .logger import get_logger

class SecurityManager:
    _instance = None
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(SecurityManager, cls).__new__(cls)
            cls._instance.logger = get_logger("SecurityManager")
            cls._instance.key = b'SecretKeyForDemo' # In prod, load from env/secure storage
            cls._instance.has_crypto = False
            try:
                from cryptography.fernet import Fernet
                # Generate a key if not exists, for now use fixed for demo consistency
                # key = Fernet.generate_key() 
                # self.cipher = Fernet(key)
                cls._instance.has_crypto = True
            except ImportError:
                cls._instance.logger.warning("Cryptography module not found. Using fallback obfuscation.")
                
        return cls._instance

    def encrypt(self, data):
        if not data:
            return data
            
        if self.has_crypto:
            # TODO: Implement actual Fernet encryption when lib is available
            # return self.cipher.encrypt(data.encode()).decode()
            pass
            
        # Fallback: Simple Base64 Obfuscation (NOT SECURE for Prod)
        encoded = base64.b64encode(data.encode()).decode()
        return f"ENC:{encoded}"

    def decrypt(self, data):
        if not data or not data.startswith("ENC:"):
            return data
            
        if self.has_crypto:
            # return self.cipher.decrypt(data.encode()).decode()
            pass
            
        # Fallback
        encoded = data.split("ENC:")[1]
        return base64.b64decode(encoded).decode()

    def hash_password(self, password):
        # SHA256 is decent for legacy, but Argon2 is better (requires lib)
        return hashlib.sha256(password.encode()).hexdigest()

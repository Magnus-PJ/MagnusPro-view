# Comparative Analysis: MagnusPro View vs. Orthanc + OHIF

**Date:** 2025-12-04
**Subject:** Detailed comparison of MagnusPro View (Native Desktop) vs. Orthanc + OHIF (Web PACS + Viewer).

## 1. Conceptual Overview

### MagnusPro View
*   **Type:** **Native Desktop Workstation ("Thick Client")**.
*   **Analogy:** Like Microsoft Word or Adobe Photoshop installed on your computer.
*   **Core Philosophy:** Maximum performance, direct hardware access, local data processing, and independence from constant network connectivity.
*   **Primary Role:** A **Diagnostic Workstation** for radiologists requiring high-speed interaction with large datasets.

### Orthanc + OHIF
*   **Type:** **Server-Side PACS + Web Viewer ("Thin Client")**.
*   **Analogy:** Like Google Docs or Gmail.
*   **Core Philosophy:** Zero-footprint access, centralized data management, accessibility from any device with a browser.
*   **Primary Role:** **Enterprise Image Distribution**, referring physician access, and teleradiology review.

---

## 2. Detailed Architectural Comparison

| Feature | **MagnusPro View** | **Orthanc + OHIF** |
| :--- | :--- | :--- |
| **Architecture** | **Monolithic Desktop App** | **Client-Server (REST API)** |
| **Frontend** | **PyQt6 (Qt)**: Native Windows widgets. | **React.js**: HTML/DOM elements. |
| **Rendering Engine** | **VTK (C++)**: Direct OpenGL/GPU calls via Python bindings. | **VTK.js / Cornerstone**: WebGL via Browser. |
| **Data Storage** | **Local SQLite + Files**: Stores images on the user's hard drive. | **Server DB (SQLite/Postgres)**: Stores images on a central server. |
| **Protocol** | **DIMSE (C-STORE, C-MOVE)**: Traditional DICOM networking. | **DICOMWeb (WADO-RS, QIDO-RS)**: Modern HTTP-based standard. |
| **Processing** | **Local CPU/GPU**: Uses the user's powerful workstation hardware. | **Hybrid**: Server fetches data; Browser RAM/CPU renders it. |

### The "Data Flow" Difference
*   **MagnusPro**: You "Download" the study to your PC (C-MOVE). Once downloaded, opening it is instant, and scrolling is limited only by your local RAM/SSD.
*   **Orthanc+OHIF**: You "Stream" the study. The browser requests metadata (JSON), then requests pixel data chunks. Large studies (2000+ slices) can cause browser lag or memory crashes if the client machine isn't powerful enough.

---

## 3. Performance Deep Dive

### A. Large Datasets (e.g., Thin-Slice CT, 5000 images)
*   **MagnusPro**: **Superior**. Python/VTK can allocate 16GB+ of RAM easily. The C++ backend of VTK handles the volume rendering pipeline efficiently.
*   **OHIF**: **Struggles**. Browsers (Chrome/Edge) impose memory limits on tabs (often ~4GB). Loading a massive dataset requires complex "streaming" logic. Volume rendering in WebGL is impressive but slower than native OpenGL.

### B. Startup Time
*   **MagnusPro**: Slower initial "Download" (C-MOVE takes time). Instant "Open" once local.
*   **OHIF**: Faster "Time to First Image". You see the first slice immediately while the rest download in the background.

### C. MPR & 3D
*   **MagnusPro**: **Real-time**. `vtkResliceCursorWidget` runs natively.
*   **OHIF**: **Good, but heavy**. VTK.js is a rewrite of VTK in JavaScript. It is excellent but lacks some of the mature optimization of the 30-year-old C++ VTK library.

---

## 4. Deployment & Maintenance

| Aspect | **MagnusPro View** | **Orthanc + OHIF** |
| :--- | :--- | :--- |
| **Installation** | **Per-Machine**. Need to run an installer on every doctor's PC. | **Server-Only**. Install once on a server; users just visit a URL. |
| **Updates** | **Hard**. Must update every PC (or use IT management tools). | **Easy**. Update the server, and everyone gets the new version instantly. |
| **Offline Use** | **Yes**. Can view downloaded studies without internet. | **No**. Requires network connection to the server. |
| **Security** | Data resides on local laptops (Risk of theft). | Data resides on secure server (No data left on client PC). |

---

## 5. Integration & Extensibility (The "Python Advantage")

This is where MagnusPro shines for research and AI.

### AI Integration
*   **MagnusPro**: You can import `torch` or `tensorflow` directly in the code. You can run a heavy AI model locally on the user's GPU without sending data anywhere.
    *   *Example:* A "Detect Nodule" button that runs a PyTorch model on the loaded numpy array in 500ms.
*   **Orthanc + OHIF**: Requires a complex pipeline.
    *   1. OHIF sends request to Server.
    *   2. Server sends DICOM to an "AI Server" (e.g., NVIDIA Clara).
    *   3. AI Server processes and sends DICOM SR / SEG back to Orthanc.
    *   4. OHIF re-fetches the new data to display.

### Customization
*   **MagnusPro**: Modify Python code to add a specific button or form.
*   **OHIF**: Requires React knowledge and rebuilding the webpack bundle. Extensions system is powerful but complex.

---

## 6. Summary: When to use which?

### Choose **MagnusPro View** if:
1.  **Primary Diagnosis**: Radiologists need speed, multi-monitor support, and heavy tools (3D/MPR) without browser lag.
2.  **AI Research**: You need to rapidly prototype and deploy AI models directly within the viewer.
3.  **Offline/Remote**: Users perform scans in field hospitals or areas with poor internet (download once, view offline).
4.  **Legacy PACS**: You are connecting to old PACS systems that only speak DIMSE (C-MOVE) and not DICOMWeb.

### Choose **Orthanc + OHIF** if:
1.  **Enterprise Distribution**: You need 500+ referring doctors to view images without installing software.
2.  **IT Simplicity**: You want zero client-side maintenance.
3.  **Security**: You strictly require that no patient data is stored on local devices.
4.  **Teleradiology Portal**: You want a portal where doctors can log in from home on any device.

## 7. The "Hybrid" Opportunity

The best architecture often combines both:
*   **Orthanc** as the central PACS server (Backend).
*   **OHIF** for general access (referring doctors).
*   **MagnusPro** for the dedicated radiologists (connected to Orthanc via DICOM C-MOVE).

MagnusPro is built to be that **High-Performance Specialist Tool**, whereas OHIF is the **General Purpose Web Tool**.

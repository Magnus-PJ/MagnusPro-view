# MagnusPro: UI/UX & SEO Master Plan

**Objective:** Elevate MagnusPro View from a "functional tool" to a "premium, state-of-the-art workstation" with superior usability and data discoverability.

## 1. The "SEO" Strategy (Search, Export, Organization)

In the context of a desktop medical application, "SEO" refers to **Data Discoverability** and **Interoperability**.

### A. Internal Search Engine (The "Google" of MagnusPro)
*   **Current**: Basic SQL `LIKE` queries.
*   **Enhancement**:
    *   **Fuzzy Search**: Find "Smith" even if typed "Smyth".
    *   **Universal Search Bar**: A global search input in the title bar that queries Patients, Studies, and Reports simultaneously.
    *   **Smart Filters**: "CT Studies from Last Week" (Natural Language Processing - simplified).

### B. Export Optimization (External SEO)
*   **PDF Metadata**: When exporting reports, inject XMP metadata (Title, Author, Keywords, PatientID) so hospital Document Management Systems (DMS) can index them automatically.
*   **Image Naming**: Auto-generate filenames like `[PatientID]_[Modality]_[Date]_[Description].jpg` instead of `image_001.jpg` to make them searchable in Windows Explorer.
*   **DICOM Sanitization**: Ensure exported DICOMs have "clean" standard tags for perfect indexing by PACS archives.

### C. Accessibility & Semantics
*   **Tooltips**: Rich tooltips explaining complex buttons.
*   **Keyboard Navigation**: Full Tab/Arrow key support for power users.

---

## 2. UI/UX Modernization Strategy

### A. Visual Identity ("The Premium Feel")
*   **Theme**: "Deep Space Radiology"
    *   **Backgrounds**: `#1E1E1E` (Matte Dark) -> `#121212` (OLED Black).
    *   **Accents**: `#007AFF` (iOS Blue) -> `#4488FF` (Electric Blue) with Glow effects.
    *   **Typography**: Switch to **Inter** or **Roboto** (Modern, clean sans-serif).
*   **Glassmorphism**: Apply subtle transparency to the Title Bar and Floating Toolbars.

### B. Interaction Design ("The Fluid Feel")
*   **Micro-Animations**:
    *   **Button Hover**: Subtle scale up (1.05x) and brightness increase.
    *   **Screen Transitions**: Fade-in (200ms) when switching between Dashboard and Viewer.
    *   **Loading States**: Skeleton screens (shimmer effect) instead of spinning wheels.
*   **Feedback**:
    *   **Toast Notifications**: Floating overlays for "Save Successful" instead of blocking Status Bar messages.

### C. Dashboard 2.0
*   **Layout**: Masonry grid for "Recent Studies" cards.
*   **Charts**: Animated donut charts for "Storage Usage".

---

## 3. Implementation Roadmap (Phase 6)

### Step 1: The Visual Core (UI)
*   [ ] **StyleManager Upgrade**: Implement new QSS with variables for "Glow" and "Glass".
*   [ ] **Font Integration**: Bundle a premium font (e.g., Roboto).
*   [ ] **Animations**: Add `QPropertyAnimation` for widget transitions.

### Step 2: The "SEO" Engine (Data)
*   [ ] **Smart Search**: Update `DBManager` with multi-column search logic.
*   [ ] **Metadata Injector**: Update `ReportWidget` to write PDF metadata.
*   [ ] **Filename Generator**: Create `NamingStrategy` class for exports.

### Step 3: The UX Polish
*   [ ] **Toast Widget**: Create a custom overlay notification system.
*   [ ] **Skeleton Loader**: Create a placeholder widget for loading states.

---

## 4. Technical Stack Updates
*   **Qt Effects**: Use `QGraphicsEffect` (DropShadow, Opacity) for depth.
*   **PDF Engine**: Use `reportlab` or raw PDF commands if Qt's printer is too limited for metadata (Qt can handle basic metadata).
